from rich.console import Console

from biro.agent.streaming import ToolAwarePrinter


def test_stream_printer_hides_tool_payload_but_streams_prose():
    console = Console(record=True, width=120)
    printer = ToolAwarePrinter(console)
    for chunk in [
        "I will inspect ",
        "the files.\n```to",
        "ol\ntitle: Inspect\naction: shell\ncmd: ls\n``",
        "`\nThen I will fix it.",
    ]:
        printer.feed(chunk)
    printer.finish()
    rendered = console.export_text()
    assert "I will inspect the files." in rendered
    assert "Then I will fix it." in rendered
    assert "title: Inspect" not in rendered
    assert "cmd: ls" not in rendered


def test_incomplete_tool_fence_is_not_printed_as_action():
    console = Console(record=True, width=120)
    printer = ToolAwarePrinter(console)
    printer.feed("ordinary text\n```tool\ntitle: incomplete")
    printer.finish()
    rendered = console.export_text()
    assert "ordinary text" in rendered
    assert "title: incomplete" not in rendered
