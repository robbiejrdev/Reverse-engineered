import logging

import pytest
import requests

from biro.agent.search import TavilySearch


class FakeResponse:
    def __init__(self, status_code, *, data=None, text=""):
        self.status_code = status_code
        self._data = data
        self.text = text

    def json(self):
        if isinstance(self._data, Exception):
            raise self._data
        return self._data


def test_search_sends_keyless_request_and_validates_results(monkeypatch, caplog):
    observed = {}

    def post(url, *, headers, json, timeout):
        observed.update(url=url, headers=headers, payload=json, timeout=timeout)
        return FakeResponse(200, data={
            "results": [
                {
                    "url": "https://example.com/good",
                    "title": None,
                    "content": None,
                    "score": None,
                    "published_date": None,
                    "raw_content": "Do not send raw content to the model",
                },
                {"url": "not-a-url", "title": "Bad URL", "content": "skip"},
                {"url": "https://example.com/huge", "title": "Huge score", "content": "skip", "score": 10**10000},
                {"url": "https://example.com/nan", "title": "NaN score", "content": "skip", "score": float("nan")},
                {
                    "url": "https://example.com/date",
                    "title": "Event update",
                    "content": "Published October 26, 2026",
                    "score": 0.8,
                },
            ]
        })

    monkeypatch.setattr(requests, "post", post)
    with caplog.at_level(logging.INFO, logger="biro.agent.search"):
        result = TavilySearch().search("new query", max_results=2)

    assert observed["url"] == "https://api.tavily.com/search"
    assert observed["headers"] == {
        "Content-Type": "application/json",
        "X-Tavily-Access-Mode": "keyless",
    }
    assert observed["payload"] == {"query": "new query", "max_results": 2}
    assert observed["timeout"] == 30
    assert result["results"] == [
        {
            "title": "",
            "url": "https://example.com/good",
            "content": "",
            "score": 0.0,
            "published_date": "UNKNOWN",
        },
        {
            "title": "Event update",
            "url": "https://example.com/date",
            "content": "Published October 26, 2026",
            "score": 0.8,
            "published_date": "October 26, 2026",
        },
    ]
    assert "raw_content" not in repr(result)
    assert "raw content" not in caplog.text
    assert "results=2" in caplog.text


def test_fresh_search_and_current_query_set_news_filters(monkeypatch):
    payloads = []

    def post(_url, *, json, **_kwargs):
        payloads.append(json)
        return FakeResponse(200, data={"results": []})

    monkeypatch.setattr(requests, "post", post)
    search = TavilySearch()
    search.search("market update", fresh=True)
    search.search("latest market update")

    assert all(item["topic"] == "news" for item in payloads)
    assert all(item["time_range"] == "week" for item in payloads)


def test_historical_year_does_not_trigger_fresh_news_filter(monkeypatch):
    payloads = []
    monkeypatch.setattr(
        requests,
        "post",
        lambda _url, *, json, **_kwargs: (
            payloads.append(json) or FakeResponse(200, data={"results": []})
        ),
    )

    TavilySearch().search("What happened in 2024?")

    assert payloads == [{"query": "What happened in 2024?", "max_results": 5}]


def test_plain_text_rate_limit_retries_and_returns_error(monkeypatch):
    responses = iter([
        FakeResponse(429, text="rate limited"),
        FakeResponse(429, text="rate limited"),
        FakeResponse(429, text="rate limited"),
        FakeResponse(429, text="rate limited"),
    ])
    sleeps = []
    monkeypatch.setattr(requests, "post", lambda *_args, **_kwargs: next(responses))
    monkeypatch.setattr("biro.agent.search.time.sleep", sleeps.append)

    result = TavilySearch().search("query")

    assert result == {"error": "HTTP 429: rate limited"}
    assert sleeps == [1, 2, 4]


def test_plain_text_success_response_retries_json_parse_then_returns_error(monkeypatch):
    responses = iter([
        FakeResponse(200, data=ValueError("not JSON"), text="keyless unavailable"),
        FakeResponse(200, data=ValueError("not JSON"), text="keyless unavailable"),
        FakeResponse(200, data=ValueError("not JSON"), text="keyless unavailable"),
        FakeResponse(200, data=ValueError("not JSON"), text="keyless unavailable"),
    ])
    monkeypatch.setattr(requests, "post", lambda *_args, **_kwargs: next(responses))
    monkeypatch.setattr("biro.agent.search.time.sleep", lambda _delay: None)

    assert TavilySearch().search("query") == {"error": "HTTP 200: keyless unavailable"}


@pytest.mark.parametrize("status", [400, 401])
def test_permanent_client_errors_are_not_retried(monkeypatch, status):
    calls = []

    def post(*_args, **_kwargs):
        calls.append(True)
        return FakeResponse(status, text="bad request")

    monkeypatch.setattr(requests, "post", post)
    monkeypatch.setattr("biro.agent.search.time.sleep", lambda _delay: pytest.fail("must not retry"))

    assert TavilySearch().search("query") == {"error": f"HTTP {status}: bad request"}
    assert len(calls) == 1


def test_invalid_search_parameters_fail_before_network(monkeypatch):
    monkeypatch.setattr(
        requests,
        "post",
        lambda *_args, **_kwargs: pytest.fail("invalid parameters must not make a request"),
    )

    assert "must not be empty" in TavilySearch().search("  ")["error"]
    assert "string" in TavilySearch().search(None)["error"]
    assert "between 1 and 10" in TavilySearch().search("query", max_results=11)["error"]
    assert "boolean" in TavilySearch().search("query", fresh="yes")["error"]
