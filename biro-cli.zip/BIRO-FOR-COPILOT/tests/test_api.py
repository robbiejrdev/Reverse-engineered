import base64

import httpx
import pytest

from biro.api.client import BiroAPI, BiroAPIError
from biro.config import UserConfig, validate_model


def test_model_aliases_and_validation():
    assert validate_model("max") == "biro-max"
    assert validate_model("BIRO Mini") == "biro-mini"
    with pytest.raises(ValueError):
        validate_model("unknown/provider-model")


def test_short_prompt_uses_message_body():
    payload = BiroAPI._build_prompt_payload("hello", "biro-max")
    assert payload["message"] == "hello"
    assert payload["attachments"] == []


def test_long_prompt_uses_text_attachments():
    prompt = "x" * 150_000
    payload = BiroAPI._build_prompt_payload(prompt, "biro-mini")
    assert len(payload["attachments"]) == 2
    decoded = "".join(base64.b64decode(x["data_base64"]).decode() for x in payload["attachments"])
    assert decoded == prompt
    assert payload["provider"] == "biro-mini"


def test_backend_request_limit_is_reported_not_truncated():
    # The server's attachment schema is still a contract boundary; the CLI must
    # report it honestly rather than silently cut the prompt.
    with pytest.raises(BiroAPIError, match="320,000 characters"):
        BiroAPI._build_prompt_payload("x" * 320_001, "biro-max")


def test_login_sends_credentials_and_persists_token(tmp_path):
    config = UserConfig(api_url="https://api.example", access_token="")
    # Route config into the temporary directory.
    import os
    old = os.environ.get("BIRO_CONFIG_DIR")
    os.environ["BIRO_CONFIG_DIR"] = str(tmp_path / "cfg")
    try:
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.url.path == "/api/v1/auth/login"
            assert request.headers.get("authorization") is None
            return httpx.Response(200, json={"access_token": "token-value", "user": {"email": "x@example.com", "display_name": "X"}})
        client = httpx.Client(base_url="https://api.example/", transport=httpx.MockTransport(handler))
        api = BiroAPI(config, client)
        api.login("x@example.com", "longpassword")
        assert config.access_token == "token-value"
        path = tmp_path / "cfg" / "config.json"
        assert path.exists()
        assert path.stat().st_mode & 0o077 == 0
        api.close()
    finally:
        if old is None:
            os.environ.pop("BIRO_CONFIG_DIR", None)
        else:
            os.environ["BIRO_CONFIG_DIR"] = old


def test_stream_message_uses_backend_contract_and_bearer_auth():
    config = UserConfig(api_url="https://api.example", access_token="session-token")
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.method == "POST"
        assert request.url.path == "/api/v1/chats/chat-1/messages/stream"
        assert request.headers["authorization"] == "Bearer session-token"
        data = __import__("json").loads(request.content)
        assert data["provider"] == "biro-max"
        assert data["instructions"].startswith("You are BIRO")
        body = (
            '{"type":"delta","text":"Hello"}\n'
            '{"type":"done","assistant_message":{"content":"Hello"}}\n'
        )
        return httpx.Response(200, content=body, headers={"content-type": "application/x-ndjson"})
    client = httpx.Client(base_url="https://api.example/", transport=httpx.MockTransport(handler))
    api = BiroAPI(config, client)
    events = list(api.stream_message("chat-1", "hi", "biro-max", instructions="You are BIRO"))
    assert [event["type"] for event in events] == ["delta", "done"]
    client.close()


def test_api_error_detail_is_readable():
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(401, json={"detail": "Please sign in to continue."})
    client = httpx.Client(base_url="https://api.example/", transport=httpx.MockTransport(handler))
    api = BiroAPI(UserConfig(api_url="https://api.example", access_token="bad"), client)
    with pytest.raises(BiroAPIError, match="session is invalid"):
        api.me()
    client.close()


def test_image_generation_and_download_use_existing_chat_artifact_endpoints():
    config = UserConfig(api_url="https://api.example", access_token="jwt")
    seen = []
    def handler(request: httpx.Request) -> httpx.Response:
        seen.append((request.method, request.url.path))
        assert request.headers["authorization"] == "Bearer jwt"
        if request.method == "POST":
            assert request.url.path == "/api/v1/chats/chat-1/images"
            assert __import__("json").loads(request.content) == {"prompt": "mint bicycle"}
            return httpx.Response(200, json={"artifact": {"id": "art-1", "filename": "biro-flux-a1.png"}})
        assert request.url.path == "/api/v1/chats/chat-1/artifacts/art-1/download"
        return httpx.Response(200, content=b"PNGDATA", headers={"content-type": "image/png"})
    client = httpx.Client(base_url="https://api.example/", transport=httpx.MockTransport(handler))
    api = BiroAPI(config, client)
    try:
        result = api.generate_image("chat-1", "mint bicycle")
        data, mime = api.download_artifact("chat-1", result["artifact"]["id"])
        assert data == b"PNGDATA"
        assert mime == "image/png"
        assert seen == [
            ("POST", "/api/v1/chats/chat-1/images"),
            ("GET", "/api/v1/chats/chat-1/artifacts/art-1/download"),
        ]
    finally:
        client.close()


def test_delete_chat_calls_backend_and_clears_current_chat(tmp_path, monkeypatch):
    monkeypatch.setenv("BIRO_CONFIG_DIR", str(tmp_path / "config"))
    config = UserConfig(api_url="https://api.example", access_token="jwt", current_chat_id="chat-1")

    def handler(request: httpx.Request) -> httpx.Response:
        assert request.method == "DELETE"
        assert request.url.path == "/api/v1/chats/chat-1"
        return httpx.Response(204)

    client = httpx.Client(base_url="https://api.example/", transport=httpx.MockTransport(handler))
    api = BiroAPI(config, client)
    try:
        api.delete_chat("chat-1")
        assert config.current_chat_id == ""
        assert (tmp_path / "config" / "config.json").exists()
    finally:
        client.close()


def test_create_chat_can_leave_current_chat_unchanged():
    config = UserConfig(
        api_url="https://api.example",
        access_token="jwt",
        current_chat_id="existing-chat",
    )

    def handler(request: httpx.Request) -> httpx.Response:
        assert request.method == "POST"
        assert request.url.path == "/api/v1/chats"
        return httpx.Response(201, json={"id": "new-background-chat", "title": "Background task"})

    client = httpx.Client(base_url="https://api.example/", transport=httpx.MockTransport(handler))
    api = BiroAPI(config, client)
    try:
        chat = api.create_chat("Background task", select=False)
        assert chat["id"] == "new-background-chat"
        assert config.current_chat_id == "existing-chat"
    finally:
        client.close()


def test_maximum_large_prompt_is_preserved_without_attachment_truncation():
    prompt = "x" * 320_000
    payload = BiroAPI._build_prompt_payload(prompt, "biro-max")
    assert len(payload["attachments"]) == 4
    assert all(len(item["text_content"]) <= 80_000 for item in payload["attachments"])
    assert "".join(item["text_content"] for item in payload["attachments"]) == prompt


def test_short_prompt_keeps_local_file_attachments():
    attachment = {
        "filename": "photo.png",
        "mime_type": "image/png",
        "data_base64": base64.b64encode(b"PNGDATA").decode("ascii"),
        "vision_frames": [],
    }
    payload = BiroAPI._build_prompt_payload("Please inspect this image", "biro-max", attachments=[attachment])
    assert payload["message"] == "Please inspect this image"
    assert payload["attachments"] == [attachment]
    assert base64.b64decode(payload["attachments"][0]["data_base64"]) == b"PNGDATA"


def test_long_prompt_respects_four_attachment_total_with_files():
    attachment = {"filename": "brief.txt", "mime_type": "text/plain", "data_base64": "eA=="}
    with pytest.raises(BiroAPIError, match="four attachments"):
        BiroAPI._build_prompt_payload("x" * 240_001, "biro-max", attachments=[attachment])
