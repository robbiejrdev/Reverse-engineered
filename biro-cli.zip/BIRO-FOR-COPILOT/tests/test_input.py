from prompt_toolkit.document import Document

from biro.ui.input import SlashCompleter


def test_slash_autocomplete_recommends_models_and_file_commands():
    completer = SlashCompleter()
    choices = list(completer.get_completions(Document("/"), None))
    values = {item.text for item in choices}
    assert "/models" in values
    assert "/image" in values
    assert "/file" in values


def test_model_autocomplete_shows_model_recommendations():
    completer = SlashCompleter()
    choices = list(completer.get_completions(Document("/model mi"), None))
    assert [item.text for item in choices] == ["/model mini"]
    assert "everyday model" in str(choices[0].display_meta)


def test_composer_accepts_a_command_in_noninteractive_test(tmp_path):
    from prompt_toolkit.input import create_pipe_input
    from prompt_toolkit.output import DummyOutput

    with create_pipe_input() as pipe:
        pipe.send_text("/models\r")
        from biro.ui.input import read_input
        assert read_input("BIRO Max", tmp_path, input=pipe, output=DummyOutput()) == "/models"


def test_long_composer_text_is_sent_without_ctrl_j(tmp_path):
    from prompt_toolkit.input import create_pipe_input
    from prompt_toolkit.output import DummyOutput
    from biro.ui.input import read_input

    prompt = "a" * 300
    with create_pipe_input() as pipe:
        pipe.send_text(prompt + "\r")
        assert read_input("BIRO Max", tmp_path, input=pipe, output=DummyOutput()) == prompt


def test_ctrl_t_returns_thinking_toggle_signal(tmp_path):
    from prompt_toolkit.input import create_pipe_input
    from prompt_toolkit.output import DummyOutput
    from biro.ui.input import TOGGLE_THINK_SENTINEL, read_input

    with create_pipe_input() as pipe:
        pipe.send_bytes(b"\x14")  # Ctrl+T
        assert read_input("BIRO Max", tmp_path, input=pipe, output=DummyOutput()) == TOGGLE_THINK_SENTINEL


def test_ctrl_c_exits_composer(tmp_path):
    from prompt_toolkit.input import create_pipe_input
    from prompt_toolkit.output import DummyOutput
    from biro.ui.input import EXIT_SENTINEL, read_input

    with create_pipe_input() as pipe:
        pipe.send_bytes(b"\x03")
        assert read_input("BIRO Max", tmp_path, input=pipe, output=DummyOutput()) == EXIT_SENTINEL


def test_chat_picker_d_deletes_selected_chat_only_after_confirmation():
    from prompt_toolkit.input import create_pipe_input
    from prompt_toolkit.output import DummyOutput
    from biro.ui.input import DELETE_CHAT_SENTINEL, read_chat_picker

    chats = [{"id": "chat-1", "title": "Test chat"}]
    with create_pipe_input() as pipe:
        pipe.send_text("d")
        pipe.send_text("y")
        assert read_chat_picker(chats, input=pipe, output=DummyOutput()) == f"{DELETE_CHAT_SENTINEL}chat-1"


def test_chat_picker_delete_can_be_cancelled():
    from prompt_toolkit.input import create_pipe_input
    from prompt_toolkit.output import DummyOutput
    from biro.ui.input import NEW_CHAT_SENTINEL, read_chat_picker

    chats = [{"id": "chat-1", "title": "Test chat"}]
    with create_pipe_input() as pipe:
        pipe.send_text("d")
        pipe.send_text("x")
        pipe.send_text("n")
        assert read_chat_picker(chats, input=pipe, output=DummyOutput()) == NEW_CHAT_SENTINEL


def test_ctrl_c_exits_chat_picker():
    from prompt_toolkit.input import create_pipe_input
    from prompt_toolkit.output import DummyOutput
    from biro.ui.input import EXIT_SENTINEL, read_chat_picker

    with create_pipe_input() as pipe:
        pipe.send_bytes(b"\x03")
        assert read_chat_picker([], input=pipe, output=DummyOutput()) == EXIT_SENTINEL


def test_input_has_no_details_slash_command():
    from biro.ui.input import COMMANDS

    assert "/details" not in COMMANDS


def test_each_activity_entry_can_expand_independently():
    from biro.ui import input as input_ui

    details = [
        {"kind": "command", "title": "List files", "command": "find src -type f", "content": "src/main.py"},
    ]
    fragments = input_ui._activity_formatted_text(details, {0}, lambda _index: None)
    rendered = "".join(fragment[1] for fragment in fragments)
    assert "EXECUTING SHELL · List files" in rendered
    assert "$ find src -type f" in rendered
    assert "src/main.py" in rendered
    assert any(fragment[0] == "class:activity.command" for fragment in fragments)


def test_activity_mouse_click_dispatch_toggles_shell_output(monkeypatch):
    from prompt_toolkit.data_structures import Point
    from prompt_toolkit.layout.controls import FormattedTextControl
    from prompt_toolkit.mouse_events import MouseButton, MouseEvent, MouseEventType
    from biro.ui import input as input_ui

    details = [
        {"kind": "command", "title": "List files", "command": "find src -type f", "content": "src/main.py"},
    ]
    expanded = set()
    monkeypatch.setattr(input_ui, "get_app", lambda: type("App", (), {"invalidate": lambda self: None})())
    control = FormattedTextControl(
        lambda: input_ui._activity_formatted_text(
            details,
            expanded,
            lambda index: input_ui._activity_toggle_handler(expanded, index),
        ),
        focusable=True,
    )
    control.create_content(width=80, height=2)
    control.mouse_handler(
        MouseEvent(
            position=Point(x=2, y=0),
            event_type=MouseEventType.MOUSE_UP,
            button=MouseButton.LEFT,
            modifiers=frozenset(),
        )
    )
    assert expanded == {0}
    assert "src/main.py" in "".join(
        fragment[1]
        for fragment in input_ui._activity_formatted_text(details, expanded, lambda _index: None)
    )
    control.mouse_handler(
        MouseEvent(
            position=Point(x=2, y=0),
            event_type=MouseEventType.MOUSE_UP,
            button=MouseButton.LEFT,
            modifiers=frozenset(),
        )
    )
    assert expanded == set()
