import re

from rich.console import Console

from biro.ui.diff import print_file_diff


def test_file_diff_is_line_numbered_syntax_highlighted_and_limited_to_ten_lines():
    before = "\n".join(f"answer_{index} = {index}" for index in range(1, 16))
    after = "\n".join(f"answer_{index} = {index + 100}" for index in range(1, 16))
    console = Console(record=True, width=120, force_terminal=True, color_system="truecolor")

    print_file_diff(console, "sample.py", before, after)

    styled_output = console.export_text(styles=True)
    output = re.sub(r"\x1b\[[0-9;]*m", "", styled_output)
    changed_lines = [line for line in output.splitlines() if re.search(r"[+-]\s+\d+ │ ", line)]
    assert len(changed_lines) == 10
    assert "-    1 │" in output
    assert "+   15 │" in output
    assert "20 changed lines omitted" in output
    assert "48;2;67;42;53" in styled_output
    assert "48;2;24;60;48" in styled_output
    assert "DIFF · sample.py · +15 −15" in output
