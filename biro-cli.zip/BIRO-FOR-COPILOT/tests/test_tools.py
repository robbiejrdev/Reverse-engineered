from pathlib import Path

from biro.agent.tools import WorkspaceTools, parse_tool_block, split_tool_blocks


def test_parse_shell_multiline_tool():
    block = parse_tool_block("""title: Run tests
action: shell
---
python -m pytest -q
python -m compileall src""")
    assert block is not None
    assert block["action"] == "shell"
    assert block["cmd"] == "python -m pytest -q\npython -m compileall src"


def test_parse_write_file_preserves_body():
    block = parse_tool_block("""title: Create file
action: write_file
path: src/thing.py
---
print('---')
print('hello')""")
    assert block is not None
    assert block["body"] == "print('---')\nprint('hello')"


def test_split_tool_blocks_keeps_prose_and_parses_action():
    prose, blocks = split_tool_blocks("I will inspect the project.\n```tool\ntitle: List files\naction: shell\ncmd: ls\n```\nDone")
    assert "I will inspect the project." in prose
    assert "Done" in prose
    assert len(blocks) == 1
    assert blocks[0]["cmd"] == "ls"


def test_workspace_resolves_paths_outside_launch_directory(tmp_path: Path):
    outside = tmp_path.parent / (tmp_path.name + "-outside.txt")
    tools = WorkspaceTools(tmp_path)
    assert tools.resolve_path("../" + outside.name) == outside.resolve()


def test_workspace_root_is_a_valid_path(tmp_path: Path):
    tools = WorkspaceTools(tmp_path)
    assert tools.resolve_path(".") == tmp_path.resolve()


def test_workspace_path_resolution_follows_symlinks(tmp_path: Path):
    workspace = tmp_path / "workspace"
    outside = tmp_path / "outside"
    workspace.mkdir()
    outside.mkdir()
    target = outside / "secret.txt"
    target.write_text("private", encoding="utf-8")
    link = workspace / "secret.txt"
    link.symlink_to(target)
    tools = WorkspaceTools(workspace)
    assert tools.resolve_path("secret.txt") == target.resolve()


def test_delete_path_removes_symlink_without_deleting_its_target(tmp_path: Path):
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    target = tmp_path / "important.txt"
    target.write_text("keep me", encoding="utf-8")
    link = workspace / "link.txt"
    link.symlink_to(target)

    result = WorkspaceTools(workspace).delete_path("link.txt", "Remove link")

    assert "Deleted file/link" in result
    assert not link.exists()
    assert target.read_text(encoding="utf-8") == "keep me"


def test_web_search_is_a_callable_workspace_action(monkeypatch, tmp_path: Path):
    from biro.agent.tools import parse_json_action

    action = parse_json_action(
        '{"action":"web_search","query":"latest launch","max_results":3,"fresh":true}'
    )
    assert action == {
        "title": "Search the web",
        "action": "web_search",
        "path": "",
        "cmd": "",
        "body": "",
        "prompt": "",
        "query": "latest launch",
        "max_results": 3,
        "fresh": True,
    }

    def search(query, *, max_results, fresh):
        assert (query, max_results, fresh) == ("latest launch", 3, True)
        return {
            "query": query,
            "results": [{
                "title": "Launch update",
                "url": "https://example.com/launch",
                "content": "A concise result.",
                "score": 0.9,
                "published_date": "2026-10-26",
            }],
        }

    tools = WorkspaceTools(tmp_path)
    monkeypatch.setattr(tools.web_search, "search", search)
    result = tools.execute(action)
    assert "CURRENT DATE AND TIME (UTC):" in result
    assert "PUBLISHED: 2026-10-26" in result
    assert "SNIPPET: A concise result." in result


def test_large_file_read_is_not_cut_off_by_a_cli_character_cap(tmp_path: Path):
    path = tmp_path / "large.txt"
    content = "x" * 300_000
    path.write_text(content, encoding="utf-8")
    result = WorkspaceTools(tmp_path).read_file("large.txt", "Read large file")
    assert result == content


def test_shell_output_is_not_cut_off_by_a_cli_character_cap(tmp_path: Path):
    tools = WorkspaceTools(tmp_path, auto_approve=True)
    output = tools.run_shell("python -c \"print('x' * 300000)\"", "Large output test")
    assert "x" * 300_000 in output
    assert "exit code: 0" in output
    assert "output truncated" not in output


def test_unattended_shell_action_runs_without_approval_prompt(tmp_path: Path):
    tools = WorkspaceTools(tmp_path)
    output = tools.run_shell("python -c \"print('ready')\"", "Quick check")
    assert "ready" in output
    assert "exit code: 0" in output


def test_long_running_shell_action_is_not_cut_off_by_fixed_timeout(tmp_path: Path):
    tools = WorkspaceTools(tmp_path)
    output = tools.run_shell("python -c \"import time; time.sleep(2.05); print('finished')\"", "Long job")
    assert "finished" in output
    assert "process completed normally" not in output
    assert "runtime:" in output


def test_parse_json_image_action():
    from biro.agent.tools import parse_json_action

    action = parse_json_action('''{
      "action": "generate_image",
      "title": "Create hero art",
      "prompt": "A minimal mint and black hero illustration",
      "path": "public/images/hero.png"
    }''')
    assert action is not None
    assert action["action"] == "generate_image"
    assert action["path"] == "public/images/hero.png"
    assert action["prompt"].startswith("A minimal")


def test_split_json_action_out_of_assistant_text():
    response = '''I'll generate an asset.
```biro-action
{"action":"generate_image","prompt":"a mint abstract shape","path":"public/images/shape.png"}
```
I'll use the saved path in the component.'''
    prose, actions = split_tool_blocks(response)
    assert len(actions) == 1
    assert actions[0]["action"] == "generate_image"
    assert "I'll generate an asset." in prose
    assert "I'll use the saved path" in prose


def test_ordinary_json_code_example_is_not_misclassified_as_action():
    from biro.agent.tools import has_malformed_action

    response = 'Here is JSON:\n```json\n{"name":"BIRO","enabled":true}\n```'
    assert not has_malformed_action(response)


def test_incomplete_action_marker_is_detected_for_repair():
    from biro.agent.tools import has_malformed_action

    assert has_malformed_action('I will run this:\n```tool\ntitle: incomplete')
    assert has_malformed_action('```json\n{"action": "write_file", "path":')


def test_unclosed_legacy_action_fence_is_recovered():
    response = """Completed: Check project structure and create missing video_editor.cpp
```tool
title: Check project structure
action: shell
cmd: find src -type f
"""
    prose, actions = split_tool_blocks(response)
    assert prose.strip().startswith("Completed:")
    assert len(actions) == 1
    assert actions[0]["action"] == "shell"
    assert actions[0]["cmd"] == "find src -type f"


def test_brace_expansion_is_rejected_as_an_action_path():
    from biro.agent.tools import parse_json_action

    assert parse_json_action(
        '{"action":"write_file","path":"{src,include,tests,examples}/video_editor.cpp","body":"source"}'
    ) is None


def test_workspace_tools_use_the_launch_directory(tmp_path: Path):
    workspace = tmp_path / "website"
    workspace.mkdir()
    tools = WorkspaceTools(workspace)
    result = tools.run_shell("pwd", "Show active workspace")
    assert str(workspace.resolve()) in result
    assert tools.cwd == workspace.resolve()


def test_json_action_accepts_nested_tool_call_and_preserves_long_multiline_prompt():
    from biro.agent.tools import parse_json_action

    prompt = "Create a polished product hero with exact lighting and composition.\n" + ("detail " * 12000)
    import json
    source = json.dumps({
        "name": "generate_image",
        "arguments": {"title": "Create product art", "prompt": prompt, "path": "public/images/product.webp"},
    })
    parsed = parse_json_action(source)
    assert parsed is not None
    assert parsed["action"] == "generate_image"
    assert parsed["prompt"] == prompt


def test_bare_json_action_is_detected_and_removed():
    response = 'I am generating this asset now. {"action":"generate_image","prompt":"long prompt","path":"public/images/hero.png"} I will use it in the page.'
    prose, actions = split_tool_blocks(response)
    assert len(actions) == 1
    assert actions[0]["prompt"] == "long prompt"
    assert "generating this asset" in prose
    assert "use it in the page" in prose


def test_plain_json_with_name_field_is_not_treated_as_malformed_action():
    from biro.agent.tools import has_malformed_action

    response = 'Here is JSON:\n```json\n{"name":"BIRO","enabled":true}\n```'
    assert not has_malformed_action(response)


def test_json_action_with_very_long_prompt_is_not_parser_truncated():
    import json
    from biro.agent.tools import split_tool_blocks

    prompt = "scene detail\n" + ("keep every visual detail in order; " * 7000)
    source = json.dumps({"action": "generate_image", "prompt": prompt, "path": "public/images/long.png"})
    response = "```biro-action\n" + source + "\n```"
    prose, actions = split_tool_blocks(response)
    assert prose == ""
    assert len(actions) == 1
    assert actions[0]["prompt"] == prompt
