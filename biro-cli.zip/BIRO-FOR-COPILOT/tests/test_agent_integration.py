import json

import httpx

from biro.agent.runner import Agent
from biro.api.client import BiroAPI
from biro.config import UserConfig


def test_agent_creates_saves_and_streams_a_backend_conversation(tmp_path, monkeypatch):
    monkeypatch.setenv("BIRO_CONFIG_DIR", str(tmp_path / "config"))
    config = UserConfig(api_url="https://api.example", access_token="jwt-token", email="user@example.com", model="biro-max")
    observed = {"stream": False, "title": None}

    def handler(request: httpx.Request) -> httpx.Response:
        assert request.headers.get("authorization") == "Bearer jwt-token"
        if request.method == "POST" and request.url.path == "/api/v1/chats":
            return httpx.Response(201, json={"id": "chat-1", "title": "New conversation"})
        if request.method == "GET" and request.url.path == "/api/v1/chats/chat-1/messages":
            return httpx.Response(200, json=[])
        if request.method == "PATCH" and request.url.path == "/api/v1/chats/chat-1":
            body = json.loads(request.content)
            observed["title"] = body["title"]
            return httpx.Response(200, json={"id": "chat-1", "title": body["title"]})
        if request.method == "POST" and request.url.path == "/api/v1/chats/chat-1/messages/stream":
            body = json.loads(request.content)
            assert body["provider"] == "biro-max"
            assert "action protocol" in body["instructions"].lower()
            observed["stream"] = True
            return httpx.Response(
                200,
                content='{"type":"delta","text":"Done."}\n{"type":"done","assistant_message":{"content":"Done."}}\n',
                headers={"content-type": "application/x-ndjson"},
            )
        raise AssertionError(f"Unexpected request: {request.method} {request.url}")

    client = httpx.Client(base_url="https://api.example/", transport=httpx.MockTransport(handler))
    api = BiroAPI(config, client)
    try:
        agent = Agent(api, config, tmp_path, auto_approve=True)
        assert agent.send("Please inspect the project") == 0
        assert observed["stream"] is True
        assert observed["title"] == "Please inspect the project"
        assert config.current_chat_id == "chat-1"
    finally:
        client.close()


def test_ctrl_c_hands_interrupted_turn_to_background_in_same_chat(tmp_path, monkeypatch, capsys):
    import biro.background

    config = UserConfig(
        api_url="https://api.example",
        access_token="token",
        model="biro-max",
        current_chat_id="chat-active",
    )
    started = {}

    def start_task(prompt, cwd, chat_id):
        started.update(prompt=prompt, cwd=cwd, chat_id=chat_id)
        return {"id": "job-1"}

    monkeypatch.setattr(biro.background, "start_task", start_task)

    class InterruptedAPI:
        agent = None

        def get_chat(self, chat_id):
            return {"id": chat_id, "title": "Active conversation"}

        def stream_message(self, *_args, **_kwargs):
            yield {"type": "delta", "text": "partial response " * 12}
            self.agent.detach()
            yield {"type": "interrupted"}

    api = InterruptedAPI()
    agent = Agent(api, config, tmp_path)
    api.agent = agent

    assert agent.send("Finish the implementation") == 0
    assert agent.detached is True
    assert started["chat_id"] == "chat-active"
    assert started["cwd"] == tmp_path.resolve()
    assert "Finish the implementation" in started["prompt"]
    output = capsys.readouterr().out
    assert "Tokens used: approximately" in output
    assert agent.reported_tokens_used == 0
    assert agent.token_usage_complete is False
    assert agent.session_token_count == (len("Finish the implementation") + len("partial response " * 12) + 3) // 4
    assert agent.session_token_count_approximate is True


def test_agent_reports_backend_token_usage_only(tmp_path, monkeypatch, capsys):
    import biro.background
    from biro.agent.runner import _reported_token_count

    assert _reported_token_count({"usage": {"prompt_tokens": 13, "completion_tokens": 7}}) == 20
    assert _reported_token_count({"usage": {"total_tokens": 31}}) == 31
    assert _reported_token_count({"usage": {"prompt_tokens": 13}}) is None

    config = UserConfig(
        api_url="https://api.example",
        access_token="token",
        model="biro-max",
        current_chat_id="chat-usage",
    )
    monkeypatch.setattr(
        biro.background,
        "start_task",
        lambda _prompt, _cwd, _chat_id: {"id": "job-usage"},
    )

    class UsageAPI:
        agent = None

        def get_chat(self, chat_id):
            return {"id": chat_id, "title": "Existing conversation"}

        def stream_message(self, *_args, **_kwargs):
            yield {"type": "delta", "text": "Done."}
            yield {
                "type": "done",
                "assistant_message": {"content": "Done."},
                "usage": {"prompt_tokens": 13, "completion_tokens": 7},
            }
            self.agent.detach()
            yield {"type": "interrupted"}

    api = UsageAPI()
    agent = Agent(api, config, tmp_path)
    api.agent = agent
    assert agent.send("Do it") == 0
    assert agent.reported_tokens_used == 20
    assert agent.token_usage_complete is True
    assert agent.session_token_count == 20
    assert agent.session_token_count_approximate is False
    assert "Tokens used: 20" in capsys.readouterr().out


def test_agent_tracks_added_and_deleted_lines_for_exit_summary(tmp_path):
    config = UserConfig(
        api_url="https://api.example",
        access_token="token",
        model="biro-max",
        current_chat_id="chat-diff",
    )
    (tmp_path / "example.py").write_text("old = 1\n", encoding="utf-8")
    responses = [
        '```biro-action\n{"action":"write_file","path":"example.py","body":"new = 2\\nextra = 3\\n"}\n```',
        "Updated the file.",
    ]

    class DiffAPI:
        def get_chat(self, chat_id):
            return {"id": chat_id, "title": "Existing conversation"}

        def stream_message(self, *_args, **_kwargs):
            response = responses.pop(0)
            yield {"type": "delta", "text": response}
            yield {"type": "done", "assistant_message": {"content": response}}

    agent = Agent(DiffAPI(), config, tmp_path)
    assert agent.send("Update the file") == 0
    assert agent.session_lines_added == 2
    assert agent.session_lines_deleted == 1


def test_agent_continues_after_web_search_failure(tmp_path, monkeypatch, capsys):
    from biro.agent.search import TavilySearch

    monkeypatch.setenv("BIRO_CONFIG_DIR", str(tmp_path / "config"))
    monkeypatch.setattr(
        TavilySearch,
        "search",
        lambda *_args, **_kwargs: {"error": "HTTP 429: rate limited"},
    )
    config = UserConfig(
        api_url="https://api.example",
        access_token="token",
        model="biro-max",
        current_chat_id="chat-search",
    )

    class SearchAPI:
        calls = []

        def get_chat(self, chat_id):
            return {"id": chat_id, "title": "Existing conversation"}

        def stream_message(self, chat_id, prompt, model, instructions="", attachments=None):
            self.calls.append(prompt)
            content = (
                '```biro-action\n{"action":"web_search","query":"current news"}\n```'
                if len(self.calls) == 1
                else "I could not verify current information because search was rate-limited."
            )
            yield {"type": "delta", "text": content}
            yield {"type": "done", "assistant_message": {"content": content}}

    api = SearchAPI()
    agent = Agent(api, config, tmp_path)

    assert agent.send("Find current news") == 0
    assert len(api.calls) == 2
    assert "HTTP 429" in api.calls[1]
    assert "could not verify" in capsys.readouterr().out.lower()


def test_image_action_downloads_artifact_and_saves_into_workspace(tmp_path, monkeypatch):
    from pathlib import Path

    class ImageAPI:
        def generate_image(self, chat_id, prompt):
            assert chat_id == "chat-img"
            assert prompt == "mint geometric hero art"
            return {"artifact": {"id": "artifact-1", "filename": "biro-flux.png"}}

        def download_artifact(self, chat_id, artifact_id):
            assert chat_id == "chat-img"
            assert artifact_id == "artifact-1"
            return b"fake-jpeg-bytes", "image/jpeg"

    monkeypatch.setenv("BIRO_CONFIG_DIR", str(tmp_path / "config"))
    config = UserConfig(api_url="https://api.example", access_token="token", model="biro-max")
    agent = Agent(ImageAPI(), config, tmp_path)
    result = agent._execute_action({
        "action": "generate_image",
        "title": "Make a hero image",
        "prompt": "mint geometric hero art",
        "path": "public/images/hero.png",
    }, "chat-img")
    saved = tmp_path / "public/images/hero.jpg"
    assert saved.read_bytes() == b"fake-jpeg-bytes"
    assert "Written" in result and "hero.jpg" in result
    assert not (tmp_path / "public/images/hero.png").exists()


def test_unclosed_valid_action_is_recovered_without_protocol_repair(tmp_path, monkeypatch, capsys):
    from biro.agent.prompts import SYSTEM_PROMPT

    monkeypatch.setenv("BIRO_CONFIG_DIR", str(tmp_path / "config"))
    config = UserConfig(api_url="https://api.example", access_token="jwt-token", model="biro-max", current_chat_id="chat-1")

    class RepairAPI:
        calls = []

        def get_chat(self, chat_id):
            return {"id": chat_id, "title": "Existing conversation"}

        def stream_message(self, chat_id, prompt, model, instructions="", attachments=None):
            self.calls.append({"prompt": prompt, "instructions": instructions})
            if len(self.calls) == 1:
                content = "```tool\ntitle: Broken action\naction: shell\ncmd: pwd"
            else:
                content = "I recovered the action protocol and can continue."
            yield {"type": "delta", "text": content}
            yield {"type": "done", "assistant_message": {"content": content}}

    api = RepairAPI()
    agent = Agent(api, config, tmp_path)
    assert agent.send("Inspect and fix the project") == 0
    assert len(api.calls) == 2
    assert "ACTION_PROTOCOL_REPAIR" not in api.calls[1]["prompt"]
    assert "Local tool result: Broken action" in api.calls[1]["prompt"]
    assert "Completed  Broken action" in capsys.readouterr().out
    formatted_prompt = SYSTEM_PROMPT.format(cwd=str(tmp_path), model_label="BIRO Max")
    assert len(formatted_prompt) <= 4000  # matches backend's instruction field limit
    assert "generate_image" in formatted_prompt
    assert "For every file creation or edit, use the `write_file` action" in formatted_prompt
    assert "cat <<EOF" in formatted_prompt
    assert "comma-separated brace lists" in formatted_prompt


def test_background_research_prompt_encourages_thoroughness(tmp_path, monkeypatch):
    from biro.agent.runner import Agent

    monkeypatch.setenv("BIRO_CONFIG_DIR", str(tmp_path / "config"))
    config = UserConfig(api_url="https://api.example", access_token="token", model="biro-max")

    class NoNetworkAPI:
        pass

    prompt = Agent(NoNetworkAPI(), config, tmp_path, deep_research=True).system_prompt()
    assert "Do not rush" in prompt
    assert "verify the implementation" in prompt
    assert "avoid repeated inspections" in prompt
    assert "BIRO_BACKGROUND_COMPLETE" in prompt
    assert len(prompt) <= 4000


def test_background_progress_message_does_not_finish_job_without_marker(tmp_path, monkeypatch, capsys):
    monkeypatch.setenv("BIRO_CONFIG_DIR", str(tmp_path / "config"))
    config = UserConfig(
        api_url="https://api.example",
        access_token="token",
        model="biro-max",
        current_chat_id="chat-1",
    )

    class ProgressAPI:
        calls = []

        def get_chat(self, chat_id):
            return {"id": chat_id, "title": "Weather app"}

        def stream_message(self, chat_id, prompt, model, instructions="", attachments=None):
            self.calls.append(prompt)
            content = (
                "Let me inspect the existing files and requirements."
                if len(self.calls) == 1
                else "The work is complete and verified.\nBIRO_BACKGROUND_COMPLETE"
            )
            yield {"type": "delta", "text": content}
            yield {"type": "done", "assistant_message": {"content": content}}

    api = ProgressAPI()

    assert Agent(api, config, tmp_path, deep_research=True).send("Build the project") == 0
    assert len(api.calls) == 2
    assert "BACKGROUND_TASK_INCOMPLETE" in api.calls[1]
    assert "BIRO_BACKGROUND_COMPLETE" not in capsys.readouterr().out


def test_background_job_fails_if_model_never_confirms_completion(tmp_path, monkeypatch, capsys):
    monkeypatch.setenv("BIRO_CONFIG_DIR", str(tmp_path / "config"))
    config = UserConfig(
        api_url="https://api.example",
        access_token="token",
        model="biro-max",
        current_chat_id="chat-1",
    )

    class NeverDoneAPI:
        calls = 0

        def get_chat(self, chat_id):
            return {"id": chat_id, "title": "Existing conversation"}

        def stream_message(self, *args, **kwargs):
            self.calls += 1
            content = "I am still working on it."
            yield {"type": "delta", "text": content}
            yield {"type": "done", "assistant_message": {"content": content}}

    api = NeverDoneAPI()

    assert Agent(api, config, tmp_path, deep_research=True).send("Finish this") == 1
    assert api.calls == 5
    assert "marked failed rather than complete" in capsys.readouterr().out


def test_background_completion_retries_reset_after_model_makes_progress(tmp_path, monkeypatch):
    monkeypatch.setenv("BIRO_CONFIG_DIR", str(tmp_path / "config"))
    config = UserConfig(
        api_url="https://api.example",
        access_token="token",
        model="biro-max",
        current_chat_id="chat-1",
    )
    shell_action = (
        '```biro-action\n{"action":"shell","cmd":"printf progress"}\n```'
    )
    responses = [
        "I am reviewing the project structure.",
        "I am checking the requirements.",
        "I am locating the implementation files.",
        shell_action,
        "I am continuing with the requested implementation.",
        "I am checking the remaining details.",
        "I am validating the current changes.",
        "I will now perform the next implementation step.",
        shell_action,
        "The requested work is complete.\nBIRO_BACKGROUND_COMPLETE",
    ]

    class ProgressAPI:
        def get_chat(self, chat_id):
            return {"id": chat_id, "title": "Existing conversation"}

        def stream_message(self, *args, **kwargs):
            content = responses.pop(0)
            yield {"type": "delta", "text": content}
            yield {"type": "done", "assistant_message": {"content": content}}

    assert Agent(ProgressAPI(), config, tmp_path, deep_research=True).send("Finish this task") == 0
    assert responses == []


def test_resumed_chat_history_is_rendered(tmp_path, monkeypatch, capsys):
    import biro.cli as cli

    monkeypatch.setenv("BIRO_CONFIG_DIR", str(tmp_path / "config"))

    class HistoryAPI:
        def list_messages(self, chat_id):
            assert chat_id == "chat-history"
            return [
                {"role": "user", "content": "Earlier request"},
                {"role": "assistant", "content": "Earlier response"},
            ]

    cli._show_chat_history(HistoryAPI(), "chat-history")
    output = capsys.readouterr().out
    assert "Earlier request" in output
    assert "Earlier response" in output


def test_thinking_mode_never_prints_provider_reasoning_or_embedded_system_prompt(tmp_path, monkeypatch, capsys):
    monkeypatch.setenv("BIRO_CONFIG_DIR", str(tmp_path / "config"))
    config = UserConfig(api_url="https://api.example", access_token="token", model="biro-max", current_chat_id="chat-1")

    class ThinkingAPI:
        def get_chat(self, chat_id):
            return {"id": chat_id, "title": "Existing conversation"}

        def stream_message(self, *args, **kwargs):
            yield {"type": "thinking", "text": "PRIVATE_INTERNAL_PROMPT_SHOULD_NEVER_APPEAR"}
            yield {"type": "delta", "text": "The task is complete."}
            yield {"type": "done", "assistant_message": {
                "content": "The task is complete.",
                "thinking": "PRIVATE_INTERNAL_PROMPT_SHOULD_NEVER_APPEAR",
            }}

    agent = Agent(ThinkingAPI(), config, tmp_path, think=True)
    assert agent.send("Finish the task") == 0
    output = capsys.readouterr().out
    assert "The task is complete." in output
    assert "PRIVATE_INTERNAL_PROMPT_SHOULD_NEVER_APPEAR" not in output


def test_image_generation_upstream_error_stops_without_fabricating_svg_fallback(tmp_path, monkeypatch, capsys):
    from biro.api.client import BiroAPIError

    monkeypatch.setenv("BIRO_CONFIG_DIR", str(tmp_path / "config"))
    config = UserConfig(api_url="https://api.example", access_token="token", model="biro-max", current_chat_id="chat-img")

    class ImageFailureAPI:
        stream_calls = 0

        def get_chat(self, chat_id):
            return {"id": chat_id, "title": "Existing conversation"}

        def stream_message(self, *args, **kwargs):
            self.stream_calls += 1
            response = '''```biro-action
{"action":"generate_image","title":"Generate process illustration","prompt":"Detailed bisque firing illustration","path":"sally-web/assets/process-bisque.png"}
```'''
            yield {"type": "delta", "text": response}
            yield {"type": "done", "assistant_message": {"content": response}}

        def generate_image(self, chat_id, prompt):
            raise BiroAPIError("BIRO could not generate this image. Please retry shortly.", 502)

    api = ImageFailureAPI()
    agent = Agent(api, config, tmp_path)
    assert agent.send("Generate the illustration") == 1
    assert api.stream_calls == 1
    output = capsys.readouterr().out
    assert "HTTP 502" in output
    assert "No placeholder image was written" in output
    assert not (tmp_path / "sally-web/assets/process-bisque.svg").exists()


def test_final_message_restores_content_missing_from_stream_deltas(tmp_path, monkeypatch, capsys):
    monkeypatch.setenv("BIRO_CONFIG_DIR", str(tmp_path / "config"))
    config = UserConfig(api_url="https://api.example", access_token="token", model="biro-max", current_chat_id="chat-1")
    full_response = "The complete response includes every section, including the final verification and next steps."

    class PartialStreamAPI:
        def get_chat(self, chat_id):
            return {"id": chat_id, "title": "Existing conversation"}

        def stream_message(self, *args, **kwargs):
            yield {"type": "delta", "text": "The complete response includes every section"}
            yield {"type": "done", "assistant_message": {"content": full_response}}

    assert Agent(PartialStreamAPI(), config, tmp_path).send("Finish the response") == 0
    assert full_response in capsys.readouterr().out


def test_dashboard_renders_without_missing_rich_symbols(tmp_path, monkeypatch):
    from rich.console import Console
    from biro.agent.runner import _AgentDashboard

    monkeypatch.setenv("BIRO_CONFIG_DIR", str(tmp_path / "config"))
    config = UserConfig(api_url="https://api.example", access_token="token", model="biro-max")

    class NoNetworkAPI:
        pass

    agent = Agent(NoNetworkAPI(), config, tmp_path, think=True)
    agent._active_started = 1.0
    agent.working_title = "Inspect project files"
    agent.thinking_title = "Mapping project structure"
    console = Console(record=True, width=100, force_terminal=False)
    console.print(_AgentDashboard(agent))
    output = console.export_text()
    assert "WORKSPACE" in output
    assert "BIRO MAX" in output
    assert "Mapping project structure" in output
    assert "Inspect project files" in output


def test_stream_preview_shows_live_text_but_hides_action_payloads():
    from biro.agent.runner import _safe_stream_preview

    assert _safe_stream_preview("BIRO is streaming this sentence") == "BIRO is streaming this sentence"
    assert _safe_stream_preview("I will inspect the project.\n```biro-act") == "I will inspect the project."
    assert _safe_stream_preview(
        'I will inspect the project.\n```biro-action\n{"action":"shell","cmd":"rm -rf /"}\n```'
    ) == "I will inspect the project."
    assert _safe_stream_preview('{"action":"shell","cmd":"secret command"}') == ""


def test_live_dashboard_is_transient_and_redraws_stream_deltas(tmp_path, monkeypatch):
    import biro.agent.runner as runner

    monkeypatch.setenv("BIRO_CONFIG_DIR", str(tmp_path / "config"))
    monkeypatch.setattr(runner.console, "_force_terminal", True)
    config = UserConfig(
        api_url="https://api.example", access_token="token", model="biro-max",
        current_chat_id="chat-live",
    )
    observed = {"transient": None, "previews": []}

    class FakeLive:
        def __init__(self, renderable, **kwargs):
            observed["transient"] = kwargs.get("transient")
            self.renderable = renderable

        def __enter__(self):
            return self

        def __exit__(self, *args):
            return False

        def update(self, renderable, refresh=False):
            self.renderable = renderable
            observed["previews"].append(renderable.agent.stream_preview)

    monkeypatch.setattr(runner, "Live", FakeLive)

    class StreamingAPI:
        def get_chat(self, chat_id):
            return {"id": chat_id, "title": "Existing conversation"}

        def stream_message(self, *args, **kwargs):
            yield {"type": "delta", "text": "First "}
            yield {"type": "delta", "text": "streamed "}
            yield {"type": "delta", "text": "answer."}
            yield {"type": "done", "assistant_message": {"content": "First streamed answer."}}

    result = runner.Agent(StreamingAPI(), config, tmp_path).send("Test streaming")
    assert result == 0
    assert observed["transient"] is True
    assert "First" in observed["previews"]
    assert "First streamed" in observed["previews"]
    assert "First streamed answer." in observed["previews"]
    assert observed["previews"][-1] == ""
