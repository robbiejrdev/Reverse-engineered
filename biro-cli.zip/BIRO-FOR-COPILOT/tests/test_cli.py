from pathlib import Path
from types import SimpleNamespace

import pytest

from biro.cli import parse_slash_command


def test_parse_slash_command_accepts_integrations_without_arguments():
    assert parse_slash_command("/integrations") == ("integrations", "")


def test_parse_slash_command_preserves_arguments():
    assert parse_slash_command(" /open chat-123  ") == ("open", "chat-123")


def test_parse_slash_command_ignores_empty_slash_input():
    assert parse_slash_command("/") is None
    assert parse_slash_command(" /   ") is None


def test_help_uses_biro_program_name_and_hides_internal_limits(capsys):
    from biro.cli import build_parser

    with pytest.raises(SystemExit) as raised:
        build_parser().parse_args(["--help"])

    assert raised.value.code == 0
    help_text = capsys.readouterr().out
    assert "usage: biro " in help_text
    assert "biro-cli" not in help_text
    assert "--max-steps" not in help_text
    assert "--yes" not in help_text
    assert "--confirm" not in help_text


def test_background_job_duration_format():
    from biro.cli import _format_job_duration

    assert _format_job_duration(8.9) == "8s"
    assert _format_job_duration(75) == "1m 15s"
    assert _format_job_duration(3723) == "1h 2m 3s"


def test_jobs_clear_is_accepted_by_cli_parser():
    from biro.cli import build_parser

    args = build_parser().parse_args(["jobs", "clear"])
    assert args.auth_command == "jobs"
    assert args.chat_id == "clear"


def test_jobs_clear_dispatches_without_authentication(monkeypatch, capsys):
    import biro.cli as cli
    from biro.config import UserConfig

    api = SimpleNamespace(close=lambda: None)
    monkeypatch.setattr(cli.UserConfig, "load", classmethod(lambda cls: UserConfig()))
    monkeypatch.setattr(cli, "BiroAPI", lambda _config: api)
    monkeypatch.setattr(cli, "clear_tasks", lambda: 7)

    args = cli.build_parser().parse_args(["jobs", "clear"])
    assert cli.run_app(args) == 0
    assert "7 local files removed" in capsys.readouterr().out


def test_jobs_table_displays_completed_job_duration(monkeypatch, capsys):
    import biro.cli as cli

    monkeypatch.setattr(
        cli,
        "list_tasks",
        lambda: [{
            "id": "job-1",
            "status": "complete",
            "chat_id": "chat-1",
            "created_at": "2026-10-26T10:00:00+00:00",
            "duration_seconds": 125.4,
        }],
    )

    cli._show_background_tasks()

    rendered = capsys.readouterr().out
    assert "Duration" in rendered
    assert "2m 5s" in rendered


def test_banner_keeps_biro_logo_and_version(monkeypatch, capsys, tmp_path):
    import biro.cli as cli
    from biro.config import UserConfig

    monkeypatch.setattr(cli.Path, "cwd", lambda: tmp_path)
    cli.print_banner(UserConfig())

    rendered = capsys.readouterr().out
    assert "██████████████" in rendered
    assert "BIRO" in rendered
    assert cli.__version__ in rendered


def test_integrations_command_dispatches_without_crashing(monkeypatch, tmp_path):
    import biro.cli as cli
    from biro.config import UserConfig

    config = UserConfig(current_chat_id="chat-1")
    api = SimpleNamespace(close=lambda: None, list_messages=lambda chat_id: [])

    class FakeAgent:
            instances = []

            def __init__(self, *args, **kwargs):
                self.model_label = "BIRO Max"
                self.tools = SimpleNamespace(cwd=Path(tmp_path))
                self.message_count = 0
                self.last_elapsed = 0.0
                self.think = False
                self.detached = False
                self.sent = []
                self.details = []
                self.session_token_count = 23
                self.session_token_count_approximate = True
                self.instances.append(self)

            def send(self, prompt):
                self.sent.append(prompt)
                self.detached = True

    commands = ["/integrations", "continue request", "/exit"]
    read_calls = []
    dispatched = []
    monkeypatch.setattr(cli.UserConfig, "load", classmethod(lambda cls: config))
    monkeypatch.setattr(cli, "BiroAPI", lambda _config: api)
    monkeypatch.setattr(cli, "authenticate", lambda *_args: True)
    monkeypatch.setattr(cli, "_current_chat", lambda *_args: {"id": "chat-1"})
    monkeypatch.setattr(cli, "print_banner", lambda *_args: None)
    monkeypatch.setattr(cli, "Agent", FakeAgent)
    def fake_read_input(*_args, **_kwargs):
        read_calls.append(True)
        return commands.pop(0)

    monkeypatch.setattr(cli, "read_input", fake_read_input)
    monkeypatch.setattr(cli, "_integration_status", lambda cwd: dispatched.append(cwd))

    args = cli.build_parser().parse_args([])
    assert cli.run_app(args) == 0
    assert dispatched == [Path(tmp_path)]
    assert FakeAgent.instances[0].sent == ["continue request"]
    assert len(read_calls) == 2
    assert commands == ["/exit"]


@pytest.mark.parametrize("exit_input", ["/exit", "\x00BIRO_EXIT\x00"])
def test_exit_prints_session_token_summary(monkeypatch, tmp_path, capsys, exit_input):
    import biro.cli as cli
    from biro.config import UserConfig

    api = SimpleNamespace(close=lambda: None, list_messages=lambda _chat_id: [])

    class FakeAgent:
        def __init__(self, *_args, **_kwargs):
            self.model_label = "BIRO Max"
            self.tools = SimpleNamespace(cwd=tmp_path)
            self.message_count = 0
            self.last_elapsed = 0
            self.think = False
            self.detached = False
            self.details = []
            self.session_token_count = 47
            self.session_token_count_approximate = True
            self.session_lines_added = 4
            self.session_lines_deleted = 2

    monkeypatch.setattr(cli.UserConfig, "load", classmethod(lambda cls: UserConfig(current_chat_id="chat-1")))
    monkeypatch.setattr(cli, "BiroAPI", lambda _config: api)
    monkeypatch.setattr(cli, "authenticate", lambda *_args: True)
    monkeypatch.setattr(cli, "_current_chat", lambda *_args: {"id": "chat-1"})
    monkeypatch.setattr(cli, "print_banner", lambda *_args: None)
    monkeypatch.setattr(cli, "Agent", FakeAgent)
    monkeypatch.setattr(cli, "read_input", lambda *_args, **_kwargs: exit_input)

    assert cli.run_app(cli.build_parser().parse_args([])) == 0
    output = capsys.readouterr().out
    assert "SESSION ENDED" in output
    assert "TOKENS  47" in output
    assert "CODE DIFF  +4  -2 lines" in output
    assert "RESUME  biro chat chat-1" in output
    assert "Bye." not in output
