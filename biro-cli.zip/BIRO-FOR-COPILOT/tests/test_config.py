import json
import os
from pathlib import Path

from biro.config import UserConfig


def test_config_saves_without_password_and_restricts_permissions(tmp_path: Path, monkeypatch):
    monkeypatch.setenv("BIRO_CONFIG_DIR", str(tmp_path / "config"))
    config = UserConfig(access_token="jwt-token", email="user@example.com", display_name="User", model="biro-max")
    config.save()
    path = tmp_path / "config" / "config.json"
    value = json.loads(path.read_text())
    assert value["access_token"] == "jwt-token"
    assert "password" not in value
    assert path.stat().st_mode & 0o077 == 0
    assert (tmp_path / "config").stat().st_mode & 0o077 == 0


def test_clear_session_keeps_model_and_api_url(tmp_path: Path, monkeypatch):
    monkeypatch.setenv("BIRO_CONFIG_DIR", str(tmp_path / "config"))
    config = UserConfig(access_token="jwt", email="user@example.com", display_name="User", model="biro-mini", api_url="https://api.example", current_chat_id="chat-id")
    config.clear_session()
    assert config.access_token == ""
    assert config.email == ""
    assert config.current_chat_id == ""
    assert config.model == "biro-mini"
    assert config.api_url == "https://api.example"
