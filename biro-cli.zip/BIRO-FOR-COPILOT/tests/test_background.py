import json
import subprocess
import time

import pytest

import biro.background as background
from biro.config import UserConfig


def test_start_task_uses_pm2_and_saves_its_process_list(monkeypatch, tmp_path):
    monkeypatch.setenv("BIRO_CONFIG_DIR", str(tmp_path / "config"))
    monkeypatch.setattr(background.shutil, "which", lambda name: "/usr/bin/pm2" if name == "pm2" else None)
    calls = []
    monkeypatch.setattr(
        background.subprocess,
        "run",
        lambda command, **kwargs: calls.append((command, kwargs)),
    )

    task = background.start_task("Investigate this carefully", tmp_path, "chat-1")

    assert task["status"] == "queued"
    assert task["pm2_name"] == f"biro-job-{task['id']}"
    assert task["model"] == "biro-max"
    assert task["think"] is True
    assert calls[0][0][:2] == ["/usr/bin/pm2", "start"]
    assert "--no-autorestart" in calls[0][0]
    assert "--log" in calls[0][0]
    assert "--output" not in calls[0][0]
    assert calls[0][0][-4:] == ["-m", "biro.background", "--worker", task["id"]]
    assert len(calls) == 1


def test_start_task_reports_missing_pm2(monkeypatch, tmp_path):
    monkeypatch.setenv("BIRO_CONFIG_DIR", str(tmp_path / "config"))
    monkeypatch.setattr(background.shutil, "which", lambda _name: None)

    with pytest.raises(RuntimeError, match="PM2 is required"):
        background.start_task("Do work", tmp_path, "chat-1")


def test_worker_records_duration_and_requests_deep_research(monkeypatch, tmp_path):
    monkeypatch.setenv("BIRO_CONFIG_DIR", str(tmp_path / "config"))
    task = {
        "id": "job-1",
        "status": "queued",
        "cwd": str(tmp_path),
        "chat_id": "chat-1",
        "prompt": "Research and implement this",
        "pm2_name": "biro-job-job-1",
        "created_at": background._timestamp(),
    }
    background._save_task(task)
    config = UserConfig(api_url="https://api.example", access_token="token", current_chat_id="chat-1")
    monkeypatch.setattr(UserConfig, "load", classmethod(lambda cls: config))

    class FakeAPI:
        def __init__(self, _config):
            pass

        def close(self):
            pass

    class FakeAgent:
        def __init__(self, _api, agent_config, _cwd, **kwargs):
            assert kwargs["deep_research"] is True
            assert kwargs["think"] is True
            assert agent_config.model == "biro-max"

        def send(self, _prompt):
            time.sleep(0.02)
            return 0

    monkeypatch.setattr("biro.api.client.BiroAPI", FakeAPI)
    monkeypatch.setattr("biro.agent.runner.Agent", FakeAgent)
    cleanup_launches = []
    monkeypatch.setattr(background.shutil, "which", lambda _name: "/usr/bin/pm2")
    monkeypatch.setattr(background.subprocess, "Popen", lambda command, **_kwargs: cleanup_launches.append(command))

    assert background.run_task("job-1") == 0
    result = background._read_task("job-1")
    assert result["status"] == "complete"
    assert result["duration_seconds"] >= 0.02
    assert result["started_at"] < result["finished_at"]
    assert cleanup_launches == [[
        background.sys.executable, "-m", "biro.background", "--cleanup", "job-1"
    ]]


def test_cleanup_task_deletes_pm2_process_and_saves_process_list(monkeypatch, tmp_path):
    monkeypatch.setenv("BIRO_CONFIG_DIR", str(tmp_path / "config"))
    background._save_task({"id": "job-2", "pm2_name": "biro-job-job-2"})
    monkeypatch.setattr(background.shutil, "which", lambda _name: "/usr/bin/pm2")
    monkeypatch.setattr(background.time, "sleep", lambda _seconds: None)
    calls = []
    monkeypatch.setattr(background.subprocess, "run", lambda command, **_kwargs: calls.append(command))

    assert background.cleanup_task("job-2") == 0
    assert calls == [
        ["/usr/bin/pm2", "delete", "biro-job-job-2"],
        ["/usr/bin/pm2", "save", "--force"],
    ]
    assert background._read_task("job-2")["pm2_cleanup_error"] == ""


def test_clear_tasks_deletes_pm2_jobs_records_and_logs(monkeypatch, tmp_path):
    monkeypatch.setenv("BIRO_CONFIG_DIR", str(tmp_path / "config"))
    directory = tmp_path / "config" / "background"
    directory.mkdir(parents=True)
    background._save_task({
        "id": "job-1",
        "status": "running",
        "pm2_name": "biro-job-job-1",
        "created_at": background._timestamp(),
    })
    background._save_task({
        "id": "job-2",
        "status": "complete",
        "pm2_name": "biro-job-job-2",
        "created_at": background._timestamp(),
    })
    (directory / "job-1.log").write_text("worker log", encoding="utf-8")
    (directory / "orphan.log").write_text("stale log", encoding="utf-8")
    monkeypatch.setattr(background.shutil, "which", lambda _name: "/usr/bin/pm2")
    calls = []

    def run(command, **_kwargs):
        calls.append(command)
        if command[1] == "jlist":
            return subprocess.CompletedProcess(command, 0, stdout='[{"name":"biro-job-job-1"},{"name":"other"}]')
        return subprocess.CompletedProcess(command, 0, stdout="")

    monkeypatch.setattr(background.subprocess, "run", run)

    assert background.clear_tasks() == 4
    assert sorted(path.name for path in directory.iterdir()) == []
    assert calls == [
        ["/usr/bin/pm2", "jlist"],
        ["/usr/bin/pm2", "delete", "biro-job-job-1"],
        ["/usr/bin/pm2", "save", "--force"],
    ]


def test_clear_tasks_keeps_records_when_pm2_cannot_stop_active_jobs(monkeypatch, tmp_path):
    monkeypatch.setenv("BIRO_CONFIG_DIR", str(tmp_path / "config"))
    background._save_task({
        "id": "job-1",
        "status": "running",
        "pm2_name": "biro-job-job-1",
        "created_at": background._timestamp(),
    })
    monkeypatch.setattr(background.shutil, "which", lambda _name: None)

    with pytest.raises(RuntimeError, match="Cannot clear active BIRO jobs"):
        background.clear_tasks()

    assert background._read_task("job-1") is not None


def test_start_task_records_pm2_launch_failure(monkeypatch, tmp_path):
    monkeypatch.setenv("BIRO_CONFIG_DIR", str(tmp_path / "config"))
    monkeypatch.setattr(background.shutil, "which", lambda _name: "/usr/bin/pm2")
    calls = []

    def run(command, **_kwargs):
        calls.append(command)
        if command[1] == "start":
            raise subprocess.CalledProcessError(1, command, stderr="PM2 daemon unavailable")

    monkeypatch.setattr(background.subprocess, "run", run)

    with pytest.raises(RuntimeError, match="PM2 daemon unavailable"):
        background.start_task("Do work", tmp_path, "chat-1")

    task_files = list((tmp_path / "config" / "background").glob("*.json"))
    assert len(task_files) == 1
    task = json.loads(task_files[0].read_text(encoding="utf-8"))
    assert task["status"] == "failed"
    assert "PM2 daemon unavailable" in task["error"]
    assert calls[-1][1] == "delete"
