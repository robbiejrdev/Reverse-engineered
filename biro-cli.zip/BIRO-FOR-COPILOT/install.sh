#!/usr/bin/env bash
set -euo pipefail

SOURCE_DIR="$(CDPATH= cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
INSTALL_HOME="${BIRO_INSTALL_HOME:-$HOME/.local/share/biro-cli}"
APP_DIR="$INSTALL_HOME/app"
STAGE_DIR="$INSTALL_HOME/app.new"
VENV_DIR="$INSTALL_HOME/venv"
BIN_DIR="$HOME/.local/bin"

if ! command -v python3 >/dev/null 2>&1; then
  echo "BIRO CLI needs Python 3.10 or newer. Install python3 first." >&2
  exit 1
fi

mkdir -p "$INSTALL_HOME" "$BIN_DIR"
rm -rf "$STAGE_DIR"
mkdir -p "$STAGE_DIR"
# Copy source without local environments, caches, secrets, or build output.
tar -C "$SOURCE_DIR" \
  --exclude='./.venv' --exclude='./venv' --exclude='./__pycache__' \
  --exclude='*/__pycache__' --exclude='./.pytest_cache' \
  --exclude='./build' --exclude='./dist' --exclude='./*.egg-info' \
  --exclude='./.env' --exclude='./.env.*' \
  -cf - . | tar -C "$STAGE_DIR" -xf -

if [[ -d "$APP_DIR" ]]; then
  rm -rf "$INSTALL_HOME/app.previous"
  mv "$APP_DIR" "$INSTALL_HOME/app.previous"
fi
mv "$STAGE_DIR" "$APP_DIR"

if [[ ! -x "$VENV_DIR/bin/python" ]]; then
  python3 -m venv "$VENV_DIR" || {
    echo "Could not create the private BIRO runtime. On Ubuntu, install it with:" >&2
    echo "  sudo apt-get install python3-venv" >&2
    exit 1
  }
fi

"$VENV_DIR/bin/python" -m pip install --upgrade pip
"$VENV_DIR/bin/python" -m pip install --upgrade --force-reinstall "$APP_DIR"

cat > "$BIN_DIR/biro" <<EOF
#!/usr/bin/env sh
exec "$VENV_DIR/bin/biro" "\$@"
EOF
chmod 755 "$BIN_DIR/biro"

PATH_LINE='export PATH="$HOME/.local/bin:$PATH"'
for startup_file in "$HOME/.profile" "$HOME/.bashrc"; do
  if [[ -f "$startup_file" ]] && ! grep -Fqx "$PATH_LINE" "$startup_file"; then
    printf '\n# BIRO CLI\n%s\n' "$PATH_LINE" >> "$startup_file"
  fi
done

printf '\nBIRO CLI installed successfully.\n'
printf 'No virtual-environment activation is needed. Open a new terminal, or run:\n'
printf '  export PATH="$HOME/.local/bin:$PATH"\n'
printf 'Then run: biro\n'
printf 'Workspace: the directory from which you run `biro`.\n'
