# Repository Guidelines

## Project Structure & Module Organization

This is a Python 3.10+ terminal client. Application code lives in `src/biro/`: `agent/` handles model actions and tool execution, `api/` contains the BIRO backend client, and `ui/` contains terminal interaction. Tests are in `tests/`, project notes in `docs/`, and packaging/build configuration is in `pyproject.toml` and `Makefile`.

## Build, Test, and Development Commands

- `make install` creates `.venv` and installs the package in editable mode with test dependencies.
- `make test` compiles source and tests, then runs pytest; this is also the CI check.
- `make run` builds and launches the local CLI wrapper.
- `./build/bin/biro-cli --help` shows CLI options after the wrapper is available.

## Coding Style & Naming Conventions

Use four spaces for Python indentation, descriptive `snake_case` names for modules, functions, and variables, and `PascalCase` for classes. Keep imports explicit and group standard-library imports before third-party and local imports. No formatter or linter is configured; match surrounding code and keep changes focused.

## Testing Guidelines

Add or update pytest tests under `tests/`, using `test_*.py` files and `test_*` functions. Prefer temporary directories, monkeypatched configuration, and mocked HTTP responses so tests do not require a live BIRO account or backend. Run `make test` before submitting; no coverage threshold is configured.

## Commit & Pull Request Guidelines

This checkout has no Git metadata, so repository commit conventions could not be verified. Use a short imperative subject such as `Add API retry handling`. A pull request should explain user-visible behavior, link any related issue, list validation performed, and include a terminal screenshot when changing the CLI interface.

## Security & Configuration

Never commit real account tokens, passwords, or API credentials. Use `.env.example` for configuration examples and keep local secrets in ignored files or user-level config. Tests should use dummy credentials and isolated temporary config paths.
