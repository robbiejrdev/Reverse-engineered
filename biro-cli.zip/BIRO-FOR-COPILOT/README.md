# BIRO CLI v1.2.1

BIRO CLI is an interactive coding agent that runs in your terminal and uses the existing BIRO account and inference backend. This is a new, cleaned implementation based on the structure and agent-action idea in V1, not a copy of the old script (which contained a hard-coded upstream credential and directly called the provider).

## Current features

- BIRO account sign-up and sign-in through the existing backend (`/api/v1/auth/signup`, `/api/v1/auth/login`).
- Bearer-token sessions saved locally with restricted file permissions; passwords are never stored.
- Persistent conversations and messages stored by BIRO's backend.
- Two public model choices only: **BIRO Max** (`biro-max`) and **BIRO Mini** (`biro-mini`). Upstream model identifiers and provider keys are not part of the CLI configuration.
- BIRO terminal UI restores the compact pixel banner, framed workspace composer, and transient task dashboard, with random banner colors, live keyboard-navigable slash suggestions, a left-arrow chat picker, file-path completion, and persistent prompt history.
- New chats get a short title from the model's first response. File writes display syntax-highlighted, line-numbered red deletions and green additions, with no more than ten changed lines per preview.
- Local coding-agent actions: read files, write files, delete paths, run shell commands, and search the web through Tavily's keyless search endpoint. Web results are validated, bounded, date-tagged, and passed to the model as untrusted reference context.
- Background prompts run under PM2 in a fresh chat using BIRO Max with the thinking indicator enabled, so they survive SSH disconnects without mixing into the current conversation; `biro jobs` shows each task's status and elapsed/completed duration. Resume the job conversation through `biro chat <chat_id>`.
- Saved chat list includes chat IDs; use `biro chat <chat_id>` to resume any saved conversation from another terminal.
- Saved chat listing, reopening, history viewing, model switching, and new conversations.
- `/image <path>` attaches a local image as conversation context. `/file <path>` attaches a local file; the backend extracts supported text and summarizes images with its vision helper. Model-requested `generate_image` JSON actions call the original BIRO backend image endpoint and save the returned artifact into the current workspace. No backend changes are required.
- Large prompt support through text attachments for prompts longer than the backend's ordinary message field.
- Tests for tool parsing, path boundaries, model validation, large prompts, and session persistence.

## Install on the Ubuntu VPS (no activation required)

On a new Ubuntu/Debian VPS, install Python and venv support once:

```sh
sudo apt-get update
sudo apt-get install -y python3 python3-venv python3-pip make nodejs npm
sudo npm install --global pm2
```

Extract this source folder, enter it, and install the global user command:

```sh
./install.sh
```

Open a new terminal (or run `source ~/.bashrc`) and use `biro` from **any directory**. You do not need to activate a virtual environment manually. The installer maintains a private runtime under `~/.local/share/biro-cli/venv`, installs dependencies there, and puts a small launcher at `~/.local/bin/biro`. The working directory is the directory from which you execute `biro`, not the install folder.

```sh
biro --version
biro --help
cd ~/workspace/my-app
biro
```

For development and tests inside the source tree, `make test` uses the project's private `.venv`; runtime use of the installed `biro` command does not require activation.

## Compatibility with the existing BIRO backend

This CLI is an API client for the original backend at `https://api.robbiejr.site`. It uses the same account/session routes (`/api/v1/auth/signup`, `/api/v1/auth/login`, `/api/v1/me`), chat routes (`/api/v1/chats`, `/api/v1/chats/{id}/messages/stream`), model catalogue (`/api/v1/ai/models?provider=biro-max|biro-mini`), and private generated-artifact download route (`/api/v1/chats/{id}/artifacts/{artifact_id}/download`). It does not require a new backend, upstream provider key in the CLI, or any backend deployment change. Image generation remains server-side and uses the original backend's `/api/v1/chats/{id}/images` endpoint.

The old backend itself defines model context/history boundaries. The CLI avoids its own arbitrary response-display clipping, but it cannot remove server-side model context limits without a backend change.

## First launch and account storage

Start the app:

```sh
biro
```

Select **Sign in** if you already have a BIRO account, or **Create an account** otherwise. The current backend requires a display name, a valid email address, and a password of at least 10 characters. The backend uses bcrypt, so the current effective password limit is 72 UTF-8 bytes.

The CLI sends credentials only to BIRO's HTTPS authentication endpoints. The backend returns an access token; the CLI stores the token locally at:

```text
~/.config/biro/config.json
```

The containing directory is set to `0700` and the config file to `0600` where supported. The user's password is not saved. Run `biro logout` to remove the local session. Account data and conversation history remain on the backend.

The current default API URL is `https://api.robbiejr.site`. If you need to override it for a test environment, set the **backend root URL** (not a `/generate` path):

```sh
export BIRO_API_URL='https://api.robbiejr.site'
export BIRO_MODEL='biro-max'
biro
```

Supported model values are `biro-max` and `biro-mini`. This CLI authenticates with your BIRO account and uses the backend's bearer session; it does not use the upstream provider's API key. Do not set `BIRO_API_KEY` for this version of the CLI.

## Usage

```sh
biro
biro -m max
biro -m mini
biro -p "Inspect this project, run its tests, and fix the failing tests."
biro --think
biro login
biro signup
biro logout
biro chat <chat_id>
biro --background -p "Refactor the parser and update its docs."
biro jobs
```

BIRO runs agent actions unattended by default. Shell commands and model responses have no fixed time-based cutoff, so builds and long-running jobs can finish. Background jobs are started and daemonized by PM2; install PM2 before using `--background`. Their research instructions favor thorough investigation and verification over speed.

Inside the CLI:

```text
/help
/id
/status
/retry
/rename New title
/jobs
/new
/chats
/open 1
/resume <chat_id>
/history
/model
/model mini
/paste
/file path/to/prompt.txt
/image ./references/bicycle.png
/file ./docs/requirements.pdf
/models
/cwd
/cwd src
/account
/login
/signup
/logout
/connect github
/connect huggingface
/integrations
/github repo list
/huggingface auth whoami
/exit
```

Typing `/` opens a live command menu with descriptions. Use Up/Down to navigate without changing the input, then Tab to accept. `/clear` clears the terminal display; `/new` starts a fresh conversation. Press Left at an empty prompt to open the saved-chat picker. It lists older chats first; use Up/Down to navigate, Enter to open, `n` for a new chat, or `d` then `y` to confirm deleting the selected chat; Esc returns to the prompt. Prompt history is stored between sessions: Ctrl+R searches backward, Ctrl+U clears left of the cursor, and Ctrl+K clears right. `-p` sends a one-shot prompt; add `--background` to let it continue after the terminal closes and use `biro jobs` to check status.

## Long prompts and context

Chat records are stored by the BIRO backend and remain available after the CLI exits. Resume any conversation with `biro chat <chat_id>`; use `/chats` or `biro jobs` to find IDs and background task status. Ctrl+R searches prompt history across CLI sessions.

The deployed inference route forwards only the latest 20 stored messages. To extend memory, the CLI fetches earlier messages and sends them as ordered conversation-memory attachments before each model turn. The backend accepts at most four attachments with up to 80,000 characters each; this gives up to 320,000 characters of older context when there are no other attachments or long-prompt parts. File attachments and long prompts share that budget. This improves continuity but does not provide a 1-million-token window; that requires the backend to forward more context and the selected model/provider to accept it.

## Agent workflow

BIRO uses a structured action protocol for file, shell, and image operations. File creation and edits use the `write_file` action (rather than shell heredocs or redirection) so changes receive a syntax-colored, line-numbered diff; each preview shows at most ten changed lines. The agent can run inspection, test, and build commands in the active workspace, and action results are returned to the model for the next step. Resuming a chat displays its persisted messages before the next prompt.

## Run tests

```sh
make test
```

The tests use mock HTTP responses and temporary directories. They verify client-side behavior, not the availability of the live backend or real model inference. A live signup/chat round-trip is required to validate your deployed environment.

## Backend contract used

- `POST /api/v1/auth/signup`
- `POST /api/v1/auth/login`
- `GET /api/v1/me`
- `GET /api/v1/ai/models?provider=biro-max|biro-mini`
- `GET|POST /api/v1/chats`
- `GET /api/v1/chats/{chat_id}`
- `GET /api/v1/chats/{chat_id}/messages`
- `POST /api/v1/chats/{chat_id}/messages/stream`
- `POST /api/v1/chats/{chat_id}/images`
- `GET /api/v1/chats/{chat_id}/artifacts/{artifact_id}/download`
- `PATCH|DELETE /api/v1/chats/{chat_id}`

These routes were matched against the BIRO backend source available during implementation. No backend deployment or database changes are performed by this repository.
