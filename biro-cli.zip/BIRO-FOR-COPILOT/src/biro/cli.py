from __future__ import annotations

import argparse
import math
import os
import shlex
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

from rich.console import Console
from rich import box
from rich.markup import escape
from rich.panel import Panel
from rich.table import Table
from rich.text import Text
from rich.markdown import Markdown
from biro.ui.input import (
    CHAT_PICKER_SENTINEL,
    DELETE_CHAT_SENTINEL,
    EXIT_SENTINEL,
    NEW_CHAT_SENTINEL,
    TOGGLE_THINK_SENTINEL,
    read_chat_picker,
    read_input,
)

from biro import __version__
from biro.background import clear_tasks, list_tasks, start_task
from biro.agent.runner import Agent
from biro.api.client import BiroAPI, BiroAPIError
from biro.config import UserConfig, config_dir, validate_model
from biro.ui.auth import authenticate, login_flow, signup_flow

console = Console(highlight=False, soft_wrap=True)


def print_help() -> None:
    table = Table(title="COMMAND REFERENCE", box=None, expand=True, show_header=True, header_style="bold #72D6B2", row_styles=["", "dim"])
    table.add_column("Command", style="bold #E5B86F", no_wrap=True, width=25)
    table.add_column("What it does", overflow="fold")
    groups = [
        ("Chat", [
            ("/", "show live command suggestions"),
            ("/id", "show this chat ID and the command to resume it"),
            ("/status", "show model, workspace, chat, and activity"),
            ("/chats", "list saved chats and IDs"),
            ("/open or /resume <id>", "switch to a saved chat"),
            ("/history", "read this chat"),
            ("/retry", "send the previous user prompt again"),
            ("/rename <title>", "rename the current chat"),
            ("/new", "start a new saved chat"),
            ("/clear", "clear the terminal display without changing chats"),
            ("/jobs", "see task status; run `biro jobs clear` to delete all jobs and logs"),
        ]),
        ("Workspace", [
            ("/cwd [directory]", "show or change the working folder"),
            ("/file <path>", "attach a local file"),
            ("/image <path>", "attach a local image"),
            ("/paste", "enter a multiline prompt; finish with a dot"),
        ]),
        ("Integrations", [
            ("/connect github|huggingface", "sign in through the provider CLI"),
            ("/integrations", "show provider connection status"),
            ("/github <args>", "run a GitHub CLI command"),
            ("/huggingface <args>", "run a Hugging Face CLI command"),
        ]),
        ("Account & controls", [
            ("/model [max|mini]", "show or switch models"),
            ("/think", "toggle the thinking indicator"),
            ("/account", "show the signed-in account"),
            ("/login /signup /logout", "manage the BIRO account"),
            ("/exit", "quit BIRO"),
        ]),
    ]
    for group, rows in groups:
        table.add_section()
        table.add_row(f"[bold #72D6B2]{group}[/bold #72D6B2]", "")
        for command, description in rows:
            table.add_row(command, description)
    console.print(Panel(table, title="[bold #72D6B2]BIRO · HELP[/bold #72D6B2]", border_style="#586D64", box=box.ROUNDED, padding=(0, 1)))
    console.print(Panel(
        "← on empty prompt: chats (Esc back, n new)  ·  ↑/↓ browse suggestions/history  ·  Tab accept  ·  Ctrl+R search  ·  Ctrl+T think  ·  Ctrl+I interrupt\n"
        "Start or resume with: biro chat <chat_id>. Use --background with -p to continue after this terminal closes.",
        title="SHORTCUTS", border_style="#586D64", box=box.ROUNDED, padding=(0, 1),
    ))

def _display_path(path: Path) -> str:
    resolved = path.expanduser().resolve()
    try:
        return "~/" + str(resolved.relative_to(Path.home()))
    except ValueError:
        return str(resolved)


def print_banner(config: UserConfig) -> None:
    """Print BIRO's original pixel logo using the refreshed terminal palette."""
    workspace = _display_path(Path.cwd())
    console.print()
    console.print("[bold #72D6B2]██████████████[/bold #72D6B2]  [bold]BIRO[/bold] [dim]CLI[/dim]")
    console.print("[bold #8FA8D1]████████████[/bold #8FA8D1]    [dim]v{0}[/dim]".format(__version__))
    console.print(f"[bold #E5B86F]█████████  ●[/bold #E5B86F]    [bold #72D6B2]{escape(workspace)}[/bold #72D6B2]")
    console.print()


def parse_slash_command(line: str) -> tuple[str, str] | None:
    """Parse slash input without indexing an empty list for `/` or `/   `."""
    stripped = line.strip()
    if not stripped.startswith("/"):
        return None
    parts = stripped[1:].split(maxsplit=1)
    if not parts or not parts[0]:
        return None
    return parts[0].lower(), parts[1] if len(parts) > 1 else ""

def _provider_binary(executable: str) -> str | None:
    binary = shutil.which(executable)
    if binary:
        return binary
    # The launcher may call the venv's Python directly without adding .venv/bin
    # to PATH. Discover its hf entry point explicitly in that case.
    if executable == "hf":
        candidate = Path(sys.executable).resolve().with_name("hf")
        if candidate.is_file() and os.access(candidate, os.X_OK):
            return str(candidate)
    return None


def _run_provider_cli(executable: str, arguments: list[str], cwd: Path) -> int:
    binary = _provider_binary(executable)
    if not binary:
        if executable == "gh":
            console.print("[yellow]GitHub CLI (`gh`) is not installed. Install GitHub CLI, then run `/connect github`.[/yellow]")
        else:
            console.print(f"[yellow]Hugging Face CLI (`hf`) is not installed in the BIRO environment. Install it with `{sys.executable} -m pip install -U huggingface_hub`, then run `/connect huggingface`.[/yellow]")
        return 127
    try:
        completed = subprocess.run([binary, *arguments], cwd=cwd, check=False)
        if completed.returncode:
            console.print(f"[yellow]{executable} exited with code {completed.returncode}.[/yellow]")
        return completed.returncode
    except OSError as exc:
        console.print(f"[red]Could not launch {executable}: {escape(str(exc))}[/red]")
        return 1


def _integration_status(cwd: Path) -> None:
    table = Table(title="External integrations", box=None, header_style="bold #72D6B2")
    table.add_column("Provider")
    table.add_column("Status")
    for name, binary, arguments in (
        ("GitHub", "gh", ["auth", "status"]),
        ("Hugging Face", "hf", ["auth", "whoami"]),
    ):
        if not _provider_binary(binary):
            status = "CLI not installed"
        else:
            try:
                completed = subprocess.run([_provider_binary(binary) or binary, *arguments], cwd=cwd, text=True, capture_output=True, check=False)
                status = "Connected" if completed.returncode == 0 else "Not signed in"
            except OSError:
                status = "Unable to check"
        color = "#72D6B2" if status == "Connected" else "#E5B86F"
        table.add_row(name, f"[{color}]{status}[/{color}]")
    console.print(table)
    console.print("[dim]Use /connect github or /connect huggingface to sign in. BIRO uses the CLIs' local credential stores; tokens are not copied into BIRO config.[/dim]")


def _select_model(api: BiroAPI, config: UserConfig, model: str | None = None) -> bool:
    if model:
        try:
            chosen = validate_model(model)
        except ValueError as exc:
            console.print(f"[red]{escape(str(exc))}[/red]")
            return False
    else:
        table = Table(title="BIRO Models", box=None, show_header=True, header_style="bold #72D6B2")
        table.add_column("Option", style="#E5B86F")
        table.add_column("Model", style="bold")
        table.add_column("Best for")
        table.add_row("1 / max", "BIRO Max · 500B parameters", "Complex coding, planning, deeper reasoning")
        table.add_row("2 / mini", "BIRO Mini", "Fast everyday work and smaller tasks")
        console.print(table)
        try:
            choice = input("Choose [1/2, max/mini] (Enter keeps current): ").strip()
        except (EOFError, KeyboardInterrupt):
            return False
        if not choice:
            return True
        aliases = {"1": "biro-max", "2": "biro-mini"}
        try:
            chosen = validate_model(aliases.get(choice, choice))
        except ValueError as exc:
            console.print(f"[red]{escape(str(exc))}[/red]")
            return False
    try:
        result = api.models(chosen)
        if not result.get("configured", True):
            console.print("[yellow]This model is listed, but the backend currently reports that inference is not configured.[/yellow]")
    except BiroAPIError as exc:
        # Preserve compatibility if the model catalogue route is temporarily unavailable;
        # the actual chat endpoint remains the authority at send time.
        if exc.status_code not in {404, 405}:
            console.print(f"[yellow]Couldn't verify model availability right now: {escape(str(exc))}[/yellow]")
    config.model = chosen
    config.save()
    console.print(f"[green]Selected {'BIRO Max' if chosen == 'biro-max' else 'BIRO Mini'}.[/green]")
    return True


def _current_chat(api: BiroAPI, config: UserConfig) -> dict:
    if config.current_chat_id:
        try:
            return api.get_chat(config.current_chat_id)
        except BiroAPIError as exc:
            if exc.status_code not in {404, 401}:
                raise
            config.current_chat_id = ""
            config.save()
    return api.create_chat()


def _list_chats(api: BiroAPI, config: UserConfig) -> None:
    chats = api.list_chats()
    if not chats:
        console.print("[dim]No saved conversations yet.[/dim]")
        return
    table = Table(title="Saved conversations", header_style="#72D6B2", box=None)
    table.add_column("#", style="dim", justify="right")
    table.add_column("Title")
    table.add_column("Chat ID", style="#E5B86F")
    table.add_column("Updated", style="dim")
    table.add_column("Current", style="#72D6B2")
    for index, chat in enumerate(chats, 1):
        chat_id = str(chat.get("id", ""))
        updated = str(chat.get("updated_at", ""))[:16].replace("T", " ")
        table.add_row(
            str(index), Text(str(chat.get("title") or "New conversation")), chat_id, updated,
            "●" if chat_id == config.current_chat_id else "",
        )
    console.print(table)
    console.print("[dim]Resume from another terminal with: biro chat <chat_id>[/dim]")

def _open_chat(api: BiroAPI, config: UserConfig, target: str, *, direct_id: bool = False) -> bool:
    if not target.strip():
        console.print("Usage: /open <number-or-id>")
        return False
    chosen = None
    if direct_id:
        try:
            chosen = api.get_chat(target.strip())
        except BiroAPIError as exc:
            if exc.status_code != 404:
                raise
    elif target.isdigit():
        chats = api.list_chats()
        index = int(target) - 1
        if 0 <= index < len(chats):
            chosen = chats[index]
    else:
        try:
            chosen = api.get_chat(target.strip())
        except BiroAPIError as exc:
            if exc.status_code != 404:
                raise
    if not chosen:
        console.print("[red]Chat not found. Use /chats to see saved chat IDs.[/red]")
        return False
    config.current_chat_id = str(chosen["id"])
    config.save()
    console.print(f"[#72D6B2]Opened[/#72D6B2] {escape(str(chosen.get('title') or 'New conversation'))}  [dim]{escape(config.current_chat_id)}[/dim]")
    return True

def _history(api: BiroAPI, config: UserConfig) -> None:
    chat = _current_chat(api, config)
    _show_chat_history(api, str(chat["id"]))


def _show_chat_history(api: BiroAPI, chat_id: str) -> None:
    messages = api.list_messages(chat_id)
    if not messages:
        console.print("[dim]This conversation has no messages yet.[/dim]")
        return
    for item in messages:
        role = str(item.get("role", "message"))
        content = str(item.get("content", ""))
        style = "bold" if role == "user" else ""
        console.print(f"\n[bold {style}]{'you' if role == 'user' else 'BIRO'}[/bold {style}]")
        console.print(Text(content, style=style))
        # Persisted provider reasoning is deliberately not displayed in history.
        # BIRO's thinking toggle only controls a short task/step title in the live UI.
        artifacts = item.get("artifacts") or []
        for artifact in artifacts:
            console.print(f"[dim]Attachment: {escape(str(artifact.get('filename', 'file')))} · {escape(str(artifact.get('kind', 'upload')))}[/dim]")


def _show_background_tasks() -> None:
    tasks = list_tasks()
    if not tasks:
        console.print("[dim]No background tasks yet. Start one with -p \"...\" --background.[/dim]")
        return
    table = Table(title="Background tasks", box=None, header_style="bold #72D6B2")
    table.add_column("Task", style="#E5B86F")
    table.add_column("Status")
    table.add_column("Chat ID", style="dim")
    table.add_column("Started", style="dim")
    table.add_column("Duration", justify="right")
    for task in tasks[:20]:
        status = str(task.get("status", "unknown"))
        color = "#72D6B2" if status in {"queued", "running", "starting"} else "#E5B86F"
        duration = task.get("duration_seconds")
        try:
            elapsed = float(duration) if duration is not None else None
        except (TypeError, ValueError):
            elapsed = None
        if elapsed is not None and not math.isfinite(elapsed):
            elapsed = None
        if elapsed is None:
            started_at = task.get("started_at")
            finished_at = task.get("finished_at")
            if started_at:
                try:
                    start = datetime.fromisoformat(str(started_at).replace("Z", "+00:00"))
                    end = (
                        datetime.fromisoformat(str(finished_at).replace("Z", "+00:00"))
                        if finished_at
                        else datetime.now(timezone.utc)
                    )
                    elapsed = max(0.0, (end - start).total_seconds())
                except (TypeError, ValueError):
                    elapsed = None
        duration_text = _format_job_duration(elapsed) if elapsed is not None else "—"
        table.add_row(
            str(task.get("id", "")), f"[{color}]{status}[/{color}]",
            str(task.get("chat_id", "")), str(task.get("created_at", ""))[:16],
            duration_text,
        )
    console.print(table)
    console.print("[dim]Worker logs are stored next to each task record in the BIRO config directory.[/dim]")


def _format_job_duration(seconds: float) -> str:
    total = max(0, int(seconds))
    hours, remainder = divmod(total, 3600)
    minutes, secs = divmod(remainder, 60)
    if hours:
        return f"{hours}h {minutes}m {secs}s"
    if minutes:
        return f"{minutes}m {secs}s"
    return f"{secs}s"


def _retry_last_prompt(api: BiroAPI, agent: Agent) -> None:
    messages = api.list_messages(agent.config.current_chat_id)
    previous = next((
        item for item in reversed(messages)
        if item.get("role") == "user" and isinstance(item.get("content"), str)
        and item.get("content", "").strip()
        and not item.get("content", "").startswith(("[Local tool result:", "ACTION_PROTOCOL_REPAIR:"))
    ), None)
    if previous is None:
        console.print("[dim]No previous user prompt is available to retry.[/dim]")
        return
    console.print("[dim]Retrying the previous user prompt…[/dim]")
    agent.send(str(previous["content"]))


def _account(api: BiroAPI, config: UserConfig) -> None:
    user = api.me()
    console.print(Panel.fit(
        Text(f"{user.get('display_name', config.display_name)}\n{user.get('email', config.email)}\nAccount ID: {user.get('id', '—')}"),
        title="BIRO account", border_style="#E5B86F",
    ))


def _print_session_exit_banner(agent: Agent, chat_id: str) -> None:
    token_count = int(getattr(agent, "session_token_count", 0))
    additions = int(getattr(agent, "session_lines_added", 0))
    deletions = int(getattr(agent, "session_lines_deleted", 0))
    if console.is_terminal:
        console.clear(home=True)
    workspace = escape(_display_path(Path.cwd()))
    console.print()
    console.print("[bold #72D6B2]██████████████[/bold #72D6B2]  [bold]BIRO[/bold]")
    console.print("[bold #8FA8D1]████████████[/bold #8FA8D1]    [dim]SESSION ENDED[/dim]")
    console.print("[bold #E5B86F]█████████  ●[/bold #E5B86F]    [bold #72D6B2]{0}[/bold #72D6B2]".format(workspace))
    console.print()
    console.print(f"[bold #72D6B2]MODEL[/bold #72D6B2]  {escape(agent.model_label)}")
    console.print(f"[bold #72D6B2]TOKENS[/bold #72D6B2]  {token_count:,}")
    console.print(
        f"[bold #72D6B2]CODE DIFF[/bold #72D6B2]  "
        f"[#72D6B2]+{additions}[/#72D6B2]  [#E5B86F]-{deletions}[/#E5B86F] lines"
    )
    if chat_id:
        console.print(f"[bold #72D6B2]RESUME[/bold #72D6B2]  biro chat {escape(chat_id)}")
    console.print()


def _multiline_prompt() -> str:
    console.print("[dim]Paste/type your request. Enter a single dot (`.`) on its own line to send; Ctrl+C cancels.[/dim]")
    lines: list[str] = []
    try:
        while True:
            line = input("... " if lines else "│ ")
            if line == ".":
                break
            lines.append(line)
    except (EOFError, KeyboardInterrupt):
        console.print("\n[dim]Multiline prompt cancelled.[/dim]")
        return ""
    return "\n".join(lines)



def _attachment_for_path(agent: Agent, raw_path: str, *, image_only: bool) -> dict:
    import base64
    import mimetypes

    path = agent.tools.resolve_path(raw_path.strip().strip('"').strip("'"))
    if not path.is_file():
        raise ValueError(f"No such regular file: {raw_path}")
    size = path.stat().st_size
    if size <= 0:
        raise ValueError("Empty files cannot be attached.")
    if size > 10_000_000:
        raise ValueError("BIRO currently accepts files up to 10 MB each.")
    mime = mimetypes.guess_type(path.name)[0] or "application/octet-stream"
    if image_only and not mime.startswith("image/"):
        raise ValueError("/image expects an image file such as .png, .jpg, .jpeg, or .webp.")
    raw = path.read_bytes()
    return {
        "filename": path.name,
        "mime_type": mime,
        "data_base64": base64.b64encode(raw).decode("ascii"),
        "vision_frames": [],
    }

def _ask_signin(api: BiroAPI, config: UserConfig, mode: str) -> bool:
    if mode == "login":
        return login_flow(api, config, force=True)
    return signup_flow(api, config)


def run_app(args: argparse.Namespace) -> int:
    config = UserConfig.load()
    if args.api_url:
        config.api_url = args.api_url.rstrip("/")
        config.save()
    if args.model:
        try:
            config.model = validate_model(args.model)
            config.save()
        except ValueError as exc:
            console.print(f"[red]{escape(str(exc))}[/red]")
            return 2
    api = BiroAPI(config)
    try:
        if args.auth_command == "jobs":
            if args.chat_id == "clear":
                removed = clear_tasks()
                console.print(f"Cleared background jobs and logs ({removed} local files removed).")
                return 0
            _show_background_tasks()
            return 0
        if args.auth_command == "logout":
            config.clear_session()
            console.print("[green]Signed out from this device. Your server-side conversations remain stored.[/green]")
            return 0
        if args.auth_command in {"login", "signup"}:
            return 0 if _ask_signin(api, config, args.auth_command) else 1

        if not authenticate(api, config):
            return 1
        resuming_chat = args.auth_command == "chat"
        if resuming_chat:
            if not _open_chat(api, config, args.chat_id or "", direct_id=True):
                return 1
        elif not args.background:
            _current_chat(api, config)
        if console.is_terminal:
            console.clear(home=True)
        print_banner(config)
        if resuming_chat:
            _show_chat_history(api, config.current_chat_id)
        if args.background:
            chat = api.create_chat("Background task", select=False)
            background_chat_id = str(chat["id"])
            task = start_task(
                str(args.prompt), Path.cwd(), background_chat_id,
                max_steps=args.max_steps,
            )
            console.print(
                f"[green]Background task started[/green]  task {task['id']}  chat {background_chat_id}"
            )
            console.print(f"[dim]Check it with biro jobs. Resume the chat with biro chat {background_chat_id}.[/dim]")
            return 0
        if args.prompt is not None:
            return Agent(api, config, Path.cwd(), think=args.think,
                         auto_approve=(not args.confirm or args.yes), confirm_all=args.confirm, max_steps=args.max_steps).send(args.prompt)
        agent = Agent(api, config, Path.cwd(), think=args.think,
                      auto_approve=(not args.confirm or args.yes), confirm_all=args.confirm, max_steps=args.max_steps)
        try:
            agent.message_count = len(api.list_messages(config.current_chat_id))
        except BiroAPIError:
            pass
        while True:
            line = read_input(
                agent.model_label, agent.tools.cwd,
                message_count=agent.message_count,
                last_elapsed=agent.last_elapsed,
                thinking=agent.think,
                details=agent.details,
            )
            if line is None:
                _print_session_exit_banner(agent, config.current_chat_id)
                return 0
            if line == EXIT_SENTINEL:
                _print_session_exit_banner(agent, config.current_chat_id)
                return 0
            if line == TOGGLE_THINK_SENTINEL:
                agent.think = not agent.think
                mode = "ON" if agent.think else "OFF"
                console.print(Panel.fit(
                    f"[bold #72D6B2]THINKING TITLE: {mode}[/bold #72D6B2]\n"
                    "[dim]Only a short task/step title is shown. Raw provider reasoning is never printed.[/dim]",
                    border_style="#586D64", padding=(0, 1),
                ))
                continue
            if line == CHAT_PICKER_SENTINEL:
                try:
                    while True:
                        selected_chat = read_chat_picker(api.list_chats())
                        if selected_chat == EXIT_SENTINEL:
                            _print_session_exit_banner(agent, config.current_chat_id)
                            return 0
                        if selected_chat == NEW_CHAT_SENTINEL:
                            chat = api.create_chat()
                            agent.message_count = 0
                            agent.last_elapsed = 0.0
                            console.print(f"[green]New conversation started.[/green] [dim]{escape(str(chat['id']))}[/dim]")
                            break
                        if selected_chat and selected_chat.startswith(DELETE_CHAT_SENTINEL):
                            chat_id = selected_chat[len(DELETE_CHAT_SENTINEL):]
                            deleting_current_chat = config.current_chat_id == chat_id
                            api.delete_chat(chat_id)
                            if deleting_current_chat:
                                agent.message_count = 0
                                agent.last_elapsed = 0.0
                            console.print("[green]Chat deleted.[/green]")
                            continue
                        if selected_chat:
                            if _open_chat(api, config, selected_chat, direct_id=True):
                                agent.message_count = len(api.list_messages(config.current_chat_id))
                                agent.last_elapsed = 0.0
                                _history(api, config)
                        break
                except BiroAPIError as exc:
                    console.print(f"[red]BIRO API error:[/red] {escape(str(exc))}")
                continue
            if not line.strip():
                continue
            if not line.lstrip().startswith("/"):
                agent.send(line)
                if agent.detached:
                    _print_session_exit_banner(agent, config.current_chat_id)
                    return 0
                continue
            parsed_command = parse_slash_command(line)
            if parsed_command is None:
                console.print("[dim]No command selected. Type `/` to browse commands or `/help` for the list.[/dim]")
                continue
            command, arg = parsed_command
            try:
                if command in {"exit", "quit"}:
                    _print_session_exit_banner(agent, config.current_chat_id)
                    return 0
                if command == "help":
                    print_help()
                elif command in {"id", "chat"}:
                    chat_id = config.current_chat_id
                    console.print(Panel.fit(
                        Text(f"{chat_id}\nResume with: biro chat {chat_id}"),
                        title="CHAT ID", border_style="#586D64", box=box.ROUNDED,
                    ))
                elif command == "status":
                    chat_id = config.current_chat_id
                    console.print(Panel.fit(
                        Text(f"Model: {agent.model_label}\nWorkspace: {agent.tools.cwd}\nChat ID: {chat_id}\nMessages: {agent.message_count}"),
                        title="BIRO STATUS", border_style="#586D64", box=box.ROUNDED,
                    ))
                elif command == "jobs":
                    _show_background_tasks()
                elif command == "new":
                    chat = api.create_chat()
                    agent.message_count = 0
                    agent.last_elapsed = 0.0
                    console.print(f"[green]New conversation started.[/green] [dim]{escape(str(chat['id']))}[/dim]")
                elif command == "clear":
                    if console.is_terminal:
                        console.clear(home=True)
                    print_banner(config)
                elif command == "chats":
                    _list_chats(api, config)
                elif command in {"open", "resume"}:
                    if _open_chat(api, config, arg):
                        try:
                            agent.message_count = len(api.list_messages(config.current_chat_id))
                        except BiroAPIError:
                            pass
                        _history(api, config)
                elif command == "history":
                    _history(api, config)
                elif command == "retry":
                    _retry_last_prompt(api, agent)
                    if agent.detached:
                        _print_session_exit_banner(agent, config.current_chat_id)
                        return 0
                elif command == "rename":
                    if not arg.strip():
                        console.print("Usage: /rename <chat title>")
                    else:
                        updated = api.update_chat(config.current_chat_id, title=arg.strip())
                        console.print(f"[green]Renamed[/green] {escape(str(updated.get('title') or arg.strip()))}")
                elif command in {"model", "models"}:
                    if _select_model(api, config, arg or None):
                        console.print(f"[dim]Current conversation: {config.current_chat_id}[/dim]")
                        agent.config.model = config.model
                elif command == "think":
                    agent.think = not agent.think
                    mode = "ON" if agent.think else "OFF"
                    console.print(Panel.fit(
                        f"[bold #72D6B2]THINKING TITLE: {mode}[/bold #72D6B2]\n"
                        "[dim]Only a short task/step title is shown; private reasoning text is hidden.[/dim]",
                        border_style="#586D64", padding=(0, 1),
                    ))
                elif command == "connect":
                    provider = arg.strip().lower()
                    if provider in {"github", "gh"}:
                        _run_provider_cli("gh", ["auth", "login"], agent.tools.cwd)
                    elif provider in {"huggingface", "hf", "hugging-face"}:
                        _run_provider_cli("hf", ["auth", "login"], agent.tools.cwd)
                    else:
                        console.print("Usage: /connect github  or  /connect huggingface")
                elif command == "integrations":
                    _integration_status(agent.tools.cwd)
                elif command == "github":
                    arguments = shlex.split(arg) if arg.strip() else ["auth", "status"]
                    _run_provider_cli("gh", arguments, agent.tools.cwd)
                elif command in {"huggingface", "hf"}:
                    arguments = shlex.split(arg) if arg.strip() else ["auth", "whoami"]
                    _run_provider_cli("hf", arguments, agent.tools.cwd)
                elif command == "paste":
                    prompt = _multiline_prompt()
                    if prompt.strip():
                        agent.send(prompt)
                        if agent.detached:
                            _print_session_exit_banner(agent, config.current_chat_id)
                            return 0
                elif command in {"file", "image"}:
                    if not arg.strip():
                        console.print(f"Usage: /{command} <local file path>")
                    else:
                        attached = _attachment_for_path(agent, arg, image_only=(command == "image"))
                        display_name = escape(str(attached["filename"]))
                        prompt = f"Please inspect the attached {'image' if command == 'image' else 'file'}: {attached['filename']}. Use it as context for this conversation."
                        with console.status(f"[bold]Attaching {display_name}[/bold]", spinner="dots"):
                            agent.send(prompt, attachments=[attached])
                        if agent.detached:
                            _print_session_exit_banner(agent, config.current_chat_id)
                            return 0
                elif command == "cwd":
                    if not arg:
                        console.print(f"[dim]Workspace:[/dim] {escape(str(agent.tools.cwd))}")
                    else:
                        new_cwd = agent.tools.change_cwd(arg)
                        agent.cwd = new_cwd
                        console.print(f"[green]Workspace changed:[/green] {escape(str(new_cwd))}")
                elif command == "account":
                    _account(api, config)
                elif command == "login":
                    if _ask_signin(api, config, "login"):
                        console.print("[green]Account switched. Start a new conversation or select one from /chats.[/green]")
                        _current_chat(api, config)
                        agent = Agent(api, config, agent.tools.cwd, think=agent.think,
                                      auto_approve=(not args.confirm or args.yes), confirm_all=args.confirm, max_steps=args.max_steps)
                elif command == "signup":
                    if _ask_signin(api, config, "signup"):
                        _current_chat(api, config)
                        agent = Agent(api, config, agent.tools.cwd, think=agent.think,
                                      auto_approve=(not args.confirm or args.yes), confirm_all=args.confirm, max_steps=args.max_steps)
                elif command == "logout":
                    config.clear_session()
                    console.print("[green]Signed out. Server-side chats remain stored.[/green]")
                    if authenticate(api, config):
                        _current_chat(api, config)
                        agent = Agent(api, config, agent.tools.cwd, think=agent.think,
                                      auto_approve=(not args.confirm or args.yes), confirm_all=args.confirm, max_steps=args.max_steps)
                    else:
                        return 0
                elif command == "account-config":
                    console.print(f"API: {escape(config.api_url)}\nConfig: {escape(str(config_dir() / 'config.json'))}")
                else:
                    console.print(f"[red]Unknown command:[/red] /{escape(command)}. Type /help.")
                if agent.detached:
                    _print_session_exit_banner(agent, config.current_chat_id)
                    return 0
            except BiroAPIError as exc:
                console.print(f"[red]BIRO API error:[/red] {escape(str(exc))}")
            except (OSError, ValueError) as exc:
                console.print(f"[red]Error:[/red] {escape(str(exc))}")
    finally:
        api.close()


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="biro", description="BIRO interactive coding agent")
    parser.add_argument("-p", "--prompt", help="send a single prompt and exit")
    parser.add_argument("-m", "--model", help="select max/biro-max or mini/biro-mini")
    parser.add_argument("--api-url", help="BIRO backend root URL (defaults to https://api.robbiejr.site)")
    parser.add_argument("--think", action="store_true", help="show title-only task thinking in the terminal dashboard")
    parser.add_argument("--yes", action="store_true", help=argparse.SUPPRESS)
    parser.add_argument("--confirm", action="store_true", help=argparse.SUPPRESS)
    parser.add_argument("--max-steps", type=int, default=0, help=argparse.SUPPRESS)
    parser.add_argument("--background", action="store_true", help="run a one-shot prompt in a detached worker")
    parser.add_argument("--version", action="version", version=f"BIRO CLI {__version__}")
    parser.add_argument("auth_command", nargs="?", choices=("login", "signup", "logout", "chat", "jobs"), help="manage your account, resume a chat, or manage background tasks")
    parser.add_argument("chat_id", nargs="?", help="chat ID after chat, or clear after jobs")
    return parser


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()
    if args.max_steps < 0:
        parser.error("--max-steps must be zero (unlimited) or a positive integer")
    if args.auth_command == "chat" and not args.chat_id:
        parser.error("biro chat requires a chat ID")
    if args.auth_command == "jobs" and args.chat_id not in {None, "clear"}:
        parser.error("usage: biro jobs [clear]")
    if args.auth_command not in {"chat", "jobs"} and args.chat_id:
        parser.error("a chat ID can only follow the chat command")
    if args.background and args.prompt is None:
        parser.error("--background requires -p/--prompt")
    if args.auth_command == "jobs" and (args.prompt is not None or args.background):
        parser.error("biro jobs cannot be combined with a prompt or --background")
    try:
        return run_app(args)
    except (OSError, ValueError, RuntimeError, BiroAPIError) as exc:
        console.print(f"[bold red]Startup error:[/bold red] {escape(str(exc))}")
        return 1
    except KeyboardInterrupt:
        console.print("\n[dim]Interrupted.[/dim]")
        return 130


if __name__ == "__main__":
    raise SystemExit(main())
