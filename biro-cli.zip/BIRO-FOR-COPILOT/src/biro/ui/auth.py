from __future__ import annotations

from getpass import getpass

from rich.console import Console
from rich.panel import Panel
from rich.markup import escape

from biro.api.client import BiroAPI, BiroAPIError
from biro.config import UserConfig

console = Console(highlight=False)


def _ask_email(default: str = "") -> str:
    try:
        return input(f"Email{f' [{default}]' if default else ''}: ").strip() or default
    except (EOFError, KeyboardInterrupt):
        return ""


def login_flow(api: BiroAPI, config: UserConfig, *, force: bool = False) -> bool:
    console.print(Panel.fit("[bold]Sign in to BIRO[/bold]\n[dim]Your account and conversations are stored by BIRO's backend.[/dim]", border_style="bright_cyan"))
    email = _ask_email(config.email)
    if not email:
        return False
    try:
        password = getpass("Password: ")
    except (EOFError, KeyboardInterrupt):
        console.print("\n[dim]Sign-in cancelled.[/dim]")
        return False
    if not password:
        console.print("[red]Password cannot be empty.[/red]")
        return False
    try:
        api.login(email, password)
        console.print(f"[green]Signed in[/green] as {escape(config.display_name or config.email)}.")
        return True
    except BiroAPIError as exc:
        console.print(f"[red]Sign-in failed:[/red] {escape(str(exc))}")
        return False


def signup_flow(api: BiroAPI, config: UserConfig) -> bool:
    console.print(Panel.fit("[bold]Create your BIRO account[/bold]\n[dim]Use the same account across supported BIRO clients.[/dim]", border_style="bright_cyan"))
    try:
        display_name = input("Display name: ").strip()
        email = input("Email: ").strip()
        password = getpass("Create password (10+ characters): ")
        confirm = getpass("Confirm password: ")
    except (EOFError, KeyboardInterrupt):
        console.print("\n[dim]Sign-up cancelled.[/dim]")
        return False
    if not display_name:
        console.print("[red]Display name cannot be empty.[/red]")
        return False
    if len(password) < 10:
        console.print("[red]The backend requires a password of at least 10 characters.[/red]")
        return False
    if len(password.encode("utf-8")) > 72:
        console.print("[red]The current backend password has a 72-byte limit. Choose a shorter password.[/red]")
        return False
    if password != confirm:
        console.print("[red]The passwords do not match.[/red]")
        return False
    try:
        api.signup(display_name, email, password)
        console.print(f"[green]Account created.[/green] Welcome, {escape(config.display_name or display_name)}.")
        return True
    except BiroAPIError as exc:
        console.print(f"[red]Sign-up failed:[/red] {escape(str(exc))}")
        return False


def authenticate(api: BiroAPI, config: UserConfig) -> bool:
    if config.access_token:
        try:
            user = api.me()
            config.display_name = str(user.get("display_name", config.display_name))
            config.email = str(user.get("email", config.email))
            config.save()
            return True
        except BiroAPIError as exc:
            if exc.status_code != 401:
                console.print(f"[red]Can't verify your BIRO session:[/red] {escape(str(exc))}")
                return False
            console.print("[yellow]Your saved BIRO session has expired.[/yellow]")
            config.clear_session()

    while True:
        console.print("\n[bold]Welcome to BIRO CLI[/bold]")
        console.print("[cyan]1[/cyan] Sign in\n[cyan]2[/cyan] Create an account\n[cyan]3[/cyan] Exit")
        try:
            choice = input("Choose 1–3: ").strip()
        except (EOFError, KeyboardInterrupt):
            return False
        if choice == "1" and login_flow(api, config):
            return True
        if choice == "2" and signup_flow(api, config):
            return True
        if choice == "3":
            return False
        if choice not in {"1", "2", "3"}:
            console.print("[dim]Enter 1, 2, or 3.[/dim]")
