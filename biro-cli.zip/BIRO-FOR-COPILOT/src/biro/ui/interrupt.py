from __future__ import annotations

import os
import select
import sys
import threading
from contextlib import contextmanager
from typing import Callable, Iterator


@contextmanager
def ctrl_i_monitor(
    on_interrupt: Callable[[], None],
    on_detach: Callable[[], None] | None = None,
) -> Iterator[None]:
    """Watch for Ctrl+I cancellation and Ctrl+C background detachment while streaming.

    The monitor is enabled only for an interactive POSIX terminal. Other keystrokes
    typed during generation are ignored. ISIG is disabled temporarily so Ctrl+C can be
    handled as a byte instead of terminating BIRO before it can hand off the chat.
    Terminal settings are always restored, including on exceptions.
    """
    if os.name == "nt" or not sys.stdin.isatty():
        yield
        return

    try:
        import termios
        import tty
        fd = sys.stdin.fileno()
        previous = termios.tcgetattr(fd)
    except (ImportError, OSError, ValueError):
        yield
        return

    stop = threading.Event()

    def watch() -> None:
        while not stop.is_set():
            try:
                readable, _, _ = select.select([fd], [], [], 0.05)
                if not readable:
                    continue
                key = os.read(fd, 1)
                if key == b"\x09":  # ASCII HT, produced by Ctrl+I in cbreak mode
                    on_interrupt()
                    return
                if key == b"\x03" and on_detach is not None:
                    on_detach()
                    return
            except (OSError, ValueError):
                return

    try:
        tty.setcbreak(fd)
        current = termios.tcgetattr(fd)
        current[3] &= ~termios.ISIG
        termios.tcsetattr(fd, termios.TCSADRAIN, current)
        thread = threading.Thread(target=watch, name="biro-ctrl-i-monitor", daemon=True)
        thread.start()
        try:
            yield
        finally:
            stop.set()
            thread.join(timeout=0.2)
    finally:
        try:
            termios.tcsetattr(fd, termios.TCSADRAIN, previous)
        except OSError:
            pass
