from __future__ import annotations

import html
import os
from pathlib import Path
from typing import Iterable

# Some Android/mobile terminal emulators never answer ANSI cursor-position queries.
# Mark CPR unsupported up front so prompt_toolkit doesn't print a warning after every redraw.
os.environ.setdefault("PROMPT_TOOLKIT_NO_CPR", "1")

from prompt_toolkit.application import Application, get_app
from prompt_toolkit.completion import Completer, Completion
from prompt_toolkit.document import Document
from prompt_toolkit.formatted_text import FormattedText, HTML
from prompt_toolkit.filters import Condition, to_filter
from prompt_toolkit.key_binding import KeyBindings
from prompt_toolkit.layout import HSplit, Layout, Window
from prompt_toolkit.layout.containers import ConditionalContainer
from prompt_toolkit.layout.dimension import Dimension
from prompt_toolkit.layout.controls import FormattedTextControl
from prompt_toolkit.history import FileHistory
from prompt_toolkit.styles import Style
from prompt_toolkit.widgets import Frame, SearchToolbar, TextArea

from biro.config import config_dir

COMMANDS: dict[str, str] = {
    '/status': 'show workspace, model, chat ID, and activity',
    '/id': 'show this chat ID and its resume command',
    '/model': 'switch model: max or mini',
    '/think': 'toggle the thinking indicator',
    '/new': 'start a new saved conversation',
    '/resume': 'switch to a saved chat by ID',
    '/chats': 'list saved conversations',
    '/open': 'reopen a saved conversation',
    '/history': 'show saved conversation history',
    '/retry': 'send your previous prompt again',
    '/rename': 'rename this saved conversation',
    '/jobs': 'view background tasks',
    '/models': 'choose BIRO Max or BIRO Mini',
    '/paste': 'enter multiline prompt mode',
    '/file': 'attach a local file by path',
    '/image': 'attach a local image by path',
    '/cwd': 'show or change the workspace folder',
    '/connect': 'connect GitHub or Hugging Face',
    '/integrations': 'check GitHub/Hugging Face connection status',
    '/github': 'run a GitHub CLI command',
    '/huggingface': 'run a Hugging Face CLI command',
    '/account': 'show the current BIRO account',
    '/login': 'switch BIRO account',
    '/signup': 'create a BIRO account',
    '/logout': 'sign out on this device',
    '/clear': 'clear the terminal display',
    '/help': 'show all commands and keyboard shortcuts',
    '/exit': 'quit BIRO CLI',
}

_INPUT_HISTORY: FileHistory | None = None
TOGGLE_THINK_SENTINEL = '\x00BIRO_TOGGLE_THINK\x00'
CHAT_PICKER_SENTINEL = '\x00BIRO_CHAT_PICKER\x00'
NEW_CHAT_SENTINEL = '\x00BIRO_NEW_CHAT\x00'
DELETE_CHAT_SENTINEL = '\x00BIRO_DELETE_CHAT\x00'
EXIT_SENTINEL = '\x00BIRO_EXIT\x00'

STYLE = Style.from_dict({
    "input-frame": "#72D6B2",
    "frame.border": "#586D64",
    "frame.label": "bold #E8F0EC",
    "text-area": "#E8F0EC bg:#18211E",
    "completion-menu.completion": "bg:#26332E #E8F0EC",
    "completion-menu.completion.current": "bg:#72D6B2 #14201A bold",
    "completion-menu.meta.completion": "#91A59A bg:#26332E",
    "completion-menu.meta.completion.current": "#18211E bg:#72D6B2",
    "bottom-toolbar": "bg:#18211E #91A59A",
    "suggestions.heading": "bold #72D6B2",
    "suggestions.selected": "bold #14201A bg:#72D6B2",
    "suggestions.item": "#E8F0EC",
    "suggestions.meta": "#91A59A",
    "chat-picker.selected": "bold #14201A bg:#72D6B2",
    "chat-picker.title": "#E8F0EC",
    "chat-picker.meta": "#91A59A",
    "activity.shell": "bold #72D6B2",
    "activity.label": "bold #E5B86F",
    "activity.command": "bg:#303030 #D0D0D0",
    "activity.output": "#91A59A",
})


class SlashCompleter(Completer):
    def get_completions(self, document: Document, complete_event) -> Iterable[Completion]:
        text = document.text_before_cursor
        if text.startswith(("/file ", "/image ")):
            command, path_prefix = text.split(" ", 1)
            from prompt_toolkit.completion.filesystem import PathCompleter
            is_image = command == "/image"
            completer = PathCompleter(
                expanduser=True,
                file_filter=(lambda path: Path(path).is_file() and Path(path).suffix.lower() in {".png", ".jpg", ".jpeg", ".webp", ".gif", ".bmp"}) if is_image else None,
            )
            yield from completer.get_completions(Document(path_prefix), complete_event)
            return
        if text.startswith("/cwd "):
            from prompt_toolkit.completion.filesystem import PathCompleter
            yield from PathCompleter(expanduser=True, only_directories=True).get_completions(
                Document(text.split(" ", 1)[1]), complete_event
            )
            return
        if text.startswith(("/model ", "/models ")):
            options = {"/model max": "BIRO Max · advanced coding", "/model mini": "BIRO Mini · fast everyday model"}
            for option, meta in options.items():
                if option.startswith(text.lower()):
                    yield Completion(option, start_position=-len(text), display_meta=meta)
            return
        if text.startswith("/connect "):
            options = {
                "/connect github": "sign in with GitHub CLI",
                "/connect huggingface": "sign in with Hugging Face CLI",
            }
            for option, meta in options.items():
                if option.startswith(text.lower()):
                    yield Completion(option, start_position=-len(text), display_meta=meta)
            return
        if not text.startswith("/") or " " in text:
            return
        for command, description in COMMANDS.items():
            if command.startswith(text.lower()):
                yield Completion(command, start_position=-len(text), display_meta=description)


def _input_history() -> FileHistory:
    global _INPUT_HISTORY
    if _INPUT_HISTORY is None:
        history_file = config_dir() / "prompt_history"
        history_file.parent.mkdir(parents=True, exist_ok=True)
        _INPUT_HISTORY = FileHistory(str(history_file))
    return _INPUT_HISTORY


def _activity_formatted_text(
    details: list[dict[str, str]],
    expanded: set[int],
    toggle_handler,
) -> FormattedText:
    fragments = []
    for index, item in enumerate(details):
        kind = item.get("kind", "activity")
        if kind == "command":
            label = f"●  EXECUTING SHELL · {item.get('title', '')}"
            style = "class:activity.shell"
        else:
            label = f"●  {kind.upper()} · {item.get('title', '')}"
            style = "class:activity.label"
        fragments.append((style, label, toggle_handler(index)))
        fragments.append(("", "\n"))
        if kind == "command":
            fragments.append(("class:activity.command", f"  $ {item.get('command', '')}\n"))
        if index in expanded and item.get("content"):
            fragments.append(("class:activity.output", f"  {item['content']}\n"))
    return FormattedText(fragments)


def _activity_toggle_handler(expanded: set[int], detail_index: int):
    def toggle(mouse_event):
        if mouse_event.event_type.name == "MOUSE_UP":
            if detail_index in expanded:
                expanded.remove(detail_index)
            else:
                expanded.add(detail_index)
            get_app().invalidate()
    return toggle


def _slash_suggestions(text: str) -> list[tuple[str, str]]:
    """Return matching command hints while the user is still entering a slash command."""
    if not text.startswith("/") or " " in text:
        return []
    lowered = text.lower()
    return [(command, description) for command, description in COMMANDS.items() if command.startswith(lowered)]


def read_chat_picker(chats: list[dict], *, input=None, output=None) -> str | None:
    """Show a keyboard-navigable saved-chat picker. Return the selected ID or None."""
    # Oldest conversations appear first, as requested; API order is preserved for
    # records without timestamps.
    ordered = sorted(
        chats,
        key=lambda chat: str(chat.get("created_at") or chat.get("updated_at") or ""),
    )
    selected = {"index": 0}
    confirm_delete = {"active": False}
    page_size = 14

    def visible_range() -> tuple[int, int]:
        if len(ordered) <= page_size:
            return 0, len(ordered)
        start = min(max(0, selected["index"] - page_size // 2), len(ordered) - page_size)
        return start, start + page_size

    def picker_rows():
        if not ordered:
            return FormattedText([("class:chat-picker.meta", "No saved conversations yet.\n")])
        start, end = visible_range()
        fragments = []
        for index in range(start, end):
            chat = ordered[index]
            title = str(chat.get("title") or "New conversation").replace("\n", " ").strip()
            if len(title) > 64:
                title = title[:61] + "..."
            timestamp = str(chat.get("created_at") or chat.get("updated_at") or "")[:10]
            marker = "› " if index == selected["index"] else "  "
            style = "class:chat-picker.selected" if index == selected["index"] else "class:chat-picker.title"
            fragments.append((style, f"{marker}{title:<66}  {timestamp}\n"))
        if confirm_delete["active"]:
            fragments.append(
                ("class:chat-picker.meta", "\nDelete this chat? Press y to confirm, any other key to cancel.\n")
            )
        return FormattedText(fragments)

    kb = KeyBindings()

    @kb.add("up")
    def _up(event):
        if ordered and not confirm_delete["active"]:
            selected["index"] = (selected["index"] - 1) % len(ordered)
            event.app.invalidate()

    @kb.add("down")
    def _down(event):
        if ordered and not confirm_delete["active"]:
            selected["index"] = (selected["index"] + 1) % len(ordered)
            event.app.invalidate()

    @kb.add("enter")
    def _choose(event):
        if ordered and not confirm_delete["active"]:
            event.app.exit(result=str(ordered[selected["index"]].get("id", "")))

    @kb.add("d")
    def _delete(event):
        if ordered and not confirm_delete["active"]:
            confirm_delete["active"] = True
            event.app.invalidate()

    @kb.add("y")
    def _confirm_delete(event):
        if ordered and confirm_delete["active"]:
            chat_id = str(ordered[selected["index"]].get("id", ""))
            if chat_id:
                event.app.exit(result=f"{DELETE_CHAT_SENTINEL}{chat_id}")

    @kb.add("<any>")
    def _cancel_delete(event):
        if confirm_delete["active"]:
            confirm_delete["active"] = False
            event.app.invalidate()

    @kb.add("escape")
    def _close(event):
        event.app.exit(result=None)

    @kb.add("c-c")
    def _exit(event):
        event.app.exit(result=EXIT_SENTINEL)

    @kb.add("n")
    def _new_chat(event):
        if not confirm_delete["active"]:
            event.app.exit(result=NEW_CHAT_SENTINEL)

    body = Frame(
        Window(FormattedTextControl(picker_rows), height=Dimension(min=3, max=page_size + 2)),
        title=HTML("<b>YOUR CHATS</b>"),
        style="class:input-frame",
    )
    hints = Window(
        FormattedTextControl(HTML('<style fg="#91A59A">↑/↓ navigate  ·  Enter open  ·  n new chat  ·  d delete  ·  Esc back</style>')),
        height=1,
        dont_extend_height=True,
    )
    app = Application(
        layout=Layout(HSplit([body, hints], padding=1)),
        style=STYLE,
        key_bindings=kb,
        full_screen=True,
        erase_when_done=True,
        mouse_support=True,
        input=input,
        output=output,
    )
    try:
        result = app.run()
        return str(result) if result else None
    except (EOFError, KeyboardInterrupt):
        return None


def read_input(
    model_label: str,
    cwd: Path,
    *,
    message_count: int = 0,
    last_elapsed: float = 0.0,
    thinking: bool = False,
    details: list[dict[str, str]] | None = None,
    input=None,
    output=None,
) -> str | None:
    """Render the compact BIRO composer and status strip used between turns."""
    result: dict[str, str] = {"text": ""}
    project = html.escape((cwd.name or str(cwd)).upper())
    model = html.escape(model_label.upper())
    mode = "THINK: ON" if thinking else "CTRL+T: THINK"

    def accept(buffer):
        result["text"] = buffer.text
        get_app().exit(result=buffer.text)
        return True

    search_toolbar = SearchToolbar()
    selection = {"index": 0, "text": ""}
    area = TextArea(
        text="",
        prompt=HTML('<b><style fg="#72D6B2">› </style></b>'),
        multiline=True,
        wrap_lines=True,
        completer=SlashCompleter(),
        # Slash hints are rendered in a stable inline menu below. File and argument
        # completion remain available with Tab so the menu never steals arrow keys.
        complete_while_typing=False,
        history=_input_history(),
        search_field=search_toolbar,
        accept_handler=accept,
        style="class:text-area",
        scrollbar=False,
        # Let very long input wrap to additional rows instead of being cut off.
        height=Dimension(min=1, max=6),
    )
    area.buffer.enable_history_search = to_filter(True)

    def current_suggestions() -> list[tuple[str, str]]:
        text = area.text
        if selection["text"] != text:
            selection["text"] = text
            selection["index"] = 0
        options = _slash_suggestions(text)
        if options:
            selection["index"] %= len(options)
        return options

    def suggestions_text():
        options = current_suggestions()
        if not options:
            return FormattedText([])
        page_start = (selection["index"] // 6) * 6
        fragments = [("class:suggestions.heading", "  COMMANDS  ·  ↑/↓ browse  ·  Tab accept  ·  Enter send\n")]
        for index, (command, description) in enumerate(options[page_start:page_start + 6], page_start):
            style = "class:suggestions.selected" if index == selection["index"] else "class:suggestions.item"
            if len(description) > 34:
                description = description[:31] + "..."
            fragments.append((style, f"  {command:<16} "))
            fragments.append(("class:suggestions.meta", f"{description}\n"))
        if len(options) > 6:
            fragments.append(("class:suggestions.meta", f"  {selection['index'] + 1}/{len(options)} commands · keep using ↑/↓\n"))
        return FormattedText(fragments)

    suggestion_panel = ConditionalContainer(
        Window(FormattedTextControl(suggestions_text), height=Dimension(min=1, max=8)),
        filter=Condition(lambda: bool(current_suggestions())),
    )
    title = HTML(
        f'<style fg="#91A59A">WORKSPACE:</style> '
        f'<b><style fg="#E5B86F">{project}</style></b>'
    )
    composer = Frame(area, title=title, style="class:input-frame", width=None)

    activity_details = details or []
    expanded_details: set[int] = set()

    def toggle_handler(detail_index: int):
        return _activity_toggle_handler(expanded_details, detail_index)

    def activity_text():
        return _activity_formatted_text(activity_details, expanded_details, toggle_handler)

    activity_items = ConditionalContainer(
        Window(
            FormattedTextControl(activity_text, focusable=True, show_cursor=False),
            height=Dimension(min=1, max=10),
            wrap_lines=True,
        ),
        filter=Condition(lambda: bool(activity_details)),
    )

    def status_text():
        return FormattedText([
            ("bold #72D6B2", "MODEL: "),
            ("#E8F0EC", model),
            ("bold #72D6B2", "    MESSAGES: "),
            ("#E8F0EC", str(message_count)),
            ("bold #72D6B2", "    TIME: "),
            ("#E8F0EC", f"{last_elapsed:.1f}s"),
            ("#91A59A", f"    {mode}  ·  / SUGGESTIONS  ·  ← CHATS"),
        ])

    activity_window = Window(
        FormattedTextControl(status_text),
        height=1,
        dont_extend_height=True,
    )
    footer = Frame(
        activity_window,
        style="class:input-frame",
        width=None,
        height=3,
    )
    kb = KeyBindings()

    @kb.add("c-c")
    def _(event):
        event.app.exit(result=EXIT_SENTINEL)

    @kb.add("c-t")
    def _(event):
        event.app.exit(result=TOGGLE_THINK_SENTINEL)

    @kb.add("c-u")
    def _(event):
        buffer = event.current_buffer
        buffer.delete_before_cursor(count=buffer.cursor_position)

    @kb.add("c-k")
    def _(event):
        buffer = event.current_buffer
        buffer.delete_after_cursor(count=len(buffer.text) - buffer.cursor_position)

    @kb.add("enter", filter=Condition(lambda: get_app().current_buffer is area.buffer))
    def _(event):
        event.current_buffer.validate_and_handle()

    composer_focus = Condition(lambda: get_app().current_buffer is area.buffer)

    @kb.add("left", filter=composer_focus)
    def _(event):
        buffer = event.current_buffer
        if not buffer.text and buffer.cursor_position == 0:
            event.app.exit(result=CHAT_PICKER_SENTINEL)
        else:
            buffer.cursor_left()

    @kb.add("up", filter=composer_focus)
    def _(event):
        options = current_suggestions()
        if options:
            selection["index"] = (selection["index"] - 1) % len(options)
            event.app.invalidate()
        else:
            event.current_buffer.history_backward()

    @kb.add("down", filter=composer_focus)
    def _(event):
        options = current_suggestions()
        if options:
            selection["index"] = (selection["index"] + 1) % len(options)
            event.app.invalidate()
        else:
            event.current_buffer.history_forward()

    @kb.add("tab", filter=composer_focus)
    def _(event):
        options = current_suggestions()
        if options:
            command = options[selection["index"]][0]
            event.current_buffer.text = command
            event.current_buffer.cursor_position = len(command)
            event.app.invalidate()
        elif event.current_buffer.completer:
            event.current_buffer.start_completion(select_first=False)

    app = Application(
        layout=Layout(HSplit([suggestion_panel, composer, search_toolbar, activity_items, footer], padding=0)),
        style=STYLE,
        key_bindings=kb,
        full_screen=False,
        erase_when_done=True,
        mouse_support=True,
        input=input,
        output=output,
        min_redraw_interval=0.04,
    )
    try:
        return str(app.run() or "")
    except (EOFError, KeyboardInterrupt):
        return None
