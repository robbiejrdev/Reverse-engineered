from __future__ import annotations

from difflib import SequenceMatcher

from pygments import lex
from pygments.lexers import TextLexer, get_lexer_for_filename
from pygments.styles import get_style_by_name
from pygments.util import ClassNotFound
from rich import box
from rich.console import Console
from rich.panel import Panel
from rich.style import Style
from rich.text import Text

_MAX_PREVIEW_LINES = 10
_SYNTAX_STYLE = get_style_by_name("monokai")


def _changed_lines(before: list[str], after: list[str]) -> tuple[list[tuple[str, int, str]], int, int]:
    """Return changed source lines with their old/new one-based line numbers."""
    records: list[tuple[str, int, str]] = []
    additions = 0
    deletions = 0
    matcher = SequenceMatcher(None, before, after, autojunk=False)
    for tag, old_start, old_end, new_start, new_end in matcher.get_opcodes():
        if tag == "equal":
            continue
        if tag in {"replace", "delete"}:
            for index in range(old_start, old_end):
                records.append(("-", index + 1, before[index]))
                deletions += 1
        if tag in {"replace", "insert"}:
            for index in range(new_start, new_end):
                records.append(("+", index + 1, after[index]))
                additions += 1
    return records, additions, deletions


def _preview_indexes(count: int, limit: int) -> list[int]:
    if limit <= 0:
        return []
    if count <= limit:
        return list(range(count))
    if limit <= 1:
        return [count // 2]
    # Spread the preview across the complete diff so distant edits still point
    # to their real source lines instead of always showing only the file's start.
    return sorted({round(index * (count - 1) / (limit - 1)) for index in range(limit)})


def _highlight_line(line: str, lexer, background: str, max_chars: int) -> Text:
    clipped = len(line) > max_chars
    source = line[:max_chars] if clipped else line
    result = Text()
    for token, value in lex(source, lexer):
        value = value.rstrip("\r\n")
        if not value:
            continue
        attributes = _SYNTAX_STYLE.style_for_token(token)
        color = attributes.get("color")
        result.append(
            value,
            Style(
                color=f"#{color}" if color else "#E8F0EC",
                bgcolor=background,
                bold=bool(attributes.get("bold")),
                italic=bool(attributes.get("italic")),
                underline=bool(attributes.get("underline")),
            ),
        )
    if clipped:
        result.append("…", style=Style(color="#E8F0EC", bgcolor=background, dim=True))
    return result


def print_file_diff(
    console: Console,
    path: str,
    before: str | None,
    after: str,
    *,
    max_lines: int = _MAX_PREVIEW_LINES,
) -> None:
    """Print a syntax-highlighted, line-numbered preview of at most ten edits."""
    if before is None:
        message = Text(f"Updated {path}; previous content is not readable as UTF-8, so no text diff is available.")
        console.print(Panel.fit(message, border_style="#586D64", box=box.SIMPLE))
        return

    before_lines = before.splitlines()
    after_lines = after.splitlines()
    records, additions, deletions = _changed_lines(before_lines, after_lines)
    if not records:
        console.print(Panel.fit(Text(f"No content changes · {path}"), border_style="#586D64", box=box.SIMPLE))
        return

    limit = max(0, min(_MAX_PREVIEW_LINES, int(max_lines)))
    indexes = _preview_indexes(len(records), limit)
    try:
        lexer = get_lexer_for_filename(path, stripnl=False, ensurenl=False)
    except ClassNotFound:
        lexer = TextLexer(stripnl=False, ensurenl=False)

    code_width = max(12, min(180, console.width - 14))
    rendered = Text()
    for index in indexes:
        marker, line_number, content = records[index]
        background = "#183C30" if marker == "+" else "#432A35"
        foreground = "#9EE3C1" if marker == "+" else "#E7A8B1"
        rendered.append(f"{marker}{line_number:>5} │ ", style=f"bold {foreground} on {background}")
        rendered.append_text(_highlight_line(content, lexer, background, code_width))
        rendered.append("\n")

    omitted = len(records) - len(indexes)
    if omitted:
        rendered.append(f"… {omitted} changed lines omitted from this preview.\n", style="dim")
    title = f"DIFF · {path} · +{additions} −{deletions}"
    console.print(Panel(rendered, title=title, border_style="#586D64", box=box.SIMPLE, padding=(0, 1)))
