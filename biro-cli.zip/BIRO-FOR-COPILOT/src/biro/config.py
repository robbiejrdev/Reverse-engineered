from __future__ import annotations

import json
import os
import stat
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any

DEFAULT_API_URL = "https://api.robbiejr.site"
VALID_MODELS = ("biro-max", "biro-mini")


def config_dir() -> Path:
    override = os.getenv("BIRO_CONFIG_DIR")
    if override:
        return Path(override).expanduser()
    # Use standard XDG config paths on Linux; fall back to ~/.config/biro.
    base = Path(os.getenv("XDG_CONFIG_HOME", Path.home() / ".config")).expanduser()
    return base / "biro"


@dataclass
class UserConfig:
    api_url: str = DEFAULT_API_URL
    access_token: str = ""
    email: str = ""
    display_name: str = ""
    model: str = "biro-max"
    current_chat_id: str = ""

    @classmethod
    def load(cls) -> "UserConfig":
        path = config_dir() / "config.json"
        data: dict[str, Any] = {}
        if path.exists():
            try:
                loaded = json.loads(path.read_text(encoding="utf-8"))
                if isinstance(loaded, dict):
                    data = loaded
            except (OSError, json.JSONDecodeError):
                # Do not silently overwrite a malformed token-bearing config file.
                raise ValueError(f"Could not read {path}. Back it up or remove it to recreate the config.")
        api_url = os.getenv("BIRO_API_URL", data.get("api_url", DEFAULT_API_URL))
        return cls(
            api_url=str(api_url).rstrip("/"),
            access_token=str(data.get("access_token", "")),
            email=str(data.get("email", "")),
            display_name=str(data.get("display_name", "")),
            model=str(os.getenv("BIRO_MODEL", data.get("model", "biro-max"))),
            current_chat_id=str(data.get("current_chat_id", "")),
        )

    def save(self) -> None:
        directory = config_dir()
        directory.mkdir(parents=True, exist_ok=True)
        try:
            directory.chmod(0o700)
        except OSError:
            pass
        path = directory / "config.json"
        tmp = path.with_suffix(".tmp")
        payload = json.dumps(asdict(self), indent=2).encode("utf-8")
        # Create the token-bearing temporary file with restrictive permissions from
        # the start, rather than chmodding it only after writing the secret.
        flags = os.O_WRONLY | os.O_CREAT | os.O_TRUNC
        fd = os.open(tmp, flags, 0o600)
        try:
            with os.fdopen(fd, "wb") as handle:
                handle.write(payload)
                handle.flush()
                os.fsync(handle.fileno())
        except Exception:
            try:
                tmp.unlink(missing_ok=True)
            except OSError:
                pass
            raise
        tmp.replace(path)
        try:
            path.chmod(0o600)
        except OSError:
            pass

    def clear_session(self) -> None:
        self.access_token = ""
        self.email = ""
        self.display_name = ""
        self.current_chat_id = ""
        self.save()


def validate_model(model: str) -> str:
    key = model.strip().lower().replace("_", "-")
    aliases = {"max": "biro-max", "mini": "biro-mini", "biro max": "biro-max", "biro mini": "biro-mini"}
    key = aliases.get(key, key)
    if key not in VALID_MODELS:
        raise ValueError("Choose BIRO Max (`max`) or BIRO Mini (`mini`).")
    return key
