from __future__ import annotations

import base64
import json
import threading
from collections.abc import Iterator
from typing import Any
from urllib.parse import urlencode

import httpx

from biro.config import UserConfig


class BiroAPIError(RuntimeError):
    def __init__(self, message: str, status_code: int | None = None):
        super().__init__(message)
        self.status_code = status_code


def _detail(response: httpx.Response) -> str:
    try:
        value = response.json()
        detail = value.get("detail") if isinstance(value, dict) else None
        if isinstance(detail, str) and detail.strip():
            return detail.strip()
        if isinstance(detail, list):
            return "; ".join(str(item.get("msg", item)) for item in detail)
    except (ValueError, json.JSONDecodeError):
        pass
    return f"Request failed (HTTP {response.status_code})."


class BiroAPI:
    """Small typed wrapper for the existing BIRO account/chat API."""

    def __init__(self, config: UserConfig, client: httpx.Client | None = None):
        self.config = config
        self._external_client = client is not None
        self._interrupt_requested = threading.Event()
        self._active_stream_response: httpx.Response | None = None
        self.http = client or httpx.Client(
            base_url=config.api_url.rstrip("/") + "/",
            timeout=httpx.Timeout(None, connect=15.0),
            follow_redirects=True,
            headers={"User-Agent": "BIRO-CLI/1.0"},
        )

    def close(self) -> None:
        self.interrupt_current_stream()
        if not self._external_client:
            self.http.close()

    def clear_stream_interrupt(self) -> None:
        self._interrupt_requested.clear()

    def interrupt_current_stream(self) -> None:
        """Request stream cancellation and close the active response when possible."""
        self._interrupt_requested.set()
        response = self._active_stream_response
        if response is not None:
            try:
                response.close()
            except Exception:
                pass

    def _request(self, method: str, path: str, *, auth: bool = True, **kwargs: Any) -> httpx.Response:
        headers = dict(kwargs.pop("headers", {}) or {})
        if auth and self.config.access_token:
            headers["Authorization"] = f"Bearer {self.config.access_token}"
        try:
            response = self.http.request(method, path.lstrip("/"), headers=headers, **kwargs)
        except httpx.TimeoutException:
            raise BiroAPIError("BIRO connection timed out while connecting. Please check your network and retry.") from None
        except httpx.TransportError as exc:
            raise BiroAPIError(f"Couldn't reach BIRO at {self.config.api_url}: {exc.__class__.__name__}. Check your connection and API URL.") from None
        if response.is_error:
            detail = _detail(response)
            if response.status_code == 401 and auth:
                raise BiroAPIError("Your BIRO session is invalid or expired. Run `/login` to sign in again.", 401)
            raise BiroAPIError(detail, response.status_code)
        return response

    def signup(self, display_name: str, email: str, password: str) -> dict[str, Any]:
        response = self._request("POST", "/api/v1/auth/signup", auth=False, json={
            "display_name": display_name, "email": email, "password": password,
        })
        payload = response.json()
        self._accept_session(payload)
        return payload

    def login(self, email: str, password: str) -> dict[str, Any]:
        response = self._request("POST", "/api/v1/auth/login", auth=False, json={
            "email": email, "password": password,
        })
        payload = response.json()
        self._accept_session(payload)
        return payload

    def _accept_session(self, payload: dict[str, Any]) -> None:
        token = payload.get("access_token")
        user = payload.get("user") or {}
        if not token or not isinstance(user, dict):
            raise BiroAPIError("The server returned an unexpected sign-in response.")
        # A newly issued session may belong to a different account; never carry
        # a prior account's selected conversation into the new session.
        if self.config.access_token != str(token):
            self.config.current_chat_id = ""
        self.config.access_token = str(token)
        self.config.email = str(user.get("email", ""))
        self.config.display_name = str(user.get("display_name", ""))
        self.config.save()

    def me(self) -> dict[str, Any]:
        return self._request("GET", "/api/v1/me").json()

    def models(self, model: str) -> dict[str, Any]:
        query = urlencode({"provider": model})
        return self._request("GET", f"/api/v1/ai/models?{query}").json()

    def list_chats(self) -> list[dict[str, Any]]:
        return self._request("GET", "/api/v1/chats").json()

    def get_chat(self, chat_id: str) -> dict[str, Any]:
        return self._request("GET", f"/api/v1/chats/{chat_id}").json()

    def create_chat(self, title: str = "New conversation", *, select: bool = True) -> dict[str, Any]:
        chat = self._request("POST", "/api/v1/chats", json={"title": title}).json()
        if select:
            self.config.current_chat_id = str(chat["id"])
            self.config.save()
        return chat

    def update_chat(self, chat_id: str, **fields: Any) -> dict[str, Any]:
        return self._request("PATCH", f"/api/v1/chats/{chat_id}", json=fields).json()

    def delete_chat(self, chat_id: str) -> None:
        self._request("DELETE", f"/api/v1/chats/{chat_id}")
        if self.config.current_chat_id == chat_id:
            self.config.current_chat_id = ""
            self.config.save()

    def list_messages(self, chat_id: str) -> list[dict[str, Any]]:
        return self._request("GET", f"/api/v1/chats/{chat_id}/messages").json()

    def generate_image(self, chat_id: str, prompt: str) -> dict[str, Any]:
        return self._request("POST", f"/api/v1/chats/{chat_id}/images", json={"prompt": prompt}).json()

    def download_artifact(self, chat_id: str, artifact_id: str) -> tuple[bytes, str]:
        response = self._request("GET", f"/api/v1/chats/{chat_id}/artifacts/{artifact_id}/download")
        return response.content, response.headers.get("content-type", "application/octet-stream").split(";", 1)[0]

    @staticmethod
    def _build_prompt_payload(prompt: str, model: str, instructions: str = "", attachments: list[dict[str, Any]] | None = None) -> dict[str, Any]:
        """Build a BIRO chat payload with optional local file attachments and long text.

        The current model-message builder forwards up to 80k extracted characters per
        attachment, with at most four attachments. Chunk to that exact safe boundary so
        the backend doesn't silently truncate an attachment.
        """
        attached = list(attachments or [])
        if len(attached) > 4:
            raise BiroAPIError("Attach no more than four files to a single BIRO message.")
        if len(instructions) > 4000:
            raise BiroAPIError(
                "The deployed BIRO backend accepts at most 4,000 instruction characters. "
                "The CLI will not silently truncate system instructions."
            )
        if len(prompt) <= 12_000:
            payload = {"message": prompt, "provider": model, "attachments": attached}
            if instructions:
                payload["instructions"] = instructions
            return payload
        chunk_size = 80_000
        parts = [prompt[i:i + chunk_size] for i in range(0, len(prompt), chunk_size)]
        if len(parts) > 4 and not attached:
            raise BiroAPIError(
                "The current BIRO backend forwards at most 320,000 characters from long text attachments in one request. "
                "Split the prompt or expand the backend schema."
            )
        if len(parts) + len(attached) > 4:
            raise BiroAPIError(
                "The current BIRO backend accepts at most four attachments per message, including long-prompt parts. "
                "Shorten the prompt or attach fewer files."
            )
        text_attachments = []
        for index, part in enumerate(parts, 1):
            raw = part.encode("utf-8")
            text_attachments.append({
                "filename": f"prompt-part-{index:02d}.txt",
                "mime_type": "text/plain",
                "data_base64": base64.b64encode(raw).decode("ascii"),
                "text_content": part,
                "vision_frames": [],
            })
        instruction = (
            "The attached prompt-part files contain the user's full request, in numeric order. "
            "Read every part as one request before answering. Preserve requirements across all parts."
        )
        payload = {"message": instruction, "provider": model, "attachments": attached + text_attachments}
        if instructions:
            payload["instructions"] = instructions
        return payload

    def stream_message(self, chat_id: str, prompt: str, model: str, instructions: str = "", attachments: list[dict[str, Any]] | None = None) -> Iterator[dict[str, Any]]:
        payload = self._build_prompt_payload(prompt, model, instructions, attachments)
        if self._interrupt_requested.is_set():
            yield {"type": "interrupted"}
            return
        headers = {"Authorization": f"Bearer {self.config.access_token}", "Accept": "application/x-ndjson"}
        try:
            with self.http.stream(
                "POST", f"api/v1/chats/{chat_id}/messages/stream", headers=headers, json=payload,
                timeout=httpx.Timeout(None, connect=15.0),
            ) as response:
                self._active_stream_response = response
                if response.is_error:
                    body = response.read()
                    wrapped = httpx.Response(response.status_code, content=body, request=response.request)
                    detail = _detail(wrapped)
                    if response.status_code == 401:
                        raise BiroAPIError("Your BIRO session is invalid or expired. Run `/login` to sign in again.", 401)
                    raise BiroAPIError(detail, response.status_code)
                for line in response.iter_lines():
                    if self._interrupt_requested.is_set():
                        yield {"type": "interrupted"}
                        return
                    if not line.strip():
                        continue
                    try:
                        event = json.loads(line)
                    except json.JSONDecodeError:
                        continue
                    if isinstance(event, dict):
                        if event.get("type") == "error":
                            raise BiroAPIError(str(event.get("detail") or "BIRO stream failed."))
                        yield event
        except BiroAPIError:
            raise
        except httpx.TimeoutException:
            if self._interrupt_requested.is_set():
                yield {"type": "interrupted"}
                return
            raise BiroAPIError("BIRO connection timed out while connecting. Your last message may already be saved; check chat history before retrying.") from None
        except (httpx.StreamError, httpx.TransportError, OSError):
            if self._interrupt_requested.is_set():
                yield {"type": "interrupted"}
                return
            raise BiroAPIError("BIRO connection interrupted. Check chat history before retrying to avoid duplicate requests.") from None
        finally:
            self._active_stream_response = None
