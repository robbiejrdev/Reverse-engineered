"""BIRO CLI terminal agent."""
__version__ = "1.2.1"
