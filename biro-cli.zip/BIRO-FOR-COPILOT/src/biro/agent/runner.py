from __future__ import annotations

import base64
import difflib
import re
import time
import threading
from contextlib import nullcontext
from pathlib import Path
from typing import Any

from rich.console import Console, Group
from rich.live import Live
from rich.spinner import Spinner
from rich import box
from rich.markup import escape
from rich.markdown import Markdown
from rich.panel import Panel
from rich.syntax import Syntax
from rich.table import Table
from rich.text import Text

from biro.api.client import BiroAPI, BiroAPIError
from biro.agent.prompts import SYSTEM_PROMPT
from biro.agent.tools import WorkspaceTools, has_malformed_action, split_tool_blocks
from biro.config import UserConfig, validate_model
from biro.ui.interrupt import ctrl_i_monitor

console = Console(highlight=False, soft_wrap=True)
_TITLE_CLEAN = re.compile(r"\s+")
_BACKGROUND_COMPLETE = "BIRO_BACKGROUND_COMPLETE"


def _format_elapsed(seconds: float) -> str:
    """Format elapsed time as human-readable string (e.g., '1h 30m 45s', '2m 30s', '45s')."""
    total = int(seconds)
    hours = total // 3600
    minutes = (total % 3600) // 60
    secs = total % 60
    parts = []
    if hours:
        parts.append(f"{hours}h")
    if minutes or hours:
        parts.append(f"{minutes}m")
    parts.append(f"{secs}s")
    return " ".join(parts)


def _reported_token_count(value: Any) -> int | None:
    """Return a backend-reported token total, never an estimate."""
    if not isinstance(value, dict):
        return None
    usage = value.get("usage")
    if not isinstance(usage, dict):
        usage = value.get("token_usage")
    if not isinstance(usage, dict):
        assistant = value.get("assistant_message")
        usage = assistant.get("usage") if isinstance(assistant, dict) else None
    if not isinstance(usage, dict):
        return None

    total = usage.get("total_tokens")
    if isinstance(total, int) and not isinstance(total, bool) and total >= 0:
        return total
    prompt = usage.get("prompt_tokens", usage.get("input_tokens"))
    completion = usage.get("completion_tokens", usage.get("output_tokens"))
    if (
        isinstance(prompt, int) and not isinstance(prompt, bool) and prompt >= 0
        and isinstance(completion, int) and not isinstance(completion, bool) and completion >= 0
    ):
        return prompt + completion
    return None


def _estimate_token_count(text: str) -> int:
    """Estimate tokens from text length when the backend omits usage metrics."""
    return (len(text) + 3) // 4


class _AgentDashboard:
    """Live bottom-of-terminal UI; stream preview redraws in place, never as new transcript rows."""
    def __init__(self, agent: "Agent"):
        self.agent = agent
        self.spinner = Spinner("dots", style="#72D6B2")

    def __rich_console__(self, render_console, options):
        agent = self.agent
        items = []
        # This is a redrawable preview. Rich Live repaints it in the same terminal area
        # on every refresh, so streamed tokens are not appended as separate messages.
        if agent.stream_preview.strip():
            items.append(Markdown(agent.stream_preview))
        if agent.think and agent._active_started:
            heading = Text("THINKING  ·  ", style="bold #72D6B2")
            heading.append(agent.thinking_title or "Planning next step", style="#E8F0EC")
            items.append(Panel(heading, border_style="#586D64", box=box.ROUNDED, padding=(0, 1)))

        activity = Table.grid(padding=(0, 1), expand=False)
        if agent._active_started:
            activity.add_row(self.spinner, Text(f"{agent.working_title} · working", style="#E8F0EC"))
        else:
            activity.add_row(Text("●", style="#72D6B2"), Text("Ready for the next task", style="#91A59A"))
        items.append(activity)

        workspace = Text("WORKSPACE: ", style="bold #91A59A")
        workspace.append((agent.tools.cwd.name or str(agent.tools.cwd)).upper(), style="bold #E5B86F")
        items.append(Panel(Text("›", style="bold #72D6B2"), title=workspace, border_style="#72D6B2", box=box.ROUNDED, padding=(0, 1)))

        elapsed = (time.monotonic() - agent._active_started) if agent._active_started else agent.last_elapsed
        status = Text()
        status.append("MODEL: ", style="bold #72D6B2")
        status.append(agent.model_label.upper(), style="#E8F0EC")
        status.append("    MESSAGES: ", style="bold #72D6B2")
        status.append(str(agent.message_count), style="#E8F0EC")
        status.append("    TIME: ", style="bold #72D6B2")
        status.append(_format_elapsed(elapsed), style="#E8F0EC")
        status.append("    ", style="dim")
        status.append("THINK: ON" if agent.think else "CTRL+T: THINK", style="#91A59A")
        status.append("    /HELP", style="#91A59A")
        items.append(Panel(status, border_style="#586D64", box=box.SQUARE, padding=(0, 1)))
        yield Group(*items)


class Agent:
    def __init__(self, api: BiroAPI, config: UserConfig, cwd: Path, *, think: bool = False,
                 auto_approve: bool = True, confirm_all: bool = False, max_steps: int = 0,
                 deep_research: bool = False):
        self.api = api
        self.config = config
        self.cwd = cwd.resolve()
        self.think = think
        self.max_steps = max_steps
        self.deep_research = deep_research
        self.tools = WorkspaceTools(self.cwd, auto_approve=auto_approve, confirm_all=confirm_all)
        self.message_count = 0
        self.last_elapsed = 0.0
        self.working_title = "Ready"
        self.thinking_title = "Planning next step"
        self._active_started = 0.0
        self._interrupt_requested = threading.Event()
        self._detach_requested = threading.Event()
        self.detached = False
        self._live = None
        self.stream_preview = ""
        self.details: list[dict[str, str]] = []
        self.reported_tokens_used = 0
        self.token_usage_complete = True
        self.session_token_count = 0
        self.session_token_count_approximate = False
        self.session_lines_added = 0
        self.session_lines_deleted = 0

    def _update_stream_preview(self, response: str) -> None:
        """Update the live preview while keeping executable tool payloads hidden."""
        self.stream_preview = _safe_stream_preview(response)
        if self._live is not None:
            # Live owns one region at the bottom of the terminal; refresh that region
            # instead of printing a new input/status panel for every token.
            self._live.update(_AgentDashboard(self), refresh=False)

    def interrupt(self) -> None:
        self._interrupt_requested.set()
        interrupt = getattr(self.api, "interrupt_current_stream", None)
        if callable(interrupt):
            interrupt()

    def detach(self) -> None:
        self._detach_requested.set()
        interrupt = getattr(self.api, "interrupt_current_stream", None)
        if callable(interrupt):
            interrupt()

    def _set_working_title(self, title: str) -> None:
        clean = _TITLE_CLEAN.sub(" ", str(title)).strip()
        if clean:
            self.working_title = clean[:160]

    def send(self, prompt: str, *, attachments: list[dict[str, Any]] | None = None) -> int:
        """Run one user turn with a transient live dashboard and incremental response preview."""
        started = time.monotonic()
        self._active_started = started
        self._detach_requested.clear()
        self.detached = False
        self.details = []
        self._interrupt_requested.clear()
        clear_interrupt = getattr(self.api, "clear_stream_interrupt", None)
        if callable(clear_interrupt):
            clear_interrupt()
        self._set_working_title("Planning response")
        self.thinking_title = "Planning next step"
        self.stream_preview = ""
        live_context = (
            # The live dashboard replaces itself while active, then disappears.
            # Only the actual chat response remains in scrollback; the composer and
            # status bar are drawn once by read_input() for the next turn.
            Live(_AgentDashboard(self), console=console, refresh_per_second=20, transient=True,
                 vertical_overflow="visible") if console.is_terminal else nullcontext()
        )
        try:
            with live_context as live:
                self._live = live if console.is_terminal else None
                try:
                    with ctrl_i_monitor(self.interrupt, self.detach):
                        return self._send_impl(prompt, attachments=attachments)
                finally:
                    # Finalize the pinned dashboard before Rich restores the terminal.
                    self.last_elapsed = time.monotonic() - started
                    self._active_started = 0.0
                    self._set_working_title("Ready")
                    if self._live is not None:
                        self._live.update(_AgentDashboard(self), refresh=True)
        finally:
            self._live = None
            self.last_elapsed = time.monotonic() - started
            self._active_started = 0.0
            self._set_working_title("Ready")
            self.stream_preview = ""

    @property
    def model(self) -> str:
        return validate_model(self.config.model)

    @property
    def model_label(self) -> str:
        return "BIRO Max" if self.model == "biro-max" else "BIRO Mini"

    def system_prompt(self) -> str:
        prompt = SYSTEM_PROMPT.format(cwd=self.tools.cwd, model_label=self.model_label)
        if self.deep_research:
            prompt += (
                "\n\n## Background task quality\n"
                "This is a background job. Do not rush: thoroughly inspect relevant files and requirements, "
                "research uncertain or time-sensitive facts with available tools, compare evidence, and verify "
                "the implementation with appropriate checks. Take the time and action rounds needed for a "
                "complete, reliable result; do not stop at a superficial answer or skip validation. "
                "Be efficient in execution: avoid repeated inspections and progress-only narration; move "
                "directly from findings to implementation and verification, and keep interim user-facing "
                "responses concise. "
                f"Do not finish with progress narration. After the requested work and verification are truly "
                f"complete, end your final response with the exact standalone marker `{_BACKGROUND_COMPLETE}`. "
                "If more work remains, use actions and do not emit the completion marker."
            )
        return prompt

    def ensure_chat(self) -> dict[str, Any]:
        chat_id = self.config.current_chat_id
        if chat_id:
            try:
                chat = self.api.get_chat(chat_id)
                return chat
            except BiroAPIError as exc:
                if exc.status_code not in {404, 401}:
                    raise
                self.config.current_chat_id = ""
                self.config.save()
        return self.api.create_chat()

    def _conversation_memory_attachments(
        self, chat_id: str, prompt: str, attachments: list[dict[str, Any]] | None
    ) -> list[dict[str, Any]]:
        try:
            list_messages = getattr(self.api, "list_messages", None)
            if not callable(list_messages):
                return []
            messages = list_messages(chat_id)
        except (BiroAPIError, AttributeError):
            return []
        if len(messages) <= 20:
            return []
        earlier = messages[:-20]
        transcript = []
        for message in earlier:
            if not isinstance(message, dict):
                continue
            content = message.get("content")
            if isinstance(content, str) and content.strip():
                role = str(message.get("role", "message")).upper()
                transcript.append(f"{role}: {content}")
        text = "\n\n".join(transcript)
        prompt_parts = 0 if len(prompt) <= 12_000 else (len(prompt) + 79_999) // 80_000
        slots = max(0, 4 - len(attachments or []) - prompt_parts)
        limit = slots * 80_000
        if not text or not limit:
            return []
        if len(text) > limit:
            marker = "[Earlier messages omitted to fit the backend attachment limit. Recent earlier context follows.]\n"
            text = marker + text[-(limit - len(marker)): ]
        parts = [text[index:index + 80_000] for index in range(0, len(text), 80_000)]
        return [
            {
                "filename": f"biro-memory-part-{index:02d}.txt",
                "mime_type": "text/plain",
                "data_base64": base64.b64encode(part.encode("utf-8")).decode("ascii"),
                "text_content": part,
                "vision_frames": [],
            }
            for index, part in enumerate(parts, 1)
        ]

    def _send_impl(self, prompt: str, *, attachments: list[dict[str, Any]] | None = None) -> int:
        if not prompt.strip():
            console.print("[dim]Nothing to send.[/dim]")
            return 0
        started = time.monotonic()
        self.message_count += 1
        try:
            chat = self.ensure_chat()
            needs_model_title = str(chat.get("title") or "New conversation").strip().lower() in {
                "", "new conversation", "untitled",
            }
            if needs_model_title:
                needs_model_title = not self.api.list_messages(chat["id"])
            current_prompt = prompt
            current_attachments = list(attachments or [])
            step = 0
            protocol_retries = 0
            completion_retries = 0
            while self.max_steps <= 0 or step < self.max_steps:
                self.stream_preview = ""
                if self._live is not None:
                    self._live.update(_AgentDashboard(self), refresh=False)
                response_parts: list[str] = []
                saw_done = False
                saw_interrupted = False
                request_token_usage: int | None = None
                title_probe = ""
                step_title_shown = False
                self._set_working_title("Thinking")
                memory_attachments = self._conversation_memory_attachments(
                    chat["id"], current_prompt, current_attachments
                )
                request_attachments = current_attachments + memory_attachments
                try:
                    for event in self.api.stream_message(
                        chat["id"], current_prompt, self.model,
                        instructions=self.system_prompt(), attachments=request_attachments,
                    ):
                        token_count = _reported_token_count(event)
                        if token_count is not None:
                            request_token_usage = token_count
                        kind = event.get("type")
                        if kind == "thinking":
                            # Never print/store provider thought text in the terminal. It can
                            # contain internal instructions. Only accept an explicit short label.
                            if self.think:
                                hint = event.get("title") or event.get("summary") or event.get("label")
                                if isinstance(hint, str) and hint.strip():
                                    self.thinking_title = _TITLE_CLEAN.sub(" ", hint).strip()[:90]
                                    self.details.append({
                                        "kind": "thinking",
                                        "title": self.thinking_title,
                                        "content": self.thinking_title,
                                    })
                        elif kind == "delta":
                            fragment = str(event.get("text", ""))
                            response_parts.append(fragment)
                            self._update_stream_preview("".join(response_parts))
                            # Keep generated source hidden during the stream. Only expose a
                            # concise action title while the model is preparing a tool call.
                            if not step_title_shown:
                                title_probe = (title_probe + fragment)[-2048:]
                                title_match = re.search(r"```tool\s*\ntitle:\s*([^\r\n]+)", title_probe)
                                if not title_match:
                                    title_match = re.search(r'"title"\s*:\s*"([^"\n]{1,100})"', title_probe)
                                if title_match:
                                    title = title_match.group(1).strip()[:100]
                                    self._set_working_title(title)
                                    if self.think:
                                        self.thinking_title = title
                                    step_title_shown = True
                        elif kind == "done":
                            saw_done = True
                            assistant = event.get("assistant_message") or {}
                            # Prefer the persisted final content when it is more complete
                            # than the deltas. Some stream adapters can end early while
                            # the final message record still contains the full response.
                            final_content = assistant.get("content")
                            streamed_content = "".join(response_parts)
                            if isinstance(final_content, str) and len(final_content) >= len(streamed_content):
                                response_parts = [final_content]
                            self._update_stream_preview("".join(response_parts))
                        elif kind == "interrupted":
                            saw_interrupted = True
                            break
                except BiroAPIError:
                    raise

                if request_token_usage is None:
                    request_token_usage = _estimate_token_count(
                        current_prompt + "".join(response_parts)
                    )
                    self.session_token_count_approximate = True
                    self.token_usage_complete = False
                else:
                    self.reported_tokens_used += request_token_usage
                self.session_token_count += request_token_usage

                if saw_interrupted or self._interrupt_requested.is_set():
                    if self._detach_requested.is_set():
                        return self._handoff_after_interrupt(prompt)
                    console.print("Response interrupted. BIRO stopped the active generation; no partial action was executed.")
                    return 130

                response = "".join(response_parts)
                if not response.strip() and not saw_done:
                    console.print("[red]BIRO returned no response.[/red]")
                    return 1

                visible, blocks = split_tool_blocks(response)
                if not blocks:
                    if has_malformed_action(response):
                        if protocol_retries < 4:
                            protocol_retries += 1
                            current_attachments = []
                            current_prompt = (
                                "ACTION_PROTOCOL_REPAIR: Your previous response attempted to request a local action, "
                                "but the CLI could not parse a complete valid action block, so nothing was executed. "
                                "Retry now with exactly one complete fenced `biro-action` JSON block. Use valid JSON, "
                                "a supported action, every required field, and the closing triple-backtick fence. "
                                "For any file creation or edit, use the `write_file` action with the complete file "
                                "body; never use `cat <<EOF`, shell redirection, or shell to write source files. "
                                "Every path must name one concrete file or directory. Never use brace expansion "
                                "or comma-separated brace paths such as `{src,include,tests,examples}`; use one "
                                "explicit path per action. "
                                "For an image use action=generate_image with prompt and optional workspace-relative path. "
                                "Do not repeat malformed syntax and do not claim the action ran."
                            )
                            step += 1
                            continue
                        console.print("[red]BIRO couldn't produce a valid complete action block after four repair attempts. No local action was executed.[/red]")
                        return 1
                    if self.deep_research:
                        if visible.rstrip().endswith(_BACKGROUND_COMPLETE):
                            visible = visible.rstrip()[:-len(_BACKGROUND_COMPLETE)].rstrip()
                        else:
                            if completion_retries >= 4:
                                console.print(
                                    "[red]Background agent stopped without confirming task completion. "
                                    "The job is marked failed rather than complete.[/red]"
                                )
                                return 1
                            completion_retries += 1
                            current_attachments = []
                            current_prompt = (
                                "BACKGROUND_TASK_INCOMPLETE: Your last response was progress narration, not a "
                                "completion report. Continue the requested work now using BIRO actions. Inspect "
                                "the actual files and requirements, make the needed changes, run appropriate "
                                "verification, and only when fully finished provide a concise summary ending "
                                f"with the standalone marker `{_BACKGROUND_COMPLETE}`. Do not claim completion "
                                "or emit the marker while work remains."
                            )
                            step += 1
                            continue
                    if visible.strip():
                        if needs_model_title:
                            proposed_title = title_from_response(visible, fallback=prompt)
                            if proposed_title:
                                try:
                                    self.api.update_chat(chat["id"], title=proposed_title)
                                    needs_model_title = False
                                except BiroAPIError:
                                    # A title is cosmetic; keep the requested work moving
                                    # if the optional metadata update fails.
                                    pass
                        self._set_working_title("Response complete")
                        # Replace the live preview with one durable transcript message.
                        # The transient dashboard is cleared on exit, so composer/status
                        # panels never accumulate in scrollback.
                        self.stream_preview = ""
                        if self._live is not None:
                            self._live.update(_AgentDashboard(self), refresh=True)
                        console.print(Markdown(visible))
                    return 0

                # A valid action is concrete progress; earlier completion nudges
                # must not consume the retry budget for later stages of the task.
                if self.deep_research:
                    completion_retries = 0

                # A user attachment is relevant to the first model turn only. The backend
                # persists the upload and carries its extracted context in the conversation.
                current_attachments = []
                block = blocks[0]
                model_action_title = str(block.get("title") or "").strip()
                action_title_raw = model_action_title or "BIRO action"
                action_title = escape(action_title_raw)
                action = str(block.get("action", ""))
                if needs_model_title and model_action_title:
                    try:
                        self.api.update_chat(chat["id"], title=_TITLE_CLEAN.sub(" ", model_action_title)[:72])
                        needs_model_title = False
                    except BiroAPIError:
                        pass
                if action == "shell":
                    # Keep commands visible so BIRO never feels like a black box, while
                    # keeping stdout/stderr out of the live animation and returning it to
                    # the model for the next decision.
                    command = Syntax(
                        str(block.get("cmd", "")),
                        "bash",
                        theme="ansi_dark",
                        line_numbers=False,
                        word_wrap=True,
                        background_color="#303030",
                        padding=(0, 1),
                    )
                    shell_heading = Text("● ", style="bold #72D6B2")
                    shell_heading.append(f"EXECUTING SHELL · {action_title}", style="bold")
                    console.print(shell_heading)
                    console.print(command)
                elif action == "generate_image":
                    target = str(block.get("path") or "public/images/biro-generated-image.png")
                    console.print(Panel(Text(f"Generate image → {target}", overflow="fold"), title="[bold #72D6B2]IMAGE REQUEST[/bold #72D6B2]", subtitle=action_title, border_style="#586D64", box=box.ROUNDED, padding=(0, 1)))
                previous_file_contents: str | None = ""
                if action == "write_file":
                    try:
                        target_path = self.tools.resolve_path(str(block.get("path", "")))
                        if target_path.exists():
                            previous_file_contents = target_path.read_text(encoding="utf-8")
                    except (OSError, UnicodeError, ValueError):
                        previous_file_contents = None
                details_count_before = len(self.details)
                self._set_working_title(action_title_raw)
                result = self._execute_action(block, chat["id"])
                if action == "shell":
                    self.details.append({
                        "kind": "command",
                        "title": action_title_raw,
                        "command": str(block.get("cmd", "")),
                        "content": result,
                    })
                if result.startswith(("Error", "Image generation failed:", "Rejected", "Blocked", "Cancelled")):
                    console.print(Panel(Text(result, overflow="fold", no_wrap=False), title=f"[bold #E5B86F]ACTION FAILED · {action_title_raw}[/bold #E5B86F]", border_style="#E5B86F", box=box.ROUNDED, padding=(0, 1)))
                else:
                    console.print(f"[bold #72D6B2]Completed[/bold #72D6B2]  [bold]{action_title}[/bold]")
                    if action == "generate_image":
                        details = next((line for line in result.splitlines() if line.startswith("Written ")), "")
                        if details:
                            console.print(Text(details, style="dim"))
                if action == "generate_image" and result.startswith("Image generation failed:"):
                    console.print("[dim]No placeholder image was written. The error came from BIRO's image service; check the backend's image-provider configuration/logs and retry after that service is healthy.[/dim]")
                    return 1
                if action == "write_file" and result.startswith("Written "):
                    if previous_file_contents is not None:
                        diff_text = "".join(difflib.unified_diff(
                            previous_file_contents.splitlines(keepends=True),
                            str(block.get("body", "")).splitlines(keepends=True),
                            fromfile=f"a/{block.get('path', '')}",
                            tofile=f"b/{block.get('path', '')}",
                        ))
                    else:
                        diff_text = ""
                    if diff_text:
                        self.session_lines_added += sum(
                            1 for line in diff_text.splitlines()
                            if line.startswith("+") and not line.startswith("+++")
                        )
                        self.session_lines_deleted += sum(
                            1 for line in diff_text.splitlines()
                            if line.startswith("-") and not line.startswith("---")
                        )
                        self.details.append({
                            "kind": "diff",
                            "title": str(block.get("path", "Updated file")),
                            "content": diff_text,
                        })
                if len(self.details) > details_count_before:
                    if self._live is not None:
                        self._live.update(_AgentDashboard(self), refresh=False)
                follow_up = (
                    f"[Local tool result: {block.get('title') or block.get('action')}]\n"
                    f"Action: {block.get('action')}\nResult:\n{result}\n\n"
                    "Use this actual result to decide the next step. If more work is needed, emit exactly one next "
                    "complete action block (prefer the documented JSON `biro-action` format). If the task is complete, "
                    "explain what was done and what tests succeeded or failed."
                )
                current_prompt = follow_up
                step += 1
                self._set_working_title("Planning next action")
            if self.max_steps and step >= self.max_steps:
                console.print(f"[yellow]Reached the optional {self.max_steps}-step limit. Send another message to continue.[/yellow]")
            return 0
        except BiroAPIError as exc:
            console.print(f"[bold red]BIRO API error:[/bold red] {escape(str(exc))}")
            return 1
        finally:
            self.last_elapsed = time.monotonic() - started

    def _handoff_after_interrupt(self, prompt: str) -> int:
        try:
            from biro.background import start_task

            continuation = (
                "Continue this chat's interrupted request. Review the conversation history and current workspace, "
                "determine what remains unfinished, complete the requested work, and verify it.\n"
                f"Original user request:\n{prompt}"
            )
            task = start_task(continuation, self.tools.cwd, self.config.current_chat_id)
        except (OSError, RuntimeError, ValueError) as exc:
            console.print(f"\nUnable to continue in the background: {escape(str(exc))}")
            return 1
        console.print(
            "CHAT CONTINUES IN BACKGROUND\n"
            "Your response is still generating.\n"
            f"Model: {self.model_label}  ·  {self._token_usage_summary()}\n"
            f"Continue this chat with: biro chat {self.config.current_chat_id}\n"
            f"Job: {task['id']}  ·  Check status with: biro jobs"
        )
        self.detached = True
        return 0

    def _token_usage_summary(self) -> str:
        qualifier = "approximately " if self.session_token_count_approximate else ""
        return f"Tokens used: {qualifier}{self.session_token_count:,}"

    def _execute_action(self, block: dict[str, Any], chat_id: str) -> str:
        """Execute one action, including generating and saving an image artifact."""
        if str(block.get("action")) != "generate_image":
            return self.tools.execute(block)
        prompt = str(block.get("prompt", "")).strip()
        if not prompt:
            return "Image generation failed: the JSON action needs a non-empty prompt."
        requested_path = str(block.get("path") or "public/images/biro-generated-image.png").strip()
        try:
            generated = self.api.generate_image(chat_id, prompt)
            artifact = generated.get("artifact") if isinstance(generated, dict) else None
            if not isinstance(artifact, dict) or not artifact.get("id"):
                return "Image generation failed: BIRO's image endpoint did not return an artifact ID."
            data, mime_type = self.api.download_artifact(chat_id, str(artifact["id"]))
            extension_by_mime = {"image/png": ".png", "image/jpeg": ".jpg", "image/webp": ".webp", "image/gif": ".gif"}
            extension = extension_by_mime.get(mime_type)
            if not extension:
                return f"Image generation failed: the image endpoint returned unsupported content type {mime_type!r}."
            target = Path(requested_path).expanduser()
            if target.suffix.lower() != extension:
                target = target.with_suffix(extension)
            result = self.tools.write_bytes(str(target), data, str(block.get("title") or "Save generated image"))
            if result.startswith("Written "):
                return f"Image generated by BIRO's image API.\n{result}\nContent type: {mime_type}. Use the saved path in the relevant webpage/component."
            return result
        except BiroAPIError as exc:
            status = f"HTTP {exc.status_code}: " if exc.status_code else ""
            return f"Image generation failed: {status}{exc}"
        except (OSError, ValueError) as exc:
            return f"Image generation failed: {exc}"


def _safe_stream_preview(response: str) -> str:
    """Return user-visible partial text without leaking BIRO action payloads.

    The live preview is intentionally conservative around action fences: once an
    executable marker begins, hide it and everything after it until the completed
    response is parsed. That preserves the tool-call security boundary during streaming.
    """
    preview = response
    lowered = preview.lower()

    # Hide complete and partial fenced action markers, including when the provider
    # splits the marker across adjacent streaming deltas.
    for marker in ("```biro-action", "```tool"):
        position = lowered.find(marker)
        if position >= 0:
            preview = preview[:position]
            lowered = preview.lower()

    # If a stream has only emitted the beginning of a fence/language label, hold that
    # trailing fragment back until the label is known. This stops ```biro-... flashing.
    fence = preview.rfind("```")
    if fence >= 0:
        after = preview[fence + 3:]
        if "\n" not in after:
            partial = after.strip().lower()
            if "biro-action".startswith(partial) or "tool".startswith(partial):
                preview = preview[:fence]

    # Some compatible models emit a bare JSON action without fences. Hide the object
    # as soon as its action type can be identified, rather than streaming commands.
    bare_action = re.search(
        r"\{(?=[\s\S]{0,4000}?[\"'](?:action|biro_action|tool|name|type)[\"']\s*:\s*"
        r"[\"'](?:generate[_-]image|image[_-]generation|shell|read[_-]file|write[_-]file|"
        r"delete[_-]path|run[_-]command|execute[_-]command))",
        preview, re.IGNORECASE,
    )
    if bare_action:
        preview = preview[:bare_action.start()]
    return preview.strip()


def title_from_response(response: str, *, fallback: str = "") -> str:
    """Use concise model-authored response text for a new chat's visible title."""
    for raw_line in response.splitlines():
        line = raw_line.strip()
        if not line:
            continue
        line = re.sub(r"^#{1,6}\s*", "", line)
        line = re.sub(r"^[-*+]\s+", "", line)
        line = re.sub(r"`{1,3}", "", line)
        line = re.sub(r"\[([^\]]+)\]\([^)]*\)", r"\1", line)
        for sentence in re.split(r"(?<=[.!?])\s+", line):
            sentence = _TITLE_CLEAN.sub(" ", sentence).strip(" \t\"'`*#")
            if len(sentence.split()) >= 3 and sentence.lower() not in {"of course.", "sure thing."}:
                return sentence[:72].rstrip()
    return title_from_prompt(fallback) if fallback.strip() else "New conversation"


def title_from_prompt(prompt: str) -> str:
    """Use a compact prompt title only when the model gives no useful title text."""
    cleaned = _TITLE_CLEAN.sub(" ", prompt.strip())
    return cleaned[:72] or "New conversation"
