from __future__ import annotations

from rich.console import Console
from rich.text import Text


class ToolAwarePrinter:
    """Stream normal assistant prose while hiding executable tool fences."""
    START = "```tool"

    def __init__(self, console: Console):
        self.console = console
        self.buffer = ""
        self.in_tool = False
        self.printed_any = False

    def _emit(self, text: str) -> None:
        if text:
            self.console.print(Text(text), end="", markup=False, highlight=False, soft_wrap=True)
            self.printed_any = True

    def feed(self, fragment: str) -> None:
        self.buffer += fragment
        while True:
            if self.in_tool:
                end = self.buffer.find("```")
                if end >= 0:
                    self.buffer = self.buffer[end + 3:]
                    self.in_tool = False
                    continue
                # Keep enough characters in case the closing fence spans events.
                self.buffer = self.buffer[-2:]
                return
            start = self.buffer.find(self.START)
            if start >= 0:
                self._emit(self.buffer[:start])
                self.buffer = self.buffer[start + len(self.START):]
                self.in_tool = True
                continue
            safe = len(self.buffer) - (len(self.START) - 1)
            if safe > 0:
                self._emit(self.buffer[:safe])
                self.buffer = self.buffer[safe:]
            return

    def finish(self) -> None:
        if not self.in_tool:
            self._emit(self.buffer)
        self.buffer = ""
        if self.printed_any:
            self.console.print()
