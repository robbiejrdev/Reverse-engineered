from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from typing import Any

from rich.console import Console
from rich.markup import escape
from rich.syntax import Syntax

from biro.agent.search import TavilySearch

console = Console(highlight=False, soft_wrap=True)

TOOL_RE = re.compile(
    r"```(?:tool|biro-action)[ \t]*\n(.*?)\n[ \t]*```[ \t]*",
    re.DOTALL | re.IGNORECASE,
)
JSON_ACTION_RE = re.compile(
    r"```(?:biro-action|json|jsonc)[ \t]*\n(.*?)\n[ \t]*```[ \t]*",
    re.DOTALL | re.IGNORECASE,
)
ACTION_OPEN_RE = re.compile(
    r"```(?:tool|biro-action)(?:[ \t]*\n)|"
    r"```(?:json|jsonc)[ \t]*\n(?:(?!```).)*?[\"'](?:action|biro_action|tool|name|type)[\"']\s*:\s*[\"']"
    r"(?:generate[_-]image|image[_-]generation|shell|read[_-]file|write[_-]file|delete[_-]path|run[_-]command|execute[_-]command|web[_-]search|tavily[_-]search|search[_-]web|search)",
    re.IGNORECASE | re.DOTALL,
)

SUPPORTED_ACTIONS = {"shell", "read_file", "write_file", "delete_path", "generate_image", "web_search"}


def _is_concrete_action_path(path: str) -> bool:
    return bool(path.strip()) and not any(char in path for char in "{}")

_ACTION_ALIASES = {
    "image": "generate_image",
    "image_generation": "generate_image",
    "generate-image": "generate_image",
    "run_command": "shell",
    "execute_command": "shell",
    "command": "shell",
    "read": "read_file",
    "write": "write_file",
    "delete": "delete_path",
    "search": "web_search",
    "search_web": "web_search",
    "tavily_search": "web_search",
}


def parse_tool_block(source: str) -> dict[str, Any] | None:
    """Parse BIRO's legacy human-readable action block."""
    lines = source.splitlines()
    while lines and not lines[0].strip():
        lines.pop(0)
    if not lines or not lines[0].strip().lower().startswith("title:"):
        return None
    result: dict[str, Any] = {
        "title": lines[0].split(":", 1)[1].strip(),
        "action": "",
        "path": "",
        "cmd": "",
        "body": "",
        "prompt": "",
        "query": "",
        "max_results": 5,
        "fresh": False,
    }
    separator = None
    for idx, line in enumerate(lines[1:], start=1):
        if line.strip() == "---":
            separator = idx
            result["body"] = "\n".join(lines[idx + 1:])
            break
        if ":" in line:
            key, value = line.split(":", 1)
            key = key.strip().lower()
            if key in {"action", "path", "cmd", "prompt", "query"}:
                result[key] = value.strip()
    if result["action"] == "shell" and result["body"].strip():
        result["cmd"] = "\n".join(part for part in (result["cmd"], result["body"]) if part).strip()
    if result["action"] != "shell" and separator is not None:
        result["body"] = "\n".join(lines[separator + 1:])
    if result["action"] not in SUPPORTED_ACTIONS:
        return None
    if result["action"] == "generate_image" and not str(result.get("prompt", "")).strip():
        return None
    if result["action"] == "web_search" and not str(result.get("query", "")).strip():
        return None
    if result["action"] in {"read_file", "write_file", "delete_path"} and not _is_concrete_action_path(
        str(result.get("path", ""))
    ):
        return None
    return result


def parse_json_action(source: str) -> dict[str, Any] | None:
    """Parse a JSON action, including common tool-call envelope shapes.

    The model may emit a direct action object or a tool call with the payload
    nested under ``arguments``, ``parameters``, or ``input``. String values are
    never clipped.
    """
    try:
        payload = json.loads(source.strip())
    except (json.JSONDecodeError, TypeError):
        return None
    if not isinstance(payload, dict):
        return None
    nested = next(
        (payload.get(key) for key in ("arguments", "parameters", "input") if isinstance(payload.get(key), dict)),
        {},
    )
    values = {**payload, **nested}
    action_candidates = (
        payload.get("action"),
        payload.get("biro_action"),
        payload.get("tool"),
        payload.get("name"),
        payload.get("type"),
        nested.get("action"),
        nested.get("biro_action"),
        nested.get("tool"),
        nested.get("name"),
    )
    action = ""
    for candidate in action_candidates:
        candidate_name = str(candidate or "").strip().lower().replace("-", "_")
        candidate_name = _ACTION_ALIASES.get(candidate_name, candidate_name)
        if candidate_name in SUPPORTED_ACTIONS:
            action = candidate_name
            break
    if action not in SUPPORTED_ACTIONS:
        return None
    title = str(values.get("title") or values.get("description") or _default_title(action)).strip()
    field_aliases = {
        "path": ("path", "file_path", "output_path", "destination"),
        "cmd": ("cmd", "command", "shell_command"),
        "body": ("body", "content", "file_content", "text"),
        "prompt": ("prompt", "image_prompt", "description"),
        "query": ("query", "search_query"),
    }
    parsed: dict[str, Any] = {"title": title, "action": action}
    for field, aliases in field_aliases.items():
        value = next((values.get(alias) for alias in aliases if alias in values), "")
        if value is not None and not isinstance(value, str):
            return None
        parsed[field] = value or ""
    if action == "shell" and not parsed["cmd"].strip():
        return None
    if action in {"read_file", "write_file", "delete_path"} and not parsed["path"].strip():
        return None
    if action in {"read_file", "write_file", "delete_path"} and not _is_concrete_action_path(parsed["path"]):
        return None
    if action == "generate_image" and not parsed["prompt"].strip():
        return None
    if action == "write_file" and not any(key in values for key in field_aliases["body"]):
        return None
    if action == "web_search":
        max_results = values.get("max_results", 5)
        fresh = values.get("fresh", False)
        if not parsed["query"].strip():
            return None
        if isinstance(max_results, bool) or not isinstance(max_results, int) or not 1 <= max_results <= 10:
            return None
        if not isinstance(fresh, bool):
            return None
        parsed["max_results"] = max_results
        parsed["fresh"] = fresh
    return parsed


def _default_title(action: str) -> str:
    return {
        "shell": "Run project command",
        "read_file": "Read project file",
        "write_file": "Write project file",
        "delete_path": "Delete project path",
        "generate_image": "Generate project image",
        "web_search": "Search the web",
    }.get(action, "BIRO action")


def split_tool_blocks(response: str) -> tuple[str, list[dict[str, Any]]]:
    """Extract executable actions, accepting fenced blocks and standalone JSON calls.

    Ordinary JSON examples stay visible because a candidate is accepted only
    when it decodes to a supported BIRO action with all required fields.
    """
    def parse_action_fence(source: str) -> dict[str, Any] | None:
        return parse_json_action(source) or parse_tool_block(source)

    matches: list[tuple[int, int, Any, Any, int]] = []
    for regex, parser, priority in (
        (TOOL_RE, parse_action_fence, 0),
        (JSON_ACTION_RE, parse_json_action, 1),
    ):
        for match in regex.finditer(response):
            matches.append((match.start(), match.end(), match, parser, priority))

    # Recover complete legacy actions when a model omits the closing fence.
    for match in re.finditer(
        r"```(?:tool|biro-action)[ \t]*\n(.*)\Z",
        response,
        re.DOTALL | re.IGNORECASE,
    ):
        if response.find("```", match.start() + 3) == -1:
            matches.append((match.start(), match.end(), match, parse_action_fence, 0))

    # Also recognize a bare JSON tool object (some provider adapters omit fences).
    decoder = json.JSONDecoder()
    for marker in re.finditer(
        r"\{(?=.*?[\"'](?:action|biro_action|tool|name|type)[\"']\s*:)",
        response,
        re.DOTALL | re.IGNORECASE,
    ):
        pos = marker.start()
        try:
            _payload, end_pos = decoder.raw_decode(response, pos)
        except json.JSONDecodeError:
            continue
        if end_pos <= pos:
            continue
        raw = response[pos:end_pos]
        parsed = parse_json_action(raw)
        if parsed:
            matches.append((pos, end_pos, raw, lambda value, parsed=parsed: parsed, 2))

    matches.sort(key=lambda item: (item[0], item[4], -(item[1] - item[0])))

    blocks: list[dict[str, Any]] = []
    visible_parts: list[str] = []
    cursor = 0
    for start, end, match, parser, _priority in matches:
        if start < cursor:
            continue
        source = match.group(1) if hasattr(match, "group") else match
        parsed = parser(source)
        if parsed:
            visible_parts.append(response[cursor:start])
            blocks.append(parsed)
            cursor = end
    visible_parts.append(response[cursor:])
    return "".join(visible_parts).strip(), blocks


def has_malformed_action(response: str) -> bool:
    """True when a supported action was started but no complete action was parsed."""
    if ACTION_OPEN_RE.search(response):
        return True
    # Handle unfenced/incomplete JSON actions without treating normal JSON as a tool.
    return bool(
        re.search(
            r"\{[^{}]{0,4000}[\"'](?:action|biro_action|tool|name|type)[\"']\s*:\s*[\"']"
            r"(?:generate[_-]image|image[_-]generation|shell|read[_-]file|write[_-]file|delete[_-]path|run[_-]command|execute[_-]command|web[_-]search|tavily[_-]search|search[_-]web|search)",
            response,
            re.IGNORECASE | re.DOTALL,
        )
    )


class WorkspaceTools:
    def __init__(self, cwd: Path, *, auto_approve: bool = True, confirm_all: bool = False):
        # auto_approve / confirm_all kept only for API compatibility; no gating is performed.
        self.cwd = cwd.resolve()
        self.auto_approve = auto_approve
        self.confirm_all = confirm_all
        self.web_search = TavilySearch()

    def change_cwd(self, path: str) -> Path:
        target = Path(path).expanduser().resolve()
        if not target.is_dir():
            raise ValueError(f"Directory does not exist: {target}")
        self.cwd = target
        os.chdir(target)
        return target

    def resolve_path(self, value: str) -> Path:
        if not value.strip():
            raise ValueError("A non-empty path is required.")
        candidate = Path(value).expanduser()
        if not candidate.is_absolute():
            candidate = self.cwd / candidate
        # No workspace confinement: resolve freely, allow any path.
        return candidate.resolve()

    def execute(self, block: dict[str, Any]) -> str:
        action = str(block.get("action", ""))
        title = str(block.get("title") or "BIRO action")
        if action == "read_file":
            return self.read_file(str(block.get("path", "")), title)
        if action == "write_file":
            return self.write_file(
                str(block.get("path", "")),
                str(block.get("body", "")),
                title,
            )
        if action == "delete_path":
            return self.delete_path(str(block.get("path", "")), title)
        if action == "shell":
            return self.run_shell(str(block.get("cmd", "")), title)
        if action == "web_search":
            query = str(block.get("query", "")).strip()
            result = self.web_search.search(
                query,
                max_results=block.get("max_results", 5),
                fresh=block.get("fresh", False),
            )
            if "error" in result:
                return f"Error: {result['error']}"
            return self.web_search.format_context(query, result)
        return f"Rejected unsupported action: {action!r}"

    def write_bytes(self, path: str, content: bytes, title: str = "Save generated asset") -> str:
        """Atomically save a binary artifact."""
        try:
            full = self.resolve_path(path)
            if full.exists() and not full.is_file():
                return f"Error: refusing to overwrite a non-file path: {path}"
            full.parent.mkdir(parents=True, exist_ok=True)
            fd, temp_name = tempfile.mkstemp(
                prefix=f".{full.name}.", suffix=".biro-tmp", dir=str(full.parent)
            )
            try:
                with os.fdopen(fd, "wb") as handle:
                    handle.write(content)
                    handle.flush()
                    os.fsync(handle.fileno())
                Path(temp_name).replace(full)
            finally:
                Path(temp_name).unlink(missing_ok=True)
            return f"Written {len(content):,} bytes to {path}."
        except (OSError, ValueError) as exc:
            return f"Error saving binary file {path}: {exc}"

    def read_file(self, path: str, title: str) -> str:
        try:
            full = self.resolve_path(path)
            if not full.is_file():
                return f"Error: not a regular file: {path}"
            with full.open("rb") as handle:
                raw = handle.read()
            return raw.decode("utf-8", errors="replace")
        except (OSError, ValueError) as exc:
            return f"Error reading {path}: {exc}"

    def write_file(self, path: str, content: str, title: str) -> str:
        try:
            full = self.resolve_path(path)
            if full.exists() and not full.is_file():
                return f"Error: refusing to overwrite a non-file path: {path}"
            full.parent.mkdir(parents=True, exist_ok=True)
            temp = full.with_name(full.name + ".biro-tmp")
            try:
                temp.write_text(content, encoding="utf-8")
                temp.replace(full)
            finally:
                if temp.exists():
                    temp.unlink(missing_ok=True)
            size = len(content.encode("utf-8"))
            return f"Written {size:,} bytes to {path}."
        except (OSError, ValueError) as exc:
            return f"Error writing {path}: {exc}"

    def delete_path(self, path: str, title: str) -> str:
        try:
            if not path.strip():
                raise ValueError("A non-empty path is required.")
            candidate = Path(path).expanduser()
            if not candidate.is_absolute():
                candidate = self.cwd / candidate
            if candidate.name in {"", ".", ".."}:
                full = candidate.resolve()
            else:
                full = candidate.parent.resolve() / candidate.name
            if not full.exists() and not full.is_symlink():
                return f"Path does not exist: {path}"
            if full == Path(full.anchor):
                return f"Error: refusing to delete a filesystem root: {path}"
            if full.is_symlink() or full.is_file():
                full.unlink()
                return f"Deleted file/link {path}."
            if full.is_dir():
                shutil.rmtree(full)
                return f"Deleted directory {path}."
            return f"Unsupported path type: {path}"
        except (OSError, ValueError) as exc:
            return f"Error deleting {path}: {exc}"

    def run_shell(self, cmd: str, title: str) -> str:
        if not cmd.strip():
            return "Error: shell action has no command."
        start = time.monotonic()
        try:
            with tempfile.TemporaryFile(mode="w+b") as output_file:
                env = os.environ.copy()
                venv_bin = str(Path(sys.executable).resolve().parent)
                env["PATH"] = venv_bin + os.pathsep + env.get("PATH", "")
                proc = subprocess.Popen(
                    cmd,
                    shell=True,
                    cwd=self.cwd,
                    env=env,
                    stdout=output_file,
                    stderr=subprocess.STDOUT,
                    start_new_session=(os.name != "nt"),
                )
                return_code = proc.wait()
                output_file.seek(0)
                raw = output_file.read()
                output = raw.decode("utf-8", errors="replace")
                elapsed = time.monotonic() - start
                output += f"\n[exit code: {return_code}; runtime: {elapsed:.1f}s]"
            return output or "(no output)"
        except OSError as exc:
            return f"Error running command: {exc}"
