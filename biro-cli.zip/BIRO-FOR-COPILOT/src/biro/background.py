from __future__ import annotations

import json
import shutil
import subprocess
import sys
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from biro.config import UserConfig, config_dir


def _task_dir() -> Path:
    return config_dir() / "background"


def _task_path(task_id: str) -> Path:
    return _task_dir() / f"{task_id}.json"


def _timestamp() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds")


def _save_task(task: dict[str, Any]) -> None:
    directory = _task_dir()
    directory.mkdir(parents=True, exist_ok=True)
    target = _task_path(str(task["id"]))
    temporary = target.with_suffix(".tmp")
    temporary.write_text(json.dumps(task, ensure_ascii=False, indent=2), encoding="utf-8")
    temporary.replace(target)


def _read_task(task_id: str) -> dict[str, Any] | None:
    try:
        value = json.loads(_task_path(task_id).read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    return value if isinstance(value, dict) else None


def _update_task(task_id: str, **fields: Any) -> None:
    task = _read_task(task_id)
    if task is None:
        return
    task.update(fields)
    task["updated_at"] = _timestamp()
    _save_task(task)


def list_tasks() -> list[dict[str, Any]]:
    directory = _task_dir()
    if not directory.exists():
        return []
    tasks = []
    for path in directory.glob("*.json"):
        try:
            value = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        if isinstance(value, dict):
            tasks.append(value)
    return sorted(tasks, key=lambda task: str(task.get("created_at", "")), reverse=True)


def clear_tasks() -> int:
    """Stop BIRO PM2 workers and remove job records and their local logs."""
    directory = _task_dir()
    tasks = list_tasks()
    running = [
        task for task in tasks
        if str(task.get("status", "")).lower() in {"queued", "starting", "running"}
    ]
    pm2 = shutil.which("pm2")
    if running and pm2 is None:
        raise RuntimeError("Cannot clear active BIRO jobs because PM2 is not installed or not on PATH.")
    if pm2:
        try:
            result = subprocess.run(
                [pm2, "jlist"], check=True, capture_output=True, text=True,
            )
            processes = json.loads(result.stdout or "[]")
        except (OSError, subprocess.CalledProcessError, json.JSONDecodeError) as exc:
            detail = getattr(exc, "stderr", None) or str(exc)
            raise RuntimeError(f"Could not inspect PM2 jobs before clearing: {detail.strip()}") from exc
        if not isinstance(processes, list):
            raise RuntimeError("Could not inspect PM2 jobs before clearing: unexpected process list format.")
        names = sorted({
            str(process.get("name", ""))
            for process in processes
            if isinstance(process, dict) and str(process.get("name", "")).startswith("biro-job-")
        })
        try:
            for name in names:
                subprocess.run([pm2, "delete", name], check=True, capture_output=True, text=True)
            if names:
                subprocess.run([pm2, "save", "--force"], check=True, capture_output=True, text=True)
        except (OSError, subprocess.CalledProcessError) as exc:
            detail = getattr(exc, "stderr", None) or str(exc)
            raise RuntimeError(f"Could not remove BIRO jobs from PM2: {detail.strip()}") from exc

    removed = 0
    for path in (*directory.glob("*.json"), *directory.glob("*.log"), *directory.glob("*.tmp")):
        try:
            path.unlink()
            removed += 1
        except FileNotFoundError:
            continue
        except OSError as exc:
            raise RuntimeError(f"Could not remove background job file {path}: {exc}") from exc
    return removed


def start_task(prompt: str, cwd: Path, chat_id: str, *, max_steps: int = 0) -> dict[str, Any]:
    pm2 = shutil.which("pm2")
    if pm2 is None:
        raise RuntimeError(
            "PM2 is required for persistent background jobs. Install Node.js and PM2 "
            "(npm install --global pm2), then retry."
        )
    task_id = uuid.uuid4().hex[:10]
    pm2_name = f"biro-job-{task_id}"
    task = {
        "id": task_id,
        "status": "queued",
        "prompt": prompt,
        "cwd": str(cwd.resolve()),
        "chat_id": chat_id,
        "think": True,
        "model": "biro-max",
        "max_steps": max_steps,
        "pm2_name": pm2_name,
        "created_at": _timestamp(),
        "updated_at": _timestamp(),
    }
    _save_task(task)
    log_path = _task_dir() / f"{task_id}.log"
    try:
        subprocess.run(
            [
                pm2, "start", sys.executable,
                "--name", pm2_name,
                "--interpreter", "none",
                "--cwd", str(cwd.resolve()),
                "--no-autorestart",
                "--log", str(log_path),
                "--",
                "-m", "biro.background", "--worker", task_id,
            ],
            check=True,
            capture_output=True,
            text=True,
        )
    except (OSError, subprocess.CalledProcessError) as exc:
        message = getattr(exc, "stderr", None) or str(exc)
        try:
            subprocess.run(
                [pm2, "delete", pm2_name],
                check=False,
                capture_output=True,
                text=True,
            )
        except OSError:
            pass
        _update_task(task_id, status="failed", error=message.strip(), returncode=1, finished_at=_timestamp())
        raise RuntimeError(f"Could not start the background job with PM2: {message.strip()}") from exc
    _update_task(task_id, log=str(log_path))
    return _read_task(task_id) or task


def run_task(task_id: str) -> int:
    task = _read_task(task_id)
    if task is None:
        return 1
    started = time.monotonic()
    started_at = _timestamp()
    _update_task(task_id, status="running", started_at=started_at)
    task = _read_task(task_id) or task
    returncode = 1
    finished_at: str
    error = ""
    config: UserConfig | None = None
    try:
        from biro.agent.runner import Agent
        from biro.api.client import BiroAPI

        config = UserConfig.load()
        config.current_chat_id = str(task.get("chat_id", ""))
        config.model = "biro-max"
        api = BiroAPI(config)
        try:
            agent = Agent(
                api, config, Path(str(task["cwd"])),
                think=True,
                max_steps=int(task.get("max_steps", 0)),
                deep_research=True,
            )
            returncode = agent.send(str(task.get("prompt", "")))
        finally:
            api.close()
    except Exception as exc:
        error = f"{type(exc).__name__}: {exc}"
        returncode = 1

    finished_at = _timestamp()
    elapsed = round(time.monotonic() - started, 3)
    fields = {
        "status": "complete" if returncode == 0 else "failed",
        "chat_id": config.current_chat_id if config is not None else str(task.get("chat_id", "")),
        "returncode": returncode,
        "started_at": started_at,
        "finished_at": finished_at,
        "duration_seconds": elapsed,
    }
    if error:
        fields["error"] = error
    _update_task(task_id, **fields)
    pm2 = shutil.which("pm2")
    if pm2 and task.get("pm2_name"):
        try:
            subprocess.Popen(
                [sys.executable, "-m", "biro.background", "--cleanup", task_id],
                cwd=str(Path(__file__).resolve().parent),
                stdin=subprocess.DEVNULL,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                close_fds=True,
                start_new_session=(sys.platform != "win32"),
            )
        except OSError as exc:
            _update_task(task_id, pm2_cleanup_error=str(exc))
    return returncode


def cleanup_task(task_id: str) -> int:
    task = _read_task(task_id)
    if task is None:
        return 1
    pm2 = shutil.which("pm2")
    if pm2 is None:
        _update_task(task_id, pm2_cleanup_error="PM2 executable was not found during cleanup.")
        return 1
    time.sleep(1)
    name = str(task.get("pm2_name") or f"biro-job-{task_id}")
    try:
        subprocess.run([pm2, "delete", name], check=True, capture_output=True, text=True)
        subprocess.run([pm2, "save", "--force"], check=True, capture_output=True, text=True)
    except (OSError, subprocess.CalledProcessError) as exc:
        detail = getattr(exc, "stderr", None) or str(exc)
        _update_task(task_id, pm2_cleanup_error=detail.strip())
        return 1
    _update_task(task_id, pm2_cleanup_error="")
    return 0


def main() -> int:
    if len(sys.argv) == 3 and sys.argv[1] == "--worker":
        return run_task(sys.argv[2])
    if len(sys.argv) == 3 and sys.argv[1] == "--cleanup":
        return cleanup_task(sys.argv[2])
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
