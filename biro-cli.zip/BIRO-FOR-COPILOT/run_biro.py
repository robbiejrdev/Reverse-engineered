#!/usr/bin/env python3
"""Compatibility entry point for running BIRO CLI from the source checkout."""
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent / "src"))

from biro.cli import main  # noqa: E402

if __name__ == "__main__":
    raise SystemExit(main())
