# BIRO CLI v1.2.1 — transcript and streaming UI fix

This is a focused UI bug fix for the existing v1.2.1 source. The visual styles, colors,
layout components, commands, API behavior, and package version are unchanged.

## Changes

- The live workspace/status dashboard is transient. It redraws in place during a turn and
  is removed when the turn ends, so the composer and status strip no longer accumulate in
  terminal scrollback after each response.
- Text response deltas are rendered incrementally in the live area above the dashboard.
  When generation finishes, BIRO leaves one durable Markdown response in the transcript.
- Executable `biro-action` / `tool` fenced blocks and recognizable bare JSON action payloads
  are withheld from the live preview so shell commands and tool payloads are not exposed
  during generation.
- Added regression coverage for transient dashboard behavior, incremental preview updates,
  and action-payload suppression.

## Validation

- `PYTHONPATH=src pytest -q`: 49 tests passed.
- Python compilation check passed.

The source package is not a prebuilt executable; reinstall from source using the included
`install.sh` or `make install-user` workflow if that is how this installation was installed.
