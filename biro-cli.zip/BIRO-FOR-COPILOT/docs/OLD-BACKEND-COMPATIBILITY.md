# Compatibility with the original BIRO backend

This CLI release targets the existing BIRO backend contract. It deliberately does not include server-side source changes, database migrations, endpoint renames, or provider changes.

Routes used by the CLI and present in the supplied original backend source:

- `POST /api/v1/auth/signup`
- `POST /api/v1/auth/login`
- `GET /api/v1/me`
- `GET /api/v1/ai/models?provider=biro-max|biro-mini`
- `GET|POST /api/v1/chats`, plus `GET|PATCH|DELETE /api/v1/chats/{chat_id}`
- `GET /api/v1/chats/{chat_id}/messages`
- `POST /api/v1/chats/{chat_id}/messages/stream` (NDJSON `thinking`, `delta`, `done`, and `error` events)
- `POST /api/v1/chats/{chat_id}/images`
- `GET /api/v1/chats/{chat_id}/artifacts/{artifact_id}/download`

The CLI never renders the `thinking` event's `text` field or the stored `MessageResponse.thinking` value. It only shows a short local task/step label in the dashboard. Generated images are requested via the existing image endpoint and downloaded from the artifact endpoint, then saved relative to the user's current workspace.

The original backend applies its own request schema and model-context/history limits. Client-side changes cannot remove server-side inference-context limits without changing that backend; this release intentionally leaves the shared backend unchanged so the web and mobile apps continue to use it as before.
