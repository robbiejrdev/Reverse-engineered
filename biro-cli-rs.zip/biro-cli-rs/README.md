# BIRO CLI (Rust)

An interactive, account-backed terminal coding agent. This Rust implementation talks to the BIRO API and includes streaming responses, local workspace actions, saved chats, file/image attachments, web search, GitHub and Hugging Face CLI integration, and background jobs.

## Requirements

- Rust and Cargo (the package targets Rust 1.75 or newer).
- Network access to the configured BIRO API.
- Optional: GitHub CLI (`gh`), Hugging Face CLI (`hf`), and PM2 for managed background jobs.

## Build

```sh
cargo build --release
./target/release/biro --version
./target/release/biro --help
```

## Run

```sh
# Start an interactive session
biro

# Send one prompt and exit
biro --prompt "Explain this project"

# Choose a model or API endpoint
biro --model mini --api-url https://api.robbiejr.site

# Start a background task
biro --background --prompt "Run the project tests and report failures"

# Inspect background tasks
biro jobs

# Resume a saved conversation
biro chat CHAT_ID
```

The executable is named `biro`. Configuration is stored under `${XDG_CONFIG_HOME:-~/.config}/biro/config.json`, with environment overrides `BIRO_CONFIG_DIR`, `BIRO_API_URL`, and `BIRO_MODEL`. The default API base URL is `https://api.robbiejr.site`.

## Interactive commands

Use `/help` inside a session to see available slash commands, including `/chats`, `/open`, `/new`, `/history`, `/retry`, `/cwd`, `/file`, `/image`, `/model`, `/think`, `/jobs`, `/connect`, `/integrations`, and `/exit`.

## Security notes

The config stores the session access token locally. On Unix, the application attempts to restrict config directory permissions to `0700` and the config file to `0600`. Do not commit local configuration files or tokens to version control.
