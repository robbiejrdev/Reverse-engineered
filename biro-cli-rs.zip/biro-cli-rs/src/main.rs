mod agent;
mod api;
mod background;
mod cli;
mod config;
mod ui;

use std::sync::{
    atomic::{AtomicBool, Ordering},
    Arc,
};

fn main() {
    // Background worker dispatch (spawned by `biro --background`).
    let argv: Vec<String> = std::env::args().collect();
    if let Some(code) = background::run_worker_command(&argv[1..]) {
        std::process::exit(code);
    }

    let flag = Arc::new(AtomicBool::new(false));
    let flag_handler = flag.clone();
    let _ = ctrlc::set_handler(move || {
        flag_handler.store(true, Ordering::SeqCst);
    });

    let args = cli::Args::parse_args();
    let code = match cli::run_app(args, flag) {
        Ok(c) => c,
        Err(e) => {
            eprintln!("\x1b[1;31mStartup error:\x1b[0m {}", e);
            1
        }
    };
    std::process::exit(code);
}
