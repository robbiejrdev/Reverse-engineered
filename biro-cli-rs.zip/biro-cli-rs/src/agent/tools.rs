use std::fs;
use std::io::Write;
use std::path::PathBuf;
use std::process::Command;
use std::sync::OnceLock;
use std::time::Instant;

use regex::Regex;
use serde_json::{json, Value};

use crate::agent::search::TavilySearch;

pub const SUPPORTED_ACTIONS: &[&str] = &[
    "shell",
    "read_file",
    "write_file",
    "delete_path",
    "generate_image",
    "web_search",
];

fn tool_re() -> &'static Regex {
    static R: OnceLock<Regex> = OnceLock::new();
    R.get_or_init(|| {
        Regex::new(r"(?is)```(?:tool|biro-action)[ \t]*\n(.*?)\n[ \t]*```[ \t]*").unwrap()
    })
}

fn json_action_re() -> &'static Regex {
    static R: OnceLock<Regex> = OnceLock::new();
    R.get_or_init(|| {
        Regex::new(r"(?is)```(?:biro-action|json|jsonc)[ \t]*\n(.*?)\n[ \t]*```[ \t]*").unwrap()
    })
}

fn action_open_re() -> &'static Regex {
    static R: OnceLock<Regex> = OnceLock::new();
    R.get_or_init(|| {
        Regex::new(
            r#"(?is)```(?:tool|biro-action)(?:[ \t]*\n)|```(?:json|jsonc)[ \t]*\n(?:(?!```).)*?["'](?:action|biro_action|tool|name|type)["']\s*:\s*["'](?:generate[_-]image|image[_-]generation|shell|read[_-]file|write[_-]file|delete[_-]path|run[_-]command|execute[_-]command|web[_-]search|tavily[_-]search|search[_-]web|search)"#,
        )
        .unwrap()
    })
}

fn alias(name: &str) -> Option<&'static str> {
    match name {
        "image" | "image_generation" | "generate-image" | "generate_image" => Some("generate_image"),
        "run_command" | "execute_command" | "command" | "shell" => Some("shell"),
        "read" | "read_file" => Some("read_file"),
        "write" | "write_file" => Some("write_file"),
        "delete" | "delete_path" => Some("delete_path"),
        "search" | "search_web" | "tavily_search" | "web_search" => Some("web_search"),
        _ => None,
    }
}

fn default_title(action: &str) -> &'static str {
    match action {
        "shell" => "Run project command",
        "read_file" => "Read project file",
        "write_file" => "Write project file",
        "delete_path" => "Delete project path",
        "generate_image" => "Generate project image",
        "web_search" => "Search the web",
        _ => "BIRO action",
    }
}

fn is_concrete_action_path(path: &str) -> bool {
    !path.trim().is_empty() && !path.contains('{') && !path.contains('}')
}

pub fn parse_tool_block(source: &str) -> Option<Value> {
    let mut lines: Vec<&str> = source.lines().collect();
    while !lines.is_empty() && lines[0].trim().is_empty() {
        lines.remove(0);
    }
    if lines.is_empty() {
        return None;
    }
    let first = lines[0].trim();
    if !first.to_lowercase().starts_with("title:") {
        return None;
    }
    let mut result = json!({
        "title": first.splitn(2, ':').nth(1).unwrap_or("").trim(),
        "action": "", "path": "", "cmd": "", "body": "", "prompt": "",
        "query": "", "max_results": 5, "fresh": false,
    });
    let mut separator: Option<usize> = None;
    for (idx, line) in lines.iter().enumerate().skip(1) {
        if line.trim() == "---" {
            separator = Some(idx);
            result["body"] = json!(lines[idx + 1..].join("\n"));
            break;
        }
        if let Some((k, v)) = line.split_once(':') {
            let key = k.trim().to_lowercase();
            if matches!(key.as_str(), "action" | "path" | "cmd" | "prompt" | "query") {
                result[key.as_str()] = json!(v.trim());
            }
        }
    }
    let action = result.get("action").and_then(|v| v.as_str()).unwrap_or("").to_string();
    if action == "shell" {
        let body = result.get("body").and_then(|v| v.as_str()).unwrap_or("");
        if !body.trim().is_empty() {
            let existing = result.get("cmd").and_then(|v| v.as_str()).unwrap_or("");
            let combined = if existing.is_empty() {
                body.to_string()
            } else {
                format!("{}\n{}", existing, body)
            };
            result["cmd"] = json!(combined.trim());
        }
    } else if action != "shell" && separator.is_some() {
        // body already set
    }
    if !SUPPORTED_ACTIONS.contains(&action.as_str()) {
        return None;
    }
    if action == "generate_image"
        && result.get("prompt").and_then(|v| v.as_str()).unwrap_or("").trim().is_empty()
    {
        return None;
    }
    if action == "web_search"
        && result.get("query").and_then(|v| v.as_str()).unwrap_or("").trim().is_empty()
    {
        return None;
    }
    if matches!(action.as_str(), "read_file" | "write_file" | "delete_path")
        && !is_concrete_action_path(result.get("path").and_then(|v| v.as_str()).unwrap_or(""))
    {
        return None;
    }
    Some(result)
}

pub fn parse_json_action(source: &str) -> Option<Value> {
    let payload: Value = serde_json::from_str(source.trim()).ok()?;
    let obj = payload.as_object()?;

    // Merge nested envelope objects.
    let mut values: serde_json::Map<String, Value> = obj.clone();
    for key in ["arguments", "parameters", "input"] {
        if let Some(nested) = obj.get(key).and_then(|v| v.as_object()) {
            for (k, v) in nested {
                values.insert(k.clone(), v.clone());
            }
        }
    }

    let mut action: String = String::new();
    for cand_key in ["action", "biro_action", "tool", "name", "type"] {
        if let Some(v) = values.get(cand_key).and_then(|v| v.as_str()) {
            let normalized = v.trim().to_lowercase().replace('-', "_");
            if let Some(mapped) = alias(&normalized) {
                action = mapped.to_string();
                break;
            }
        }
    }
    if action.is_empty() {
        return None;
    }
    let title = values
        .get("title")
        .and_then(|v| v.as_str())
        .or_else(|| values.get("description").and_then(|v| v.as_str()))
        .map(|s| s.to_string())
        .unwrap_or_else(|| default_title(&action).to_string());

    let get = |aliases: &[&str]| -> Option<String> {
        for a in aliases {
            if let Some(v) = values.get(*a) {
                if v.is_null() {
                    return Some(String::new());
                }
                if let Some(s) = v.as_str() {
                    return Some(s.to_string());
                }
                return None;
            }
        }
        Some(String::new())
    };

    let path = get(&["path", "file_path", "output_path", "destination"])?;
    let cmd = get(&["cmd", "command", "shell_command"])?;
    let body = get(&["body", "content", "file_content", "text"])?;
    let prompt = get(&["prompt", "image_prompt", "description"])?;
    let query = get(&["query", "search_query"])?;

    let mut parsed = json!({
        "title": title, "action": action,
        "path": path, "cmd": cmd, "body": body,
        "prompt": prompt, "query": query,
        "max_results": 5, "fresh": false,
    });

    if action == "shell" && parsed["cmd"].as_str().unwrap_or("").trim().is_empty() {
        return None;
    }
    if matches!(action.as_str(), "read_file" | "write_file" | "delete_path")
        && parsed["path"].as_str().unwrap_or("").trim().is_empty()
    {
        return None;
    }
    if matches!(action.as_str(), "read_file" | "write_file" | "delete_path")
        && !is_concrete_action_path(parsed["path"].as_str().unwrap_or(""))
    {
        return None;
    }
    if action == "generate_image" && parsed["prompt"].as_str().unwrap_or("").trim().is_empty() {
        return None;
    }
    if action == "write_file"
        && !["body", "content", "file_content", "text"]
            .iter()
            .any(|k| values.contains_key(*k))
    {
        return None;
    }
    if action == "web_search" {
        if parsed["query"].as_str().unwrap_or("").trim().is_empty() {
            return None;
        }
        let max_results = values
            .get("max_results")
            .and_then(|v| v.as_i64())
            .unwrap_or(5);
        let fresh = values.get("fresh").and_then(|v| v.as_bool()).unwrap_or(false);
        if !(1..=10).contains(&max_results) {
            return None;
        }
        parsed["max_results"] = json!(max_results);
        parsed["fresh"] = json!(fresh);
    }
    Some(parsed)
}

pub fn split_tool_blocks(response: &str) -> (String, Vec<Value>) {
    #[derive(Clone)]
    struct Candidate {
        start: usize,
        end: usize,
        block: Value,
    }

    let mut matches: Vec<Candidate> = Vec::new();

    // Fenced tool blocks
    for m in tool_re().find_iter(response) {
        let full = m.as_str();
        let inner = full[3..]
            .split_once('\n')
            .map(|(_, rest)| rest)
            .unwrap_or("");
        let inner = inner.trim_end_matches("```").trim_end();
        if let Some(block) = parse_tool_block(inner).or_else(|| parse_json_action(inner)) {
            matches.push(Candidate {
                start: m.start(),
                end: m.end(),
                block,
            });
        }
    }

    // Fenced JSON actions
    for m in json_action_re().find_iter(response) {
        let full = m.as_str();
        let inner = full[3..].split_once('\n').map(|(_, r)| r).unwrap_or("");
        let inner = inner.trim_end_matches("```").trim_end();
        if let Some(block) = parse_json_action(inner) {
            matches.push(Candidate {
                start: m.start(),
                end: m.end(),
                block,
            });
        }
    }

    // Bare JSON action objects
    // Scan for '{' indices and try to parse a Value starting there.
    let mut idx = 0;
    let bytes = response.as_bytes();
    while idx < bytes.len() {
        if bytes[idx] == b'{' {
            let tail = &response[idx..];
            let mut iter = serde_json::Deserializer::from_str(tail).into_iter::<Value>();
            if let Some(Ok(val)) = iter.next() {
                let consumed = iter.byte_offset();
                if let Some(parsed) = parse_json_action(&tail[..consumed]) {
                    matches.push(Candidate {
                        start: idx,
                        end: idx + consumed,
                        block: parsed,
                    });
                }
                idx += consumed;
                continue;
            }
        }
        idx += 1;
    }
    matches.sort_by_key(|c| (c.start, std::cmp::Reverse(c.end - c.start)));

    let mut blocks: Vec<Value> = Vec::new();
    let mut visible = String::new();
    let mut cursor = 0usize;
    for c in matches {
        if c.start < cursor {
            continue;
        }
        visible.push_str(&response[cursor..c.start]);
        blocks.push(c.block);
        cursor = c.end;
    }
    visible.push_str(&response[cursor..]);
    (visible.trim().to_string(), blocks)
}

pub fn has_malformed_action(response: &str) -> bool {
    if action_open_re().is_match(response) {
        return true;
    }
    static BARE: OnceLock<Regex> = OnceLock::new();
    let bare = BARE.get_or_init(|| {
        Regex::new(
            r#"(?is)\{[^{}]{0,4000}["'](?:action|biro_action|tool|name|type)["']\s*:\s*["'](?:generate[_-]image|image[_-]generation|shell|read[_-]file|write[_-]file|delete[_-]path|run[_-]command|execute[_-]command|web[_-]search|tavily[_-]search|search[_-]web|search)"#,
        )
        .unwrap()
    });
    bare.is_match(response)
}

fn shellexpand(s: &str) -> String {
    if s == "~" {
        if let Some(h) = dirs::home_dir() {
            return h.display().to_string();
        }
    }
    if let Some(rest) = s.strip_prefix("~/") {
        if let Some(h) = dirs::home_dir() {
            return h.join(rest).display().to_string();
        }
    }
    s.to_string()
}

pub struct WorkspaceTools {
    pub cwd: PathBuf,
    pub web_search: TavilySearch,
}

impl WorkspaceTools {
    pub fn new(cwd: PathBuf) -> Self {
        Self {
            cwd,
            web_search: TavilySearch::new(),
        }
    }

    pub fn change_cwd(&mut self, path: &str) -> Result<PathBuf, String> {
        let target_str = shellexpand(path);
        let candidate = PathBuf::from(&target_str);
        let target = candidate
            .canonicalize()
            .map_err(|_| format!("Directory does not exist: {}", target_str))?;
        if !target.is_dir() {
            return Err(format!("Directory does not exist: {}", target.display()));
        }
        std::env::set_current_dir(&target).map_err(|e| format!("Failed to change directory: {}", e))?;
        self.cwd = target.clone();
        Ok(target)
    }

    pub fn resolve_path(&self, value: &str) -> Result<PathBuf, String> {
        if value.trim().is_empty() {
            return Err("A non-empty path is required.".into());
        }
        let expanded = shellexpand(value);
        let candidate = PathBuf::from(&expanded);
        let absolute = if candidate.is_absolute() {
            candidate
        } else {
            self.cwd.join(candidate)
        };
        Ok(absolute.canonicalize().unwrap_or(absolute))
    }

    pub fn execute(&mut self, block: &Value) -> String {
        let action = block.get("action").and_then(|v| v.as_str()).unwrap_or("");
        match action {
            "read_file" => self.read_file(block.get("path").and_then(|v| v.as_str()).unwrap_or("")),
            "write_file" => self.write_file(
                block.get("path").and_then(|v| v.as_str()).unwrap_or(""),
                block.get("body").and_then(|v| v.as_str()).unwrap_or(""),
            ),
            "delete_path" => self.delete_path(block.get("path").and_then(|v| v.as_str()).unwrap_or("")),
            "shell" => self.run_shell(block.get("cmd").and_then(|v| v.as_str()).unwrap_or("")),
            "web_search" => {
                let query = block.get("query").and_then(|v| v.as_str()).unwrap_or("");
                let max_results = block
                    .get("max_results")
                    .and_then(|v| v.as_u64())
                    .unwrap_or(5) as u32;
                let fresh = block.get("fresh").and_then(|v| v.as_bool()).unwrap_or(false);
                let result = self.web_search.search(query, max_results, fresh);
                if let Some(err) = result.get("error").and_then(|v| v.as_str()) {
                    return format!("Error: {}", err);
                }
                TavilySearch::format_context(query, &result)
            }
            other => format!("Rejected unsupported action: {:?}", other),
        }
    }

    pub fn read_file(&self, path: &str) -> String {
        match self.resolve_path(path) {
            Ok(full) => {
                if !full.is_file() {
                    return format!("Error: not a regular file: {}", path);
                }
                match fs::read(&full) {
                    Ok(bytes) => String::from_utf8_lossy(&bytes).to_string(),
                    Err(e) => format!("Error reading {}: {}", path, e),
                }
            }
            Err(e) => format!("Error reading {}: {}", path, e),
        }
    }

    pub fn write_file(&self, path: &str, content: &str) -> String {
        match self.resolve_path(path) {
            Ok(full) => {
                if full.exists() && !full.is_file() {
                    return format!("Error: refusing to overwrite a non-file path: {}", path);
                }
                if let Some(parent) = full.parent() {
                    if let Err(e) = fs::create_dir_all(parent) {
                        return format!("Error writing {}: {}", path, e);
                    }
                }
                let fname = full.file_name().and_then(|n| n.to_str()).unwrap_or("file");
                let tmp = full.with_file_name(format!("{}.biro-tmp", fname));
                let result = (|| -> std::io::Result<()> {
                    let mut f = fs::File::create(&tmp)?;
                    f.write_all(content.as_bytes())?;
                    f.sync_all()?;
                    fs::rename(&tmp, &full)?;
                    Ok(())
                })();
                if let Err(e) = result {
                    let _ = fs::remove_file(&tmp);
                    return format!("Error writing {}: {}", path, e);
                }
                format!("Written {} bytes to {}.", content.as_bytes().len(), path)
            }
            Err(e) => format!("Error writing {}: {}", path, e),
        }
    }

    pub fn write_bytes(&self, path: &str, content: &[u8]) -> String {
        match self.resolve_path(path) {
            Ok(full) => {
                if full.exists() && !full.is_file() {
                    return format!("Error: refusing to overwrite a non-file path: {}", path);
                }
                if let Some(parent) = full.parent() {
                    if let Err(e) = fs::create_dir_all(parent) {
                        return format!("Error saving binary file {}: {}", path, e);
                    }
                }
                let fname = full.file_name().and_then(|n| n.to_str()).unwrap_or("file");
                let tmp = full.with_file_name(format!(".{}.biro-tmp", fname));
                let result = (|| -> std::io::Result<()> {
                    let mut f = fs::File::create(&tmp)?;
                    f.write_all(content)?;
                    f.sync_all()?;
                    fs::rename(&tmp, &full)?;
                    Ok(())
                })();
                if let Err(e) = result {
                    let _ = fs::remove_file(&tmp);
                    return format!("Error saving binary file {}: {}", path, e);
                }
                format!("Written {} bytes to {}.", content.len(), path)
            }
            Err(e) => format!("Error saving binary file {}: {}", path, e),
        }
    }

    pub fn delete_path(&self, path: &str) -> String {
        if path.trim().is_empty() {
            return "Error: A non-empty path is required.".into();
        }
        let candidate = PathBuf::from(shellexpand(path));
        let full = if candidate.is_absolute() {
            candidate
        } else {
            self.cwd.join(candidate)
        };
        let resolved = full
            .parent()
            .and_then(|p| p.canonicalize().ok())
            .map(|p| p.join(full.file_name().unwrap_or_default()))
            .unwrap_or_else(|| full.clone());
        if !resolved.exists() && !resolved.is_symlink() {
            return format!("Path does not exist: {}", path);
        }
        if resolved.is_symlink() || resolved.is_file() {
            match fs::remove_file(&resolved) {
                Ok(_) => format!("Deleted file/link {}.", path),
                Err(e) => format!("Error deleting {}: {}", path, e),
            }
        } else if resolved.is_dir() {
            match fs::remove_dir_all(&resolved) {
                Ok(_) => format!("Deleted directory {}.", path),
                Err(e) => format!("Error deleting {}: {}", path, e),
            }
        } else {
            format!("Unsupported path type: {}", path)
        }
    }

    pub fn run_shell(&self, cmd: &str) -> String {
        if cmd.trim().is_empty() {
            return "Error: shell action has no command.".into();
        }
        let start = Instant::now();
        let (shell, flag) = if cfg!(windows) {
            ("cmd", "/C")
        } else {
            ("sh", "-c")
        };
        let mut command = Command::new(shell);
        command.arg(flag).arg(cmd).current_dir(&self.cwd);
        if let Ok(exe) = std::env::current_exe() {
            if let Some(dir) = exe.parent() {
                let existing = std::env::var("PATH").unwrap_or_default();
                let sep = if cfg!(windows) { ";" } else { ":" };
                command.env("PATH", format!("{}{}{}", dir.display(), sep, existing));
            }
        }
        #[cfg(unix)]
        {
            use std::os::unix::process::CommandExt;
            command.process_group(0);
        }
        match command.output() {
            Ok(out) => {
                let mut combined = String::from_utf8_lossy(&out.stdout).to_string();
                combined.push_str(&String::from_utf8_lossy(&out.stderr));
                let elapsed = start.elapsed().as_secs_f64();
                combined.push_str(&format!(
                    "\n[exit code: {}; runtime: {:.1}s]",
                    out.status.code().unwrap_or(-1),
                    elapsed
                ));
                combined
            }
            Err(e) => format!("Error running command: {}", e),
        }
    }
}
