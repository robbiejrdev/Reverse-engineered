use std::path::PathBuf;
use std::sync::{
    atomic::{AtomicBool, Ordering},
    Arc,
};
use std::time::Instant;

use base64::Engine;
use serde_json::{json, Value};

use crate::agent::prompts::SYSTEM_PROMPT;
use crate::agent::tools::{has_malformed_action, split_tool_blocks, WorkspaceTools};
use crate::api::client::{ApiError, BiroApi};
use crate::config::validate_model;
use crate::ui::diff::print_file_diff;

pub struct DetailEntry {
    pub kind: String,
    pub title: String,
    pub content: String,
    pub command: Option<String>,
}

pub struct Agent {
    pub api: BiroApi,
    pub cwd: PathBuf,
    pub think: bool,
    pub max_steps: u32,
    pub deep_research: bool,
    pub tools: WorkspaceTools,
    pub message_count: usize,
    pub last_elapsed: f64,
    pub working_title: String,
    pub thinking_title: String,
    pub stream_preview: String,
    pub details: Vec<DetailEntry>,
    pub reported_tokens_used: u64,
    pub token_usage_complete: bool,
    pub session_token_count: u64,
    pub session_token_count_approximate: bool,
    pub session_lines_added: u64,
    pub session_lines_deleted: u64,
    pub interrupt: Arc<AtomicBool>,
}

impl Agent {
    pub fn new(
        api: BiroApi,
        cwd: PathBuf,
        think: bool,
        max_steps: u32,
        deep_research: bool,
        interrupt: Arc<AtomicBool>,
    ) -> Self {
        let tools = WorkspaceTools::new(cwd.clone());
        Self {
            api,
            cwd,
            think,
            max_steps,
            deep_research,
            tools,
            message_count: 0,
            last_elapsed: 0.0,
            working_title: "Ready".into(),
            thinking_title: "Planning next step".into(),
            stream_preview: String::new(),
            details: Vec::new(),
            reported_tokens_used: 0,
            token_usage_complete: true,
            session_token_count: 0,
            session_token_count_approximate: false,
            session_lines_added: 0,
            session_lines_deleted: 0,
            interrupt,
        }
    }

    pub fn model(&self) -> Result<String, String> {
        validate_model(&self.api.config.model)
    }

    pub fn model_label(&self) -> String {
        match self.model().unwrap_or_else(|_| "biro-max".into()).as_str() {
            "biro-mini" => "BIRO Mini".into(),
            _ => "BIRO Max".into(),
        }
    }

    pub fn system_prompt(&self) -> String {
        let mut p = SYSTEM_PROMPT
            .replace("{cwd}", &self.tools.cwd.display().to_string())
            .replace("{model_label}", &self.model_label());
        if self.deep_research {
            p.push_str("\n\n## Background task quality\n");
            p.push_str("This is a background job. Do not rush: thoroughly inspect relevant files and requirements, research uncertain or time-sensitive facts with available tools, compare evidence, and verify the implementation with appropriate checks. Take the time and action rounds needed for a complete, reliable result; do not stop at a superficial answer or skip validation. Be efficient in execution: avoid repeated inspections and progress-only narration; move directly from findings to implementation and verification, and keep interim user-facing responses concise. ");
            p.push_str("Do not finish with progress narration. After the requested work and verification are truly complete, end your final response with the exact standalone marker `BIRO_BACKGROUND_COMPLETE`. If more work remains, use actions and do not emit the completion marker.");
        }
        p
    }

    pub fn ensure_chat(&mut self) -> Result<Value, ApiError> {
        if !self.api.config.current_chat_id.is_empty() {
            match self.api.get_chat(&self.api.config.current_chat_id.clone()) {
                Ok(c) => return Ok(c),
                Err(e) => {
                    if !matches!(e_status(&e), Some(404) | Some(401)) {
                        return Err(e);
                    }
                    self.api.config.current_chat_id.clear();
                    let _ = self.api.config.save();
                }
            }
        }
        self.api.create_chat("New conversation", true)
    }

    fn conversation_memory(&self, chat_id: &str, prompt: &str, attachments: &[Value]) -> Vec<Value> {
        let Ok(messages) = self.api.list_messages(chat_id) else {
            return Vec::new();
        };
        if messages.len() <= 20 {
            return Vec::new();
        }
        let earlier = &messages[..messages.len() - 20];
        let mut transcript = String::new();
        for m in earlier {
            if let Some(content) = m.get("content").and_then(|v| v.as_str()) {
                if !content.trim().is_empty() {
                    let role = m
                        .get("role")
                        .and_then(|v| v.as_str())
                        .unwrap_or("message")
                        .to_uppercase();
                    transcript.push_str(&format!("{}: {}\n\n", role, content));
                }
            }
        }
        let prompt_parts = if prompt.len() <= 12_000 {
            0
        } else {
            (prompt.len() + 79_999) / 80_000
        };
        let slots = 4usize
            .saturating_sub(attachments.len())
            .saturating_sub(prompt_parts);
        let limit = slots * 80_000;
        if transcript.is_empty() || limit == 0 {
            return Vec::new();
        }
        if transcript.len() > limit {
            let marker = "[Earlier messages omitted to fit the backend attachment limit. Recent earlier context follows.]\n";
            let keep = limit.saturating_sub(marker.len());
            let start = transcript.len().saturating_sub(keep);
            // ensure char boundary
            let mut start = start;
            while start < transcript.len() && !transcript.is_char_boundary(start) {
                start += 1;
            }
            transcript = format!("{}{}", marker, &transcript[start..]);
        }
        let mut out = Vec::new();
        let mut i = 0usize;
        let mut part = 1usize;
        while i < transcript.len() {
            let mut end = (i + 80_000).min(transcript.len());
            while end > i && !transcript.is_char_boundary(end) {
                end -= 1;
            }
            let chunk = &transcript[i..end];
            let encoded = base64::engine::general_purpose::STANDARD.encode(chunk.as_bytes());
            out.push(json!({
                "filename": format!("biro-memory-part-{:02}.txt", part),
                "mime_type": "text/plain",
                "data_base64": encoded,
                "text_content": chunk,
                "vision_frames": [],
            }));
            part += 1;
            i = end;
        }
        out
    }

    pub fn send(&mut self, prompt: &str, attachments: Vec<Value>) -> i32 {
        if prompt.trim().is_empty() {
            println!("Nothing to send.");
            return 0;
        }
        let started = Instant::now();
        self.message_count += 1;
        self.details.clear();
        let result = self.send_impl(prompt, attachments);
        self.last_elapsed = started.elapsed().as_secs_f64();
        result
    }

    fn send_impl(&mut self, prompt: &str, attachments: Vec<Value>) -> i32 {
        let chat = match self.ensure_chat() {
            Ok(c) => c,
            Err(e) => {
                println!("\x1b[1;31mBIRO API error:\x1b[0m {}", e);
                return 1;
            }
        };
        let chat_id = chat
            .get("id")
            .and_then(|v| v.as_str())
            .unwrap_or("")
            .to_string();
        let mut needs_model_title = is_untitled(&chat);
        if needs_model_title {
            needs_model_title = self
                .api
                .list_messages(&chat_id)
                .map(|m| m.is_empty())
                .unwrap_or(false);
        }
        let mut current_prompt = prompt.to_string();
        let mut current_attachments = attachments;
        let mut step = 0u32;
        let mut protocol_retries = 0u32;
        let mut completion_retries = 0u32;

        loop {
            if self.max_steps > 0 && step >= self.max_steps {
                break;
            }
            self.stream_preview.clear();
            self.set_working_title("Thinking");
            let memory = self.conversation_memory(&chat_id, &current_prompt, &current_attachments);
            let mut request_attachments = current_attachments.clone();
            request_attachments.extend(memory);
            let model = self.model().unwrap_or_else(|_| "biro-max".into());
            let payload = match BiroApi::build_prompt_payload(
                &current_prompt,
                &model,
                &self.system_prompt(),
                &request_attachments,
            ) {
                Ok(p) => p,
                Err(e) => {
                    println!("\x1b[1;31mBIRO API error:\x1b[0m {}", e);
                    return 1;
                }
            };

            let mut response_parts = String::new();
            let mut saw_done = false;
            let mut saw_interrupted = false;
            let mut reported_usage: Option<u64> = None;
            let interrupt = self.interrupt.clone();
            let think = self.think;
            let thinking_title = &mut self.thinking_title;
            let working_title = &mut self.working_title;
            let stream_preview = &mut self.stream_preview;
            let mut title_probe = String::new();
            let mut step_title_shown = false;

            let result = self.api.stream_message(&chat_id, &payload, |event| {
                if interrupt.load(Ordering::SeqCst) {
                    saw_interrupted = true;
                    return false;
                }
                match event.get("type").and_then(|v| v.as_str()).unwrap_or("") {
                    "thinking" => {
                        if think {
                            let hint = event
                                .get("title")
                                .or_else(|| event.get("summary"))
                                .or_else(|| event.get("label"))
                                .and_then(|v| v.as_str());
                            if let Some(h) = hint {
                                let cleaned: String = h.split_whitespace().collect::<Vec<_>>().join(" ");
                                if !cleaned.is_empty() {
                                    let truncated: String = cleaned.chars().take(90).collect();
                                    *thinking_title = truncated;
                                }
                            }
                        }
                    }
                    "delta" => {
                        let frag = event.get("text").and_then(|v| v.as_str()).unwrap_or("");
                        response_parts.push_str(frag);
                        *stream_preview = safe_stream_preview(&response_parts);
                        print!("\r\x1b[K\x1b[2m{}\x1b[0m", first_line(stream_preview));
                        use std::io::Write;
                        let _ = std::io::stdout().flush();
                        if !step_title_shown {
                            title_probe.push_str(frag);
                            if title_probe.len() > 2048 {
                                title_probe = title_probe[title_probe.len() - 2048..].to_string();
                            }
                            if let Some(t) = extract_title(&title_probe) {
                                *working_title = t.clone();
                                if think {
                                    *thinking_title = t;
                                }
                                step_title_shown = true;
                            }
                        }
                    }
                    "done" => {
                        saw_done = true;
                        if let Some(assistant) = event.get("assistant_message") {
                            if let Some(content) = assistant.get("content").and_then(|v| v.as_str()) {
                                if content.len() >= response_parts.len() {
                                    response_parts = content.to_string();
                                    *stream_preview = safe_stream_preview(&response_parts);
                                }
                            }
                        }
                        if let Some(usage) = event.get("usage").and_then(|v| v.as_object()) {
                            if let Some(total) = usage.get("total_tokens").and_then(|v| v.as_u64()) {
                                reported_usage = Some(total);
                            } else {
                                let p = usage.get("prompt_tokens").and_then(|v| v.as_u64());
                                let c = usage.get("completion_tokens").and_then(|v| v.as_u64());
                                if let (Some(p), Some(c)) = (p, c) {
                                    reported_usage = Some(p + c);
                                }
                            }
                        }
                    }
                    "interrupted" => {
                        saw_interrupted = true;
                        return false;
                    }
                    _ => {}
                }
                true
            });

            print!("\r\x1b[K");
            use std::io::Write;
            let _ = std::io::stdout().flush();

            if let Err(e) = result {
                println!("\x1b[1;31mBIRO API error:\x1b[0m {}", e);
                return 1;
            }
            if saw_interrupted {
                println!("Response interrupted. BIRO stopped the active generation; no partial action was executed.");
                return 130;
            }

            if let Some(usage) = reported_usage {
                self.reported_tokens_used += usage;
                self.session_token_count += usage;
            } else {
                let estimate = ((current_prompt.len() + response_parts.len() + 3) / 4) as u64;
                self.session_token_count += estimate;
                self.session_token_count_approximate = true;
                self.token_usage_complete = false;
            }

            if response_parts.trim().is_empty() && !saw_done {
                println!("\x1b[31mBIRO returned no response.\x1b[0m");
                return 1;
            }

            let (visible, blocks) = split_tool_blocks(&response_parts);

            if blocks.is_empty() {
                if has_malformed_action(&response_parts) {
                    if protocol_retries < 4 {
                        protocol_retries += 1;
                        current_attachments.clear();
                        current_prompt = "ACTION_PROTOCOL_REPAIR: Your previous response attempted to request a local action, but the CLI could not parse a complete valid action block, so nothing was executed. Retry now with exactly one complete fenced `biro-action` JSON block. Use valid JSON, a supported action, every required field, and the closing triple-backtick fence. For any file creation or edit, use the `write_file` action with the complete file body; never use `cat <<EOF`, shell redirection, or shell to write source files. Every path must name one concrete file or directory. Never use brace expansion or comma-separated brace paths such as `{src,include,tests,examples}`; use one explicit path per action. For an image use action=generate_image with prompt and optional workspace-relative path. Do not repeat malformed syntax and do not claim the action ran.".to_string();
                        step += 1;
                        continue;
                    }
                    println!("\x1b[31mBIRO couldn't produce a valid complete action block after four repair attempts. No local action was executed.\x1b[0m");
                    return 1;
                }
                let mut visible_final = visible.clone();
                if self.deep_research {
                    let trimmed = visible_final.trim_end();
                    if trimmed.ends_with("BIRO_BACKGROUND_COMPLETE") {
                        visible_final = trimmed.trim_end_matches("BIRO_BACKGROUND_COMPLETE").trim_end().to_string();
                    } else {
                        if completion_retries >= 4 {
                            println!("\x1b[31mBackground agent stopped without confirming task completion. The job is marked failed rather than complete.\x1b[0m");
                            return 1;
                        }
                        completion_retries += 1;
                        current_attachments.clear();
                        current_prompt = "BACKGROUND_TASK_INCOMPLETE: Your last response was progress narration, not a completion report. Continue the requested work now using BIRO actions. Inspect the actual files and requirements, make the needed changes, run appropriate verification, and only when fully finished provide a concise summary ending with the standalone marker `BIRO_BACKGROUND_COMPLETE`. Do not claim completion or emit the marker while work remains.".to_string();
                        step += 1;
                        continue;
                    }
                }
                if !visible_final.trim().is_empty() {
                    if needs_model_title {
                        let proposed = title_from_response(&visible_final, prompt);
                        if !proposed.is_empty() {
                            let _ = self.api.update_chat(&chat_id, &proposed);
                            needs_model_title = false;
                        }
                    }
                    self.set_working_title("Response complete");
                    self.stream_preview.clear();
                    println!("{}", visible_final);
                }
                return 0;
            }

            if self.deep_research {
                completion_retries = 0;
            }

            current_attachments.clear();
            let block = &blocks[0];
            let model_action_title = block
                .get("title")
                .and_then(|v| v.as_str())
                .unwrap_or("")
                .to_string();
            let action_title = if model_action_title.is_empty() {
                "BIRO action".to_string()
            } else {
                model_action_title.clone()
            };
            let action = block.get("action").and_then(|v| v.as_str()).unwrap_or("").to_string();

            if needs_model_title && !model_action_title.is_empty() {
                let t: String = model_action_title.chars().take(72).collect();
                let _ = self.api.update_chat(&chat_id, &t);
                needs_model_title = false;
            }

            match action.as_str() {
                "shell" => {
                    println!("\x1b[1;32m● EXECUTING SHELL\x1b[0m · {}", action_title);
                    println!(
                        "\x1b[2;37m  $ {}\x1b[0m",
                        block.get("cmd").and_then(|v| v.as_str()).unwrap_or("")
                    );
                }
                "generate_image" => {
                    let target = block
                        .get("path")
                        .and_then(|v| v.as_str())
                        .unwrap_or("public/images/biro-generated-image.png");
                    println!("\x1b[1;32mIMAGE REQUEST\x1b[0m · {} → {}", action_title, target);
                }
                _ => {}
            }

            let mut previous_file_contents: Option<String> = None;
            if action == "write_file" {
                match self
                    .tools
                    .resolve_path(block.get("path").and_then(|v| v.as_str()).unwrap_or(""))
                {
                    Ok(p) if p.exists() => {
                        previous_file_contents = std::fs::read_to_string(&p).ok();
                    }
                    Ok(_) => previous_file_contents = Some(String::new()),
                    Err(_) => previous_file_contents = None,
                }
            }
            self.set_working_title(&action_title);
            let result = self.execute_action(block, &chat_id);
            if action == "shell" {
                self.details.push(DetailEntry {
                    kind: "command".into(),
                    title: action_title.clone(),
                    command: Some(
                        block
                            .get("cmd")
                            .and_then(|v| v.as_str())
                            .unwrap_or("")
                            .to_string(),
                    ),
                    content: result.clone(),
                });
            }
            if result.starts_with("Error")
                || result.starts_with("Image generation failed:")
                || result.starts_with("Rejected")
                || result.starts_with("Blocked")
                || result.starts_with("Cancelled")
            {
                println!("\x1b[1;33mACTION FAILED\x1b[0m · {}", action_title);
                println!("{}", result);
            } else {
                println!("\x1b[1;32mCompleted\x1b[0m  {}", action_title);
                if action == "generate_image" {
                    if let Some(line) = result.lines().find(|l| l.starts_with("Written ")) {
                        println!("\x1b[2m{}\x1b[0m", line);
                    }
                }
            }
            if action == "generate_image" && result.starts_with("Image generation failed:") {
                println!("\x1b[2mNo placeholder image was written. The error came from BIRO's image service; check the backend's image-provider configuration/logs and retry after that service is healthy.\x1b[0m");
                return 1;
            }
            if action == "write_file" && result.starts_with("Written ") {
                let body = block.get("body").and_then(|v| v.as_str()).unwrap_or("");
                let path = block.get("path").and_then(|v| v.as_str()).unwrap_or("");
                print_file_diff(path, previous_file_contents.as_deref(), body);
                if let Some(prev) = &previous_file_contents {
                    let diff = similar::TextDiff::from_lines(prev.as_str(), body);
                    let mut adds = 0u64;
                    let mut dels = 0u64;
                    for c in diff.iter_all_changes() {
                        match c.tag() {
                            similar::ChangeTag::Insert => adds += 1,
                            similar::ChangeTag::Delete => dels += 1,
                            similar::ChangeTag::Equal => {}
                        }
                    }
                    self.session_lines_added += adds;
                    self.session_lines_deleted += dels;
                }
            }

            current_prompt = format!(
                "[Local tool result: {}]\nAction: {}\nResult:\n{}\n\nUse this actual result to decide the next step. If more work is needed, emit exactly one next complete action block (prefer the documented JSON `biro-action` format). If the task is complete, explain what was done and what tests succeeded or failed.",
                block.get("title").and_then(|v| v.as_str()).unwrap_or(""),
                block.get("action").and_then(|v| v.as_str()).unwrap_or(""),
                result
            );
            step += 1;
            self.set_working_title("Planning next action");
        }
        if self.max_steps > 0 && step >= self.max_steps {
            println!(
                "\x1b[33mReached the optional {}-step limit. Send another message to continue.\x1b[0m",
                self.max_steps
            );
        }
        0
    }

    fn execute_action(&mut self, block: &Value, chat_id: &str) -> String {
        let action = block.get("action").and_then(|v| v.as_str()).unwrap_or("");
        if action != "generate_image" {
            return self.tools.execute(block);
        }
        let prompt = block
            .get("prompt")
            .and_then(|v| v.as_str())
            .unwrap_or("")
            .trim()
            .to_string();
        if prompt.is_empty() {
            return "Image generation failed: the JSON action needs a non-empty prompt.".into();
        }
        let requested_path = block
            .get("path")
            .and_then(|v| v.as_str())
            .unwrap_or("public/images/biro-generated-image.png")
            .trim()
            .to_string();
        let generated = match self.api.generate_image(chat_id, &prompt) {
            Ok(g) => g,
            Err(e) => return format!("Image generation failed: {}", e),
        };
        let artifact_id = generated
            .get("artifact")
            .and_then(|a| a.get("id"))
            .and_then(|v| v.as_str());
        let Some(artifact_id) = artifact_id else {
            return "Image generation failed: BIRO's image endpoint did not return an artifact ID.".into();
        };
        let (data, mime) = match self.api.download_artifact(chat_id, artifact_id) {
            Ok(x) => x,
            Err(e) => return format!("Image generation failed: {}", e),
        };
        let ext = match mime.as_str() {
            "image/png" => ".png",
            "image/jpeg" => ".jpg",
            "image/webp" => ".webp",
            "image/gif" => ".gif",
            _ => {
                return format!(
                    "Image generation failed: the image endpoint returned unsupported content type {:?}.",
                    mime
                )
            }
        };
        let target = if requested_path.to_lowercase().ends_with(ext) {
            requested_path
        } else {
            let pb = std::path::Path::new(&requested_path);
            let stem = pb.file_stem().and_then(|s| s.to_str()).unwrap_or("image");
            let parent = pb
                .parent()
                .map(|p| p.display().to_string())
                .unwrap_or_default();
            if parent.is_empty() {
                format!("{}{}", stem, ext)
            } else {
                format!("{}/{}{}", parent, stem, ext)
            }
        };
        let result = self.tools.write_bytes(&target, &data);
        if result.starts_with("Written ") {
            format!(
                "Image generated by BIRO's image API.\n{}\nContent type: {}. Use the saved path in the relevant webpage/component.",
                result, mime
            )
        } else {
            result
        }
    }

    fn set_working_title(&mut self, title: &str) {
        let clean: String = title.split_whitespace().collect::<Vec<_>>().join(" ");
        if !clean.is_empty() {
            self.working_title = clean.chars().take(160).collect();
        }
    }
}

fn first_line(s: &str) -> String {
    s.lines().next().unwrap_or("").chars().take(140).collect()
}

fn e_status(e: &ApiError) -> Option<u16> {
    match e {
        ApiError::Http(_, s) => Some(*s),
        _ => None,
    }
}

fn is_untitled(chat: &Value) -> bool {
    let title = chat
        .get("title")
        .and_then(|v| v.as_str())
        .unwrap_or("New conversation")
        .trim()
        .to_lowercase();
    matches!(title.as_str(), "" | "new conversation" | "untitled")
}

fn safe_stream_preview(response: &str) -> String {
    let mut preview = response.to_string();
    for marker in &["```biro-action", "```tool"] {
        if let Some(pos) = preview.to_lowercase().find(marker) {
            preview = preview[..pos].to_string();
        }
    }
    if let Some(fence) = preview.rfind("```") {
        let after = &preview[fence + 3..];
        if !after.contains('\n') {
            let partial = after.trim().to_lowercase();
            if "biro-action".starts_with(&partial) || "tool".starts_with(&partial) {
                preview = preview[..fence].to_string();
            }
        }
    }
    preview.trim().to_string()
}

fn extract_title(probe: &str) -> Option<String> {
    use std::sync::OnceLock;
    static R1: OnceLock<regex::Regex> = OnceLock::new();
    static R2: OnceLock<regex::Regex> = OnceLock::new();
    let r1 = R1.get_or_init(|| regex::Regex::new(r"(?s)```tool\s*\ntitle:\s*([^\r\n]+)").unwrap());
    let r2 = R2.get_or_init(|| regex::Regex::new(r#""title"\s*:\s*"([^"\n]{1,100})""#).unwrap());
    if let Some(c) = r1.captures(probe) {
        if let Some(m) = c.get(1) {
            return Some(m.as_str().trim().to_string());
        }
    }
    if let Some(c) = r2.captures(probe) {
        if let Some(m) = c.get(1) {
            return Some(m.as_str().trim().to_string());
        }
    }
    None
}

pub fn title_from_response(response: &str, fallback: &str) -> String {
    for raw in response.lines() {
        let mut line = raw.trim().to_string();
        if line.is_empty() {
            continue;
        }
        while line.starts_with('#') {
            line.remove(0);
        }
        line = line
            .trim_start_matches(|c: char| c == '-' || c == '*' || c == '+')
            .trim_start()
            .to_string();
        line = line.replace('`', "");
        for sentence in line.split(|c| c == '.' || c == '!' || c == '?') {
            let s = sentence.trim_matches(|c: char| c.is_whitespace() || "\"'`*#".contains(c));
            if s.split_whitespace().count() >= 3
                && !matches!(s.to_lowercase().as_str(), "of course." | "sure thing.")
            {
                return s.chars().take(72).collect();
            }
        }
    }
    if !fallback.trim().is_empty() {
        let cleaned = fallback.split_whitespace().collect::<Vec<_>>().join(" ");
        return cleaned.chars().take(72).collect();
    }
    "New conversation".into()
}
