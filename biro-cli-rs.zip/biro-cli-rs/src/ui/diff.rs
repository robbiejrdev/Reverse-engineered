use similar::{ChangeTag, TextDiff};

const MAX_PREVIEW_LINES: usize = 10;

pub fn print_file_diff(path: &str, before: Option<&str>, after: &str) {
    let before = match before {
        Some(b) => b,
        None => {
            println!(
                "Updated {}; previous content is not readable as UTF-8, so no text diff is available.",
                path
            );
            return;
        }
    };

    let diff = TextDiff::from_lines(before, after);
    let mut additions = 0usize;
    let mut deletions = 0usize;
    let mut preview: Vec<(char, usize, String)> = Vec::new();

    // Collect changed-line positions with line numbers, tracking total counts.
    let mut old_no = 0usize;
    let mut new_no = 0usize;
    for change in diff.iter_all_changes() {
        let tag = change.tag();
        match tag {
            ChangeTag::Equal => {
                old_no += 1;
                new_no += 1;
            }
            ChangeTag::Delete => {
                deletions += 1;
                old_no += 1;
                preview.push(('-', old_no, change.value().trim_end().to_string()));
            }
            ChangeTag::Insert => {
                additions += 1;
                new_no += 1;
                preview.push(('+', new_no, change.value().trim_end().to_string()));
            }
        }
    }

    if preview.is_empty() {
        println!("No content changes · {}", path);
        return;
    }

    println!(
        "\x1b[2mDIFF · {} · \x1b[0m\x1b[32m+{}\x1b[0m \x1b[31m−{}\x1b[0m",
        path, additions, deletions
    );

    // Spread preview selection across the whole diff like the Python version.
    let take = preview.len().min(MAX_PREVIEW_LINES);
    let indices: Vec<usize> = if preview.len() <= take {
        (0..preview.len()).collect()
    } else {
        let mut out = Vec::with_capacity(take);
        for i in 0..take {
            let pos = ((i as f64) * ((preview.len() - 1) as f64) / ((take - 1).max(1) as f64)).round() as usize;
            out.push(pos);
        }
        out.sort();
        out.dedup();
        out
    };

    for idx in &indices {
        let (marker, line_no, content) = &preview[*idx];
        let bg = if *marker == '+' { "48;5;22" } else { "48;5;52" };
        let fg = if *marker == '+' { "38;5;121" } else { "38;5;211" };
        println!(
            "\x1b[{};{}m{}{:>5} │ {}\x1b[0m",
            bg, fg, marker, line_no, content
        );
    }

    let omitted = preview.len() - indices.len();
    if omitted > 0 {
        println!("\x1b[2m… {} changed lines omitted from this preview.\x1b[0m", omitted);
    }
}
