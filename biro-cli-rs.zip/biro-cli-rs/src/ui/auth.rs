use std::io::Write;

use crate::api::client::BiroApi;

fn ask(prompt: &str) -> Option<String> {
    print!("{}", prompt);
    let _ = std::io::stdout().flush();
    let mut line = String::new();
    match std::io::stdin().read_line(&mut line) {
        Ok(0) => None,
        Ok(_) => Some(line.trim().to_string()),
        Err(_) => None,
    }
}

fn ask_password(prompt: &str) -> Option<String> {
    print!("{}", prompt);
    let _ = std::io::stdout().flush();

    // On Unix, disable terminal echo while reading the password. If stdin is
    // not a terminal (or `stty` is unavailable), fall back to ordinary input.
    #[cfg(unix)]
    let echo_disabled = std::process::Command::new("stty")
        .arg("-echo")
        .stdin(std::process::Stdio::inherit())
        .stderr(std::process::Stdio::null())
        .status()
        .map(|status| status.success())
        .unwrap_or(false);

    let mut line = String::new();
    let read_result = std::io::stdin().read_line(&mut line);

    #[cfg(unix)]
    if echo_disabled {
        let _ = std::process::Command::new("stty")
            .arg("echo")
            .stdin(std::process::Stdio::inherit())
            .stderr(std::process::Stdio::null())
            .status();
        println!();
    }

    match read_result {
        Ok(0) | Err(_) => None,
        Ok(_) => Some(line.trim_end_matches(['\r', '\n']).to_string()),
    }
}


pub fn login_flow(api: &mut BiroApi) -> anyhow::Result<bool> {
    println!("\x1b[1mSign in to BIRO\x1b[0m");
    println!("\x1b[2mYour account and conversations are stored by BIRO's backend.\x1b[0m");
    let default = api.config.email.clone();
    let prompt = if default.is_empty() {
        "Email: ".to_string()
    } else {
        format!("Email [{}]: ", default)
    };
    let email = match ask(&prompt) {
        Some(v) if !v.is_empty() => v,
        Some(_) => default,
        None => return Ok(false),
    };
    if email.is_empty() {
        return Ok(false);
    }
    let Some(password) = ask_password("Password: ") else {
        println!("\n\x1b[2mSign-in cancelled.\x1b[0m");
        return Ok(false);
    };
    if password.is_empty() {
        println!("\x1b[31mPassword cannot be empty.\x1b[0m");
        return Ok(false);
    }
    match api.login(&email, &password) {
        Ok(_) => {
            println!(
                "\x1b[32mSigned in\x1b[0m as {}",
                if api.config.display_name.is_empty() {
                    &api.config.email
                } else {
                    &api.config.display_name
                }
            );
            Ok(true)
        }
        Err(e) => {
            println!("\x1b[31mSign-in failed:\x1b[0m {}", e);
            Ok(false)
        }
    }
}

pub fn signup_flow(api: &mut BiroApi) -> anyhow::Result<bool> {
    println!("\x1b[1mCreate your BIRO account\x1b[0m");
    println!("\x1b[2mUse the same account across supported BIRO clients.\x1b[0m");
    let Some(display_name) = ask("Display name: ") else {
        println!("\n\x1b[2mSign-up cancelled.\x1b[0m");
        return Ok(false);
    };
    let Some(email) = ask("Email: ") else {
        println!("\n\x1b[2mSign-up cancelled.\x1b[0m");
        return Ok(false);
    };
    let Some(password) = ask_password("Create password (10+ characters): ") else {
        println!("\n\x1b[2mSign-up cancelled.\x1b[0m");
        return Ok(false);
    };
    let Some(confirm) = ask_password("Confirm password: ") else {
        println!("\n\x1b[2mSign-up cancelled.\x1b[0m");
        return Ok(false);
    };
    if display_name.is_empty() {
        println!("\x1b[31mDisplay name cannot be empty.\x1b[0m");
        return Ok(false);
    }
    if password.chars().count() < 10 {
        println!("\x1b[31mThe backend requires a password of at least 10 characters.\x1b[0m");
        return Ok(false);
    }
    if password.as_bytes().len() > 72 {
        println!("\x1b[31mThe current backend password has a 72-byte limit. Choose a shorter password.\x1b[0m");
        return Ok(false);
    }
    if password != confirm {
        println!("\x1b[31mThe passwords do not match.\x1b[0m");
        return Ok(false);
    }
    match api.signup(&display_name, &email, &password) {
        Ok(_) => {
            println!(
                "\x1b[32mAccount created.\x1b[0m Welcome, {}",
                if api.config.display_name.is_empty() {
                    &display_name
                } else {
                    &api.config.display_name
                }
            );
            Ok(true)
        }
        Err(e) => {
            println!("\x1b[31mSign-up failed:\x1b[0m {}", e);
            Ok(false)
        }
    }
}

pub fn authenticate(api: &mut BiroApi) -> anyhow::Result<bool> {
    if !api.config.access_token.is_empty() {
        match api.me() {
            Ok(user) => {
                if let Some(dn) = user.get("display_name").and_then(|v| v.as_str()) {
                    api.config.display_name = dn.to_string();
                }
                if let Some(em) = user.get("email").and_then(|v| v.as_str()) {
                    api.config.email = em.to_string();
                }
                let _ = api.config.save();
                return Ok(true);
            }
            Err(e) => {
                let status = match &e {
                    crate::api::client::ApiError::Http(_, s) => Some(*s),
                    _ => None,
                };
                if status != Some(401) {
                    println!("\x1b[31mCan't verify your BIRO session:\x1b[0m {}", e);
                    return Ok(false);
                }
                println!("\x1b[33mYour saved BIRO session has expired.\x1b[0m");
                let mut cfg = api.config.clone();
                let _ = cfg.clear_session();
                api.config = cfg;
            }
        }
    }
    loop {
        println!("\n\x1b[1mWelcome to BIRO CLI\x1b[0m");
        println!("\x1b[36m1\x1b[0m Sign in\n\x1b[36m2\x1b[0m Create an account\n\x1b[36m3\x1b[0m Exit");
        let Some(choice) = ask("Choose 1–3: ") else {
            return Ok(false);
        };
        match choice.as_str() {
            "1" => {
                if login_flow(api)? {
                    return Ok(true);
                }
            }
            "2" => {
                if signup_flow(api)? {
                    return Ok(true);
                }
            }
            "3" => return Ok(false),
            _ => println!("\x1b[2mEnter 1, 2, or 3.\x1b[0m"),
        }
    }
}
