use std::fs;
use std::path::PathBuf;

use serde::{Deserialize, Serialize};

pub const DEFAULT_API_URL: &str = "https://api.robbiejr.site";
pub const VALID_MODELS: &[&str] = &["biro-max", "biro-mini"];

pub fn config_dir() -> PathBuf {
    if let Ok(over) = std::env::var("BIRO_CONFIG_DIR") {
        return PathBuf::from(over);
    }
    let base = std::env::var("XDG_CONFIG_HOME")
        .ok()
        .map(PathBuf::from)
        .or_else(|| dirs::home_dir().map(|h| h.join(".config")))
        .unwrap_or_else(|| PathBuf::from(".config"));
    base.join("biro")
}

fn default_api_url() -> String {
    DEFAULT_API_URL.to_string()
}
fn default_model() -> String {
    "biro-max".to_string()
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct UserConfig {
    #[serde(default = "default_api_url")]
    pub api_url: String,
    #[serde(default)]
    pub access_token: String,
    #[serde(default)]
    pub email: String,
    #[serde(default)]
    pub display_name: String,
    #[serde(default = "default_model")]
    pub model: String,
    #[serde(default)]
    pub current_chat_id: String,
}

impl Default for UserConfig {
    fn default() -> Self {
        Self {
            api_url: DEFAULT_API_URL.into(),
            access_token: String::new(),
            email: String::new(),
            display_name: String::new(),
            model: "biro-max".into(),
            current_chat_id: String::new(),
        }
    }
}

impl UserConfig {
    pub fn load() -> anyhow::Result<Self> {
        let path = config_dir().join("config.json");
        let mut cfg = if path.exists() {
            let text = fs::read_to_string(&path)?;
            serde_json::from_str::<Self>(&text).map_err(|e| {
                anyhow::anyhow!(
                    "Could not read {}. Back it up or remove it to recreate the config: {}",
                    path.display(),
                    e
                )
            })?
        } else {
            Self::default()
        };
        if let Ok(v) = std::env::var("BIRO_API_URL") {
            cfg.api_url = v;
        }
        if let Ok(v) = std::env::var("BIRO_MODEL") {
            cfg.model = v;
        }
        cfg.api_url = cfg.api_url.trim_end_matches('/').to_string();
        Ok(cfg)
    }

    pub fn save(&self) -> anyhow::Result<()> {
        let dir = config_dir();
        fs::create_dir_all(&dir)?;
        #[cfg(unix)]
        {
            use std::os::unix::fs::PermissionsExt;
            let _ = fs::set_permissions(&dir, fs::Permissions::from_mode(0o700));
        }
        let path = dir.join("config.json");
        let tmp = path.with_extension("tmp");
        let payload = serde_json::to_string_pretty(self)?;

        #[cfg(unix)]
        {
            use std::io::Write;
            use std::os::unix::fs::OpenOptionsExt;
            let mut f = fs::OpenOptions::new()
                .write(true)
                .create(true)
                .truncate(true)
                .mode(0o600)
                .open(&tmp)?;
            f.write_all(payload.as_bytes())?;
            f.sync_all()?;
        }
        #[cfg(not(unix))]
        {
            fs::write(&tmp, payload.as_bytes())?;
        }
        fs::rename(&tmp, &path)?;
        #[cfg(unix)]
        {
            use std::os::unix::fs::PermissionsExt;
            let _ = fs::set_permissions(&path, fs::Permissions::from_mode(0o600));
        }
        Ok(())
    }

    pub fn clear_session(&mut self) -> anyhow::Result<()> {
        self.access_token.clear();
        self.email.clear();
        self.display_name.clear();
        self.current_chat_id.clear();
        self.save()
    }
}

pub fn validate_model(model: &str) -> Result<String, String> {
    let key = model.trim().to_lowercase().replace('_', "-");
    let key = match key.as_str() {
        "max" => "biro-max",
        "mini" => "biro-mini",
        "biro max" => "biro-max",
        "biro mini" => "biro-mini",
        other => other,
    };
    if !VALID_MODELS.contains(&key) {
        return Err("Choose BIRO Max (`max`) or BIRO Mini (`mini`).".into());
    }
    Ok(key.to_string())
}
