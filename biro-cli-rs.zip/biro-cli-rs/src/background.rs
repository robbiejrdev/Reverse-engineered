use std::fs;
use std::path::PathBuf;
use std::process::{Command, Stdio};
use std::time::{SystemTime, UNIX_EPOCH};

use serde::{Deserialize, Serialize};
use serde_json::Value;

use crate::config::config_dir;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BackgroundTask {
    pub id: String,
    pub status: String,
    pub prompt: String,
    pub cwd: String,
    pub chat_id: String,
    pub max_steps: u32,
    pub created_at: u64,
    #[serde(default)]
    pub started_at: Option<u64>,
    #[serde(default)]
    pub finished_at: Option<u64>,
    #[serde(default)]
    pub duration_seconds: Option<f64>,
    #[serde(default)]
    pub returncode: Option<i32>,
    #[serde(default)]
    pub pid: Option<u32>,
    #[serde(default)]
    pub error: Option<String>,
    #[serde(default)]
    pub pm2_name: Option<String>,
}

fn task_dir() -> PathBuf {
    config_dir().join("background")
}

fn task_path(id: &str) -> PathBuf {
    task_dir().join(format!("{}.json", id))
}

fn now_ts() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_secs())
        .unwrap_or(0)
}

fn save_task(task: &BackgroundTask) -> anyhow::Result<()> {
    let dir = task_dir();
    fs::create_dir_all(&dir)?;
    let target = task_path(&task.id);
    let tmp = target.with_extension("tmp");
    fs::write(&tmp, serde_json::to_string_pretty(task)?)?;
    fs::rename(tmp, target)?;
    Ok(())
}

fn read_task(id: &str) -> Option<BackgroundTask> {
    let text = fs::read_to_string(task_path(id)).ok()?;
    serde_json::from_str(&text).ok()
}

pub fn list_tasks() -> Vec<BackgroundTask> {
    let dir = task_dir();
    let Ok(entries) = fs::read_dir(&dir) else {
        return Vec::new();
    };
    let mut out = Vec::new();
    for entry in entries.flatten() {
        let path = entry.path();
        if path.extension().and_then(|e| e.to_str()) != Some("json") {
            continue;
        }
        if let Ok(text) = fs::read_to_string(&path) {
            if let Ok(task) = serde_json::from_str::<BackgroundTask>(&text) {
                out.push(task);
            }
        }
    }
    out.sort_by(|a, b| b.created_at.cmp(&a.created_at));
    out
}

pub fn show_background_tasks() {
    let tasks = list_tasks();
    if tasks.is_empty() {
        println!("\x1b[2mNo background tasks yet. Start one with -p \"...\" --background.\x1b[0m");
        return;
    }
    println!(
        "{:<12} {:<10} {:<16} {:<10} {}",
        "Task", "Status", "Chat ID", "Started", "Duration"
    );
    for task in tasks.iter().take(20) {
        let dur = if let Some(secs) = task.duration_seconds {
            format_duration(secs)
        } else if let Some(start) = task.started_at {
            let now = now_ts();
            format_duration((now.saturating_sub(start)) as f64)
        } else {
            "—".to_string()
        };
        let status_color = if matches!(task.status.as_str(), "queued" | "running" | "starting") {
            "32"
        } else {
            "33"
        };
        let started = format_ts(task.created_at);
        println!(
            "{:<12} \x1b[{}m{:<10}\x1b[0m {:<16} {:<10} {}",
            task.id, status_color, task.status, task.chat_id, started, dur
        );
    }
    println!("\x1b[2mWorker logs are stored next to each task record in the BIRO config directory.\x1b[0m");
}

fn format_duration(seconds: f64) -> String {
    let total = seconds.max(0.0) as u64;
    let h = total / 3600;
    let m = (total % 3600) / 60;
    let s = total % 60;
    if h > 0 {
        format!("{}h {}m {}s", h, m, s)
    } else if m > 0 {
        format!("{}m {}s", m, s)
    } else {
        format!("{}s", s)
    }
}

fn format_ts(ts: u64) -> String {
    use chrono::{Local, TimeZone};
    match Local.timestamp_opt(ts as i64, 0) {
        chrono::LocalResult::Single(dt) => dt.format("%Y-%m-%d %H:%M").to_string(),
        _ => "—".to_string(),
    }
}

pub fn clear_tasks() -> anyhow::Result<usize> {
    let dir = task_dir();
    if !dir.exists() {
        return Ok(0);
    }
    let mut removed = 0;
    for entry in fs::read_dir(&dir)? {
        let entry = entry?;
        let path = entry.path();
        if let Err(e) = fs::remove_file(&path) {
            return Err(anyhow::anyhow!(
                "Could not remove background job file {}: {}",
                path.display(),
                e
            ));
        }
        removed += 1;
    }
    Ok(removed)
}

fn find_pm2() -> Option<PathBuf> {
    let path = std::env::var("PATH").ok()?;
    for dir in std::env::split_paths(&path) {
        let cand = dir.join("pm2");
        if cand.is_file() {
            return Some(cand);
        }
    }
    None
}

pub fn start_task(prompt: &str, cwd: &PathBuf, chat_id: &str, max_steps: u32) -> anyhow::Result<BackgroundTask> {
    let id = uuid::Uuid::new_v4().simple().to_string()[..10].to_string();
    let task = BackgroundTask {
        id: id.clone(),
        status: "queued".into(),
        prompt: prompt.to_string(),
        cwd: cwd.display().to_string(),
        chat_id: chat_id.to_string(),
        max_steps,
        created_at: now_ts(),
        started_at: None,
        finished_at: None,
        duration_seconds: None,
        returncode: None,
        pid: None,
        error: None,
        pm2_name: None,
    };
    save_task(&task)?;

    // Try PM2 first (matches the Python source); fall back to detached spawn.
    if let Some(pm2) = find_pm2() {
        let pm2_name = format!("biro-job-{}", id);
        let log_path = task_dir().join(format!("{}.log", id));
        let exe = std::env::current_exe()?;
        let exe_arg = exe.display().to_string();
        let cwd_arg = cwd.display().to_string();
        let log_arg = log_path.display().to_string();
        let pm2_args = vec![
            "start".to_string(),
            exe_arg,
            "--name".to_string(),
            pm2_name.clone(),
            "--interpreter".to_string(),
            "none".to_string(),
            "--cwd".to_string(),
            cwd_arg,
            "--no-autorestart".to_string(),
            "--log".to_string(),
            log_arg,
            "--".to_string(),
            "background-worker".to_string(),
            id.clone(),
        ];
        let status = Command::new(&pm2).args(&pm2_args).output();
        if let Ok(out) = status {
            if out.status.success() {
                let mut t = task.clone();
                t.pm2_name = Some(pm2_name);
                t.status = "queued".into();
                save_task(&t)?;
                return Ok(t);
            }
        }
        // PM2 failed — fall through to detached spawn.
    }

    // Detached fallback.
    let exe = std::env::current_exe()?;
    let log_path = task_dir().join(format!("{}.log", id));
    let log_file = fs::OpenOptions::new()
        .create(true)
        .append(true)
        .open(&log_path)?;
    let log_file2 = log_file.try_clone()?;
    let mut cmd = Command::new(&exe);
    cmd.arg("background-worker")
        .arg(&id)
        .current_dir(cwd)
        .stdin(Stdio::null())
        .stdout(Stdio::from(log_file))
        .stderr(Stdio::from(log_file2));
    #[cfg(unix)]
    {
        use std::os::unix::process::CommandExt;
        cmd.process_group(0);
    }
    let child = cmd
        .spawn()
        .map_err(|e| anyhow::anyhow!("Could not start background worker: {}", e))?;
    let mut t = task.clone();
    t.pid = Some(child.id());
    t.status = "queued".into();
    save_task(&t)?;
    Ok(t)
}

pub fn run_worker(id: &str) -> i32 {
    let Some(mut task) = read_task(id) else {
        return 1;
    };
    task.status = "running".into();
    task.started_at = Some(now_ts());
    let _ = save_task(&task);

    let start = std::time::Instant::now();
    let mut returncode = 1;
    let mut error_msg: Option<String> = None;

    let result: anyhow::Result<i32> = (|| {
        use crate::agent::runner::Agent;
        use crate::api::client::BiroApi;
        use crate::config::UserConfig;
        use std::sync::{atomic::AtomicBool, Arc};

        let mut config = UserConfig::load()?;
        config.current_chat_id = task.chat_id.clone();
        let api = BiroApi::new(config);
        let cwd = PathBuf::from(&task.cwd);
        let mut agent = Agent::new(
            api,
            cwd,
            true,
            task.max_steps,
            true,
            Arc::new(AtomicBool::new(false)),
        );
        Ok(agent.send(&task.prompt, Vec::new()))
    })();

    match result {
        Ok(code) => returncode = code,
        Err(e) => error_msg = Some(format!("{}", e)),
    }

    let mut t = read_task(id).unwrap_or(task);
    t.status = if returncode == 0 { "complete".into() } else { "failed".into() };
    t.returncode = Some(returncode);
    t.finished_at = Some(now_ts());
    t.duration_seconds = Some(start.elapsed().as_secs_f64());
    if let Some(err) = error_msg {
        t.error = Some(err);
    }
    let _ = save_task(&t);
    returncode
}

// Helper for the background worker subcommand - called from main.
pub fn run_worker_command(args: &[String]) -> Option<i32> {
    if args.first().map(|s| s.as_str()) == Some("background-worker") {
        if let Some(id) = args.get(1) {
            return Some(run_worker(id));
        }
    }
    None
}

// Silence unused warning for Value import
#[allow(dead_code)]
fn _typecheck() {
    let _: Option<Value> = None;
}
