use std::io::{BufRead, Write};
use std::path::{Path, PathBuf};
use std::sync::{
    atomic::{AtomicBool, Ordering},
    Arc,
};

use clap::{Parser, Subcommand};
use serde_json::{json, Value};

use crate::agent::runner::Agent;
use crate::api::client::{ApiError, BiroApi};
use crate::background;
use crate::config::{config_dir, validate_model, UserConfig};
use crate::ui::auth;
use crate::ui::diff::print_file_diff;

#[derive(Parser, Debug)]
#[command(name = "biro", version = "1.2.1", about = "BIRO interactive coding agent")]
pub struct Args {
    #[arg(short = 'p', long = "prompt")]
    pub prompt: Option<String>,
    #[arg(short = 'm', long = "model")]
    pub model: Option<String>,
    #[arg(long = "api-url")]
    pub api_url: Option<String>,
    #[arg(long = "think")]
    pub think: bool,
    #[arg(long = "yes", hide = true)]
    pub yes: bool,
    #[arg(long = "confirm", hide = true)]
    pub confirm: bool,
    #[arg(long = "max-steps", default_value_t = 0, hide = true)]
    pub max_steps: u32,
    #[arg(long = "background")]
    pub background: bool,
    #[command(subcommand)]
    pub auth_command: Option<AuthCommand>,
}

#[derive(Subcommand, Debug)]
pub enum AuthCommand {
    Login,
    Signup,
    Logout,
    Chat { chat_id: String },
    Jobs { action: Option<String> },
}

impl Args {
    pub fn parse_args() -> Self {
        Self::parse()
    }
}

// ---------- banner / help ----------

pub fn print_banner(config: &UserConfig) {
    let cwd = std::env::current_dir().unwrap_or_else(|_| PathBuf::from("."));
    let workspace = display_path(&cwd);
    println!();
    println!("\x1b[1;32m██████████████\x1b[0m  \x1b[1;97mBIRO\x1b[0m \x1b[2mCLI\x1b[0m");
    println!("\x1b[1;34m████████████\x1b[0m    \x1b[2mv{}\x1b[0m", env!("CARGO_PKG_VERSION"));
    println!(
        "\x1b[1;33m█████████  ●\x1b[0m    \x1b[1;32m{}\x1b[0m",
        workspace
    );
    println!();
    let _ = config;
}

fn display_path(p: &Path) -> String {
    if let Some(home) = dirs::home_dir() {
        if let Ok(rel) = p.strip_prefix(&home) {
            return format!("~/{}", rel.display());
        }
    }
    p.display().to_string()
}

pub fn print_help() {
    println!("\x1b[1;32mBIRO · HELP\x1b[0m");
    println!();
    println!("Chat");
    println!("  /              show live command suggestions");
    println!("  /id            show this chat ID and the command to resume it");
    println!("  /status        show model, workspace, chat, and activity");
    println!("  /chats         list saved chats and IDs");
    println!("  /open <n|id>   switch to a saved chat (alias /resume)");
    println!("  /history       read this chat");
    println!("  /retry         send the previous user prompt again");
    println!("  /rename <t>    rename the current chat");
    println!("  /new           start a new saved chat");
    println!("  /clear         clear the terminal display");
    println!("  /jobs          see background task status");
    println!();
    println!("Workspace");
    println!("  /cwd [dir]     show or change the working folder");
    println!("  /file <path>   attach a local file");
    println!("  /image <path>  attach a local image");
    println!("  /paste         enter a multiline prompt; finish with a dot");
    println!();
    println!("Integrations");
    println!("  /connect github|huggingface");
    println!("  /integrations  show provider connection status");
    println!("  /github <args> run a GitHub CLI command");
    println!("  /huggingface <args> run a Hugging Face CLI command");
    println!();
    println!("Account & controls");
    println!("  /model [max|mini]");
    println!("  /think         toggle the thinking indicator");
    println!("  /account       show the signed-in account");
    println!("  /login /signup /logout");
    println!("  /exit          quit BIRO");
}

pub fn print_session_exit_banner(agent: &Agent) {
    let token_note = if agent.session_token_count_approximate {
        format!("approximately {}", agent.session_token_count)
    } else {
        format!("{}", agent.session_token_count)
    };
    let workspace = display_path(&std::env::current_dir().unwrap_or_else(|_| PathBuf::from(".")));
    if atty::is(atty::Stream::Stdout) {
        print!("\x1b[2J\x1b[H");
    }
    println!();
    println!("\x1b[1;32m██████████████\x1b[0m  \x1b[1;97mBIRO\x1b[0m");
    println!("\x1b[1;34m████████████\x1b[0m    \x1b[2mSESSION ENDED\x1b[0m");
    println!("\x1b[1;33m█████████  ●\x1b[0m    \x1b[1;32m{}\x1b[0m", workspace);
    println!();
    println!("\x1b[1;32mMODEL\x1b[0m  {}", agent.model_label());
    println!("\x1b[1;32mTOKENS\x1b[0m  {}", token_note);
    println!(
        "\x1b[1;32mCODE DIFF\x1b[0m  \x1b[32m+{}\x1b[0m  \x1b[33m-{}\x1b[0m lines",
        agent.session_lines_added, agent.session_lines_deleted
    );
    if !agent.api.config.current_chat_id.is_empty() {
        println!(
            "\x1b[1;32mRESUME\x1b[0m  biro chat {}",
            agent.api.config.current_chat_id
        );
    }
    println!();
}

// ---------- slash command parsing ----------

pub fn parse_slash_command(line: &str) -> Option<(String, String)> {
    let stripped = line.trim();
    if !stripped.starts_with('/') {
        return None;
    }
    let rest = &stripped[1..];
    let mut parts = rest.splitn(2, char::is_whitespace);
    let head = parts.next().unwrap_or("").trim();
    if head.is_empty() {
        return None;
    }
    let tail = parts.next().unwrap_or("").trim().to_string();
    Some((head.to_lowercase(), tail))
}

// ---------- auth command dispatch ----------

pub fn run_app(args: Args, interrupt: Arc<AtomicBool>) -> anyhow::Result<i32> {
    let mut config = UserConfig::load()?;
    if let Some(url) = &args.api_url {
        config.api_url = url.trim_end_matches('/').to_string();
        config.save()?;
    }
    if let Some(m) = &args.model {
        match validate_model(m) {
            Ok(v) => {
                config.model = v;
                config.save()?;
            }
            Err(e) => {
                eprintln!("\x1b[31m{}\x1b[0m", e);
                return Ok(2);
            }
        }
    }

    let mut api = BiroApi::new(config.clone());

    if let Some(cmd) = &args.auth_command {
        match cmd {
            AuthCommand::Jobs { action } => {
                if action.as_deref() == Some("clear") {
                    let n = background::clear_tasks()?;
                    println!("Cleared background jobs and logs ({} local files removed).", n);
                } else {
                    background::show_background_tasks();
                }
                return Ok(0);
            }
            AuthCommand::Logout => {
                let mut cfg = api.config.clone();
                cfg.clear_session()?;
                api.config = cfg;
                println!("Signed out from this device. Your server-side conversations remain stored.");
                return Ok(0);
            }
            AuthCommand::Login => {
                let ok = auth::login_flow(&mut api)?;
                return Ok(if ok { 0 } else { 1 });
            }
            AuthCommand::Signup => {
                let ok = auth::signup_flow(&mut api)?;
                return Ok(if ok { 0 } else { 1 });
            }
            _ => {}
        }
    }

    // Authenticate
    if !auth::authenticate(&mut api)? {
        return Ok(1);
    }

    // Handle "biro chat <id>" resume
    let resuming = matches!(&args.auth_command, Some(AuthCommand::Chat { .. }));
    if let Some(AuthCommand::Chat { chat_id }) = &args.auth_command {
        if !open_chat(&mut api, chat_id, true)? {
            return Ok(1);
        }
    } else if !args.background && !resuming {
        ensure_current_chat(&mut api)?;
    }

    if atty::is(atty::Stream::Stdout) {
        print!("\x1b[2J\x1b[H");
    }
    print_banner(&api.config);

    if resuming {
        if let Some(AuthCommand::Chat { chat_id }) = &args.auth_command {
            let _ = show_history(&api, chat_id);
        }
    }

    if args.background {
        let prompt = args.prompt.as_deref().ok_or_else(|| {
            anyhow::anyhow!("--background requires -p/--prompt")
        })?;
        let chat = api.create_chat("Background task", false)?;
        let chat_id = chat
            .get("id")
            .and_then(|v| v.as_str())
            .unwrap_or("")
            .to_string();
        let cwd = std::env::current_dir()?;
        let task = background::start_task(prompt, &cwd, &chat_id, args.max_steps)?;
        println!(
            "\x1b[1;32mBackground task started\x1b[0m  task {}  chat {}",
            task.id, chat_id
        );
        println!(
            "\x1b[2mCheck it with biro jobs. Resume the chat with biro chat {}.\x1b[0m",
            chat_id
        );
        return Ok(0);
    }

    if let Some(prompt) = &args.prompt {
        let cwd = std::env::current_dir()?;
        let mut agent = Agent::new(api, cwd, args.think, args.max_steps, false, interrupt);
        let code = agent.send(prompt, Vec::new());
        return Ok(code);
    }

    let cwd = std::env::current_dir()?;
    let mut agent = Agent::new(api, cwd, args.think, args.max_steps, false, interrupt);
    if let Ok(msgs) = agent.api.list_messages(&agent.api.config.current_chat_id) {
        agent.message_count = msgs.len();
    }
    interactive_loop(&mut agent)
}

// ---------- chat helpers ----------

pub fn ensure_current_chat(api: &mut BiroApi) -> anyhow::Result<()> {
    if !api.config.current_chat_id.is_empty() {
        match api.get_chat(&api.config.current_chat_id.clone()) {
            Ok(_) => return Ok(()),
            Err(e) => {
                if !matches!(e_status(&e), Some(404) | Some(401)) {
                    return Err(anyhow::anyhow!("{}", e));
                }
                api.config.current_chat_id.clear();
                api.config.save()?;
            }
        }
    }
    let chat = api.create_chat("New conversation", true)?;
    let _ = chat;
    Ok(())
}

pub fn open_chat(api: &mut BiroApi, target: &str, direct_id: bool) -> anyhow::Result<bool> {
    let target = target.trim();
    if target.is_empty() {
        println!("Usage: /open <number-or-id>");
        return Ok(false);
    }
    let chosen: Option<Value> = if direct_id {
        api.get_chat(target).ok()
    } else if let Ok(n) = target.parse::<usize>() {
        let chats = api.list_chats().unwrap_or_default();
        if n >= 1 && n <= chats.len() {
            Some(chats[n - 1].clone())
        } else {
            None
        }
    } else {
        api.get_chat(target).ok()
    };
    let Some(chosen) = chosen else {
        println!("\x1b[31mChat not found. Use /chats to see saved chat IDs.\x1b[0m");
        return Ok(false);
    };
    let id = chosen.get("id").and_then(|v| v.as_str()).unwrap_or("");
    api.config.current_chat_id = id.to_string();
    api.config.save()?;
    println!(
        "\x1b[1;32mOpened\x1b[0m {}  \x1b[2m{}\x1b[0m",
        chosen.get("title").and_then(|v| v.as_str()).unwrap_or("New conversation"),
        id
    );
    Ok(true)
}

fn e_status(e: &ApiError) -> Option<u16> {
    match e {
        ApiError::Http(_, s) => Some(*s),
        _ => None,
    }
}

pub fn list_chats(api: &BiroApi) {
    let chats = match api.list_chats() {
        Ok(c) => c,
        Err(e) => {
            println!("\x1b[31mBIRO API error: {}\x1b[0m", e);
            return;
        }
    };
    if chats.is_empty() {
        println!("\x1b[2mNo saved conversations yet.\x1b[0m");
        return;
    }
    println!("{:<4} {:<40} {:<16} {:<16} {}", "#", "Title", "Chat ID", "Updated", "Current");
    for (i, c) in chats.iter().enumerate() {
        let title = c.get("title").and_then(|v| v.as_str()).unwrap_or("New conversation");
        let id = c.get("id").and_then(|v| v.as_str()).unwrap_or("");
        let updated = c.get("updated_at").and_then(|v| v.as_str()).unwrap_or("");
        let cur = if id == api.config.current_chat_id { "●" } else { "" };
        println!(
            "{:<4} {:<40} {:<16} {:<16} {}",
            i + 1,
            truncate(title, 40),
            id,
            truncate(updated, 16),
            cur
        );
    }
    println!("\x1b[2mResume from another terminal with: biro chat <chat_id>\x1b[0m");
}

pub fn show_history(api: &BiroApi, chat_id: &str) -> anyhow::Result<()> {
    let messages = api.list_messages(chat_id)?;
    if messages.is_empty() {
        println!("\x1b[2mThis conversation has no messages yet.\x1b[0m");
        return Ok(());
    }
    for m in messages {
        let role = m.get("role").and_then(|v| v.as_str()).unwrap_or("message");
        let content = m.get("content").and_then(|v| v.as_str()).unwrap_or("");
        let who = if role == "user" { "you" } else { "BIRO" };
        if role == "user" {
            println!("\n\x1b[1;33m{}\x1b[0m", who);
        } else {
            println!("\n\x1b[1m{}\x1b[0m", who);
        }
        println!("{}", content);
    }
    Ok(())
}

fn truncate(s: &str, n: usize) -> String {
    if s.chars().count() <= n {
        s.to_string()
    } else {
        s.chars().take(n).collect()
    }
}

// ---------- provider CLI helpers ----------

fn provider_binary(name: &str) -> Option<String> {
    if let Ok(path) = std::env::var("PATH") {
        for dir in std::env::split_paths(&path) {
            let candidate = dir.join(name);
            if candidate.is_file() {
                return Some(candidate.display().to_string());
            }
            if cfg!(windows) {
                let candidate = dir.join(format!("{}.exe", name));
                if candidate.is_file() {
                    return Some(candidate.display().to_string());
                }
            }
        }
    }
    None
}

pub fn run_provider_cli(executable: &str, args: &[String], cwd: &Path) -> i32 {
    match provider_binary(executable) {
        None => {
            if executable == "gh" {
                println!("\x1b[33mGitHub CLI (`gh`) is not installed. Install GitHub CLI, then run `/connect github`.\x1b[0m");
            } else {
                println!("\x1b[33mHugging Face CLI (`hf`) is not installed. Install it with `pip install -U huggingface_hub`, then run `/connect huggingface`.\x1b[0m");
            }
            127
        }
        Some(bin) => {
            let mut cmd = std::process::Command::new(&bin);
            cmd.args(args).current_dir(cwd);
            match cmd.status() {
                Ok(status) => status.code().unwrap_or(1),
                Err(e) => {
                    println!("\x1b[31mCould not launch {}: {}\x1b[0m", executable, e);
                    1
                }
            }
        }
    }
}

pub fn integration_status(cwd: &Path) {
    println!("{:<16} {:<24}", "Provider", "Status");
    for (name, bin, args) in [
        ("GitHub", "gh", vec!["auth", "status"]),
        ("Hugging Face", "hf", vec!["auth", "whoami"]),
    ] {
        let status = if provider_binary(bin).is_none() {
            "CLI not installed".to_string()
        } else {
            let bin_path = provider_binary(bin).unwrap();
            let mut cmd = std::process::Command::new(&bin_path);
            cmd.args(&args).current_dir(cwd);
            match cmd.output() {
                Ok(out) => {
                    if out.status.success() {
                        "Connected".to_string()
                    } else {
                        "Not signed in".to_string()
                    }
                }
                Err(_) => "Unable to check".to_string(),
            }
        };
        let color = if status == "Connected" { "32" } else { "33" };
        println!("{:<16} \x1b[{}m{}\x1b[0m", name, color, status);
    }
    println!("\x1b[2mUse /connect github or /connect huggingface to sign in. Tokens are not copied into BIRO config.\x1b[0m");
}

// ---------- model selection ----------

pub fn select_model(api: &mut BiroApi, requested: Option<&str>) -> anyhow::Result<bool> {
    let chosen = match requested {
        Some(s) if !s.is_empty() => match validate_model(s) {
            Ok(v) => v,
            Err(e) => {
                println!("\x1b[31m{}\x1b[0m", e);
                return Ok(false);
            }
        },
        _ => {
            println!("BIRO Models");
            println!("  1 / max   BIRO Max · 500B parameters  Complex coding, planning, deeper reasoning");
            println!("  2 / mini  BIRO Mini                    Fast everyday work and smaller tasks");
            print!("Choose [1/2, max/mini] (Enter keeps current): ");
            let _ = std::io::stdout().flush();
            let mut line = String::new();
            if std::io::stdin().read_line(&mut line).is_err() {
                return Ok(false);
            }
            let trimmed = line.trim();
            if trimmed.is_empty() {
                return Ok(true);
            }
            let mapped = match trimmed {
                "1" => "biro-max",
                "2" => "biro-mini",
                other => other,
            };
            match validate_model(mapped) {
                Ok(v) => v,
                Err(e) => {
                    println!("\x1b[31m{}\x1b[0m", e);
                    return Ok(false);
                }
            }
        }
    };
    match api.models(&chosen) {
        Ok(result) => {
            if !result.get("configured").and_then(|v| v.as_bool()).unwrap_or(true) {
                println!("\x1b[33mThis model is listed, but the backend currently reports that inference is not configured.\x1b[0m");
            }
        }
        Err(e) => {
            let s = e_status(&e);
            if !matches!(s, Some(404) | Some(405)) {
                println!("\x1b[33mCouldn't verify model availability right now: {}\x1b[0m", e);
            }
        }
    }
    api.config.model = chosen;
    api.config.save()?;
    println!(
        "\x1b[32mSelected {}.\x1b[0m",
        if api.config.model == "biro-max" { "BIRO Max" } else { "BIRO Mini" }
    );
    Ok(true)
}

// ---------- attachments ----------

pub fn attachment_for_path(agent: &Agent, raw_path: &str, image_only: bool) -> Result<Value, String> {
    use base64::Engine;
    let cleaned = raw_path.trim().trim_matches('"').trim_matches('\'');
    let path = agent.tools.resolve_path(cleaned)?;
    if !path.is_file() {
        return Err(format!("No such regular file: {}", raw_path));
    }
    let size = std::fs::metadata(&path).map_err(|e| e.to_string())?.len();
    if size == 0 {
        return Err("Empty files cannot be attached.".into());
    }
    if size > 10_000_000 {
        return Err("BIRO currently accepts files up to 10 MB each.".into());
    }
    let mime = mime_guess::from_path(&path)
        .first_or_octet_stream()
        .essence_str()
        .to_string();
    if image_only && !mime.starts_with("image/") {
        return Err("/image expects an image file such as .png, .jpg, .jpeg, or .webp.".into());
    }
    let raw = std::fs::read(&path).map_err(|e| e.to_string())?;
    let encoded = base64::engine::general_purpose::STANDARD.encode(&raw);
    let filename = path
        .file_name()
        .and_then(|s| s.to_str())
        .unwrap_or("attachment")
        .to_string();
    Ok(json!({
        "filename": filename,
        "mime_type": mime,
        "data_base64": encoded,
        "vision_frames": [],
    }))
}

fn multiline_prompt() -> String {
    println!("\x1b[2mPaste/type your request. Enter a single dot (`.`) on its own line to send; Ctrl+C cancels.\x1b[0m");
    let stdin = std::io::stdin();
    let mut lines = Vec::new();
    loop {
        print!("… ");
        let _ = std::io::stdout().flush();
        let mut buf = String::new();
        match stdin.lock().read_line(&mut buf) {
            Ok(0) => break,
            Ok(_) => {
                let trimmed = buf.trim_end_matches(['\r', '\n']);
                if trimmed == "." {
                    break;
                }
                lines.push(trimmed.to_string());
            }
            Err(_) => break,
        }
    }
    lines.join("\n")
}

fn retry_last(agent: &mut Agent) {
    let chat_id = agent.api.config.current_chat_id.clone();
    let messages = match agent.api.list_messages(&chat_id) {
        Ok(m) => m,
        Err(e) => {
            println!("\x1b[31mBIRO API error: {}\x1b[0m", e);
            return;
        }
    };
    let previous = messages.iter().rev().find_map(|m| {
        if m.get("role").and_then(|v| v.as_str()) != Some("user") {
            return None;
        }
        let content = m.get("content").and_then(|v| v.as_str()).unwrap_or("");
        if content.trim().is_empty() {
            return None;
        }
        if content.starts_with("[Local tool result:") || content.starts_with("ACTION_PROTOCOL_REPAIR:") {
            return None;
        }
        Some(content.to_string())
    });
    match previous {
        None => println!("\x1b[2mNo previous user prompt is available to retry.\x1b[0m"),
        Some(text) => {
            println!("\x1b[2mRetrying the previous user prompt…\x1b[0m");
            agent.send(&text, Vec::new());
        }
    }
}

// ---------- interactive REPL ----------

fn interactive_loop(agent: &mut Agent) -> anyhow::Result<i32> {
    let mut rl = rustyline::DefaultEditor::new()?;
    let history_path = config_dir().join("prompt_history");
    if history_path.exists() {
        let _ = rl.load_history(&history_path);
    }

    loop {
        agent.interrupt.store(false, Ordering::SeqCst);
        let prompt = format!(
            "\x1b[1;32m[{}]\x1b[0m \x1b[1;33m{}\x1b[0m › ",
            agent.model_label(),
            agent.tools
                .cwd
                .file_name()
                .and_then(|s| s.to_str())
                .unwrap_or("workspace")
                .to_uppercase()
        );
        match rl.readline(&prompt) {
            Ok(line) => {
                let _ = rl.add_history_entry(&line);
                if line.trim().is_empty() {
                    continue;
                }
                if !line.starts_with('/') {
                    agent.send(&line, Vec::new());
                    continue;
                }
                let Some((command, arg)) = parse_slash_command(&line) else {
                    println!("\x1b[2mNo command selected. Type `/` to browse commands or `/help` for the list.\x1b[0m");
                    continue;
                };
                match command.as_str() {
                    "exit" | "quit" => {
                        print_session_exit_banner(agent);
                        break;
                    }
                    "help" => print_help(),
                    "id" | "chat" => {
                        let id = &agent.api.config.current_chat_id;
                        println!("Chat ID: {}\nResume with: biro chat {}", id, id);
                    }
                    "status" => {
                        println!(
                            "Model: {}\nWorkspace: {}\nChat ID: {}\nMessages: {}",
                            agent.model_label(),
                            agent.tools.cwd.display(),
                            agent.api.config.current_chat_id,
                            agent.message_count
                        );
                    }
                    "jobs" => background::show_background_tasks(),
                    "new" => {
                        match agent.api.create_chat("New conversation", true) {
                            Ok(chat) => {
                                agent.message_count = 0;
                                agent.last_elapsed = 0.0;
                                println!(
                                    "\x1b[32mNew conversation started.\x1b[0m \x1b[2m{}\x1b[0m",
                                    chat.get("id").and_then(|v| v.as_str()).unwrap_or("")
                                );
                            }
                            Err(e) => println!("\x1b[31mBIRO API error: {}\x1b[0m", e),
                        }
                    }
                    "clear" => {
                        if atty::is(atty::Stream::Stdout) {
                            print!("\x1b[2J\x1b[H");
                        }
                        print_banner(&agent.api.config);
                    }
                    "chats" => list_chats(&agent.api),
                    "open" | "resume" => {
                        if let Ok(true) = open_chat(&mut agent.api, &arg, false) {
                            if let Ok(msgs) = agent.api.list_messages(&agent.api.config.current_chat_id) {
                                agent.message_count = msgs.len();
                            }
                            agent.last_elapsed = 0.0;
                            let _ = show_history(&agent.api, &agent.api.config.current_chat_id.clone());
                        }
                    }
                    "history" => {
                        let _ = show_history(&agent.api, &agent.api.config.current_chat_id.clone());
                    }
                    "retry" => retry_last(agent),
                    "rename" => {
                        if arg.is_empty() {
                            println!("Usage: /rename <chat title>");
                        } else {
                            let cid = agent.api.config.current_chat_id.clone();
                            match agent.api.update_chat(&cid, &arg) {
                                Ok(v) => println!(
                                    "\x1b[1;32mRenamed\x1b[0m {}",
                                    v.get("title").and_then(|x| x.as_str()).unwrap_or(&arg)
                                ),
                                Err(e) => println!("\x1b[31mBIRO API error: {}\x1b[0m", e),
                            }
                        }
                    }
                    "model" | "models" => {
                        let _ = select_model(&mut agent.api, Some(arg.as_str()).filter(|s| !s.is_empty()));
                    }
                    "think" => {
                        agent.think = !agent.think;
                        println!(
                            "Thinking title: {}\n\x1b[2mOnly a short task/step title is shown; private reasoning text is hidden.\x1b[0m",
                            if agent.think { "ON" } else { "OFF" }
                        );
                    }
                    "connect" => {
                        let provider = arg.trim().to_lowercase();
                        match provider.as_str() {
                            "github" | "gh" => {
                                run_provider_cli("gh", &["auth".into(), "login".into()], &agent.tools.cwd);
                            }
                            "huggingface" | "hf" | "hugging-face" => {
                                run_provider_cli("hf", &["auth".into(), "login".into()], &agent.tools.cwd);
                            }
                            _ => println!("Usage: /connect github  or  /connect huggingface"),
                        }
                    }
                    "integrations" => integration_status(&agent.tools.cwd),
                    "github" => {
                        let args_vec: Vec<String> = if arg.is_empty() {
                            vec!["auth".into(), "status".into()]
                        } else {
                            arg.split_whitespace().map(|s| s.to_string()).collect()
                        };
                        run_provider_cli("gh", &args_vec, &agent.tools.cwd);
                    }
                    "huggingface" | "hf" => {
                        let args_vec: Vec<String> = if arg.is_empty() {
                            vec!["auth".into(), "whoami".into()]
                        } else {
                            arg.split_whitespace().map(|s| s.to_string()).collect()
                        };
                        run_provider_cli("hf", &args_vec, &agent.tools.cwd);
                    }
                    "paste" => {
                        let prompt = multiline_prompt();
                        if !prompt.trim().is_empty() {
                            agent.send(&prompt, Vec::new());
                        }
                    }
                    "file" | "image" => {
                        if arg.trim().is_empty() {
                            println!("Usage: /{} <local file path>", command);
                        } else {
                            match attachment_for_path(agent, &arg, command == "image") {
                                Ok(att) => {
                                    let filename = att.get("filename").and_then(|v| v.as_str()).unwrap_or("file");
                                    let prompt = format!(
                                        "Please inspect the attached {}: {}. Use it as context for this conversation.",
                                        if command == "image" { "image" } else { "file" },
                                        filename
                                    );
                                    println!("\x1b[1;32mAttaching {}\x1b[0m", filename);
                                    agent.send(&prompt, vec![att]);
                                }
                                Err(e) => println!("\x1b[31mError: {}\x1b[0m", e),
                            }
                        }
                    }
                    "cwd" => {
                        if arg.is_empty() {
                            println!("Workspace: {}", agent.tools.cwd.display());
                        } else {
                            match agent.tools.change_cwd(&arg) {
                                Ok(new) => {
                                    agent.cwd = new.clone();
                                    println!("\x1b[32mWorkspace changed:\x1b[0m {}", new.display());
                                }
                                Err(e) => println!("\x1b[31mError: {}\x1b[0m", e),
                            }
                        }
                    }
                    "account" => match agent.api.me() {
                        Ok(user) => {
                            println!(
                                "{} <{}>\nAccount ID: {}",
                                user.get("display_name").and_then(|v| v.as_str()).unwrap_or(""),
                                user.get("email").and_then(|v| v.as_str()).unwrap_or(""),
                                user.get("id").and_then(|v| v.as_str()).unwrap_or("—")
                            );
                        }
                        Err(e) => println!("\x1b[31mBIRO API error: {}\x1b[0m", e),
                    },
                    "login" => {
                        if let Ok(true) = auth::login_flow(&mut agent.api) {
                            let _ = ensure_current_chat(&mut agent.api);
                            println!("\x1b[32mAccount switched.\x1b[0m");
                        }
                    }
                    "signup" => {
                        if let Ok(true) = auth::signup_flow(&mut agent.api) {
                            let _ = ensure_current_chat(&mut agent.api);
                        }
                    }
                    "logout" => {
                        let mut cfg = agent.api.config.clone();
                        let _ = cfg.clear_session();
                        agent.api.config = cfg;
                        println!("\x1b[32mSigned out. Server-side chats remain stored.\x1b[0m");
                        if auth::authenticate(&mut agent.api)? {
                            let _ = ensure_current_chat(&mut agent.api);
                        } else {
                            return Ok(0);
                        }
                    }
                    other => println!("\x1b[31mUnknown command:\x1b[0m /{}. Type /help.", other),
                }
            }
            Err(rustyline::error::ReadlineError::Interrupted)
            | Err(rustyline::error::ReadlineError::Eof) => {
                print_session_exit_banner(agent);
                break;
            }
            Err(e) => {
                eprintln!("\x1b[31mReadline error:\x1b[0m {}", e);
                return Ok(1);
            }
        }
    }
    let _ = rl.save_history(&history_path);
    Ok(0)
}

// silence unused warnings for helper functions used only in some paths
#[allow(dead_code)]
fn _unused(_: &Path) {
    let _ = print_file_diff;
    let _ = PathBuf::new();
}
