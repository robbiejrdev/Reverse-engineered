use std::io::{BufRead, BufReader};
use std::time::Duration;

use base64::Engine;
use reqwest::blocking::{Client, Response};
use serde_json::{json, Value};

use crate::config::UserConfig;

#[derive(Debug, thiserror::Error)]
pub enum ApiError {
    #[error("{0}")]
    Message(String),
    #[error("{0} (HTTP {1})")]
    Http(String, u16),
}

pub type ApiResult<T> = Result<T, ApiError>;

fn detail_of(resp: Response) -> (String, u16) {
    let status = resp.status().as_u16();
    let text = match resp.json::<Value>() {
        Ok(v) => {
            if let Some(d) = v.get("detail") {
                if let Some(s) = d.as_str() {
                    s.to_string()
                } else if let Some(arr) = d.as_array() {
                    arr.iter()
                        .map(|x| {
                            x.get("msg")
                                .and_then(|m| m.as_str())
                                .map(|s| s.to_string())
                                .unwrap_or_else(|| x.to_string())
                        })
                        .collect::<Vec<_>>()
                        .join("; ")
                } else {
                    format!("Request failed (HTTP {})", status)
                }
            } else {
                format!("Request failed (HTTP {})", status)
            }
        }
        Err(_) => format!("Request failed (HTTP {})", status),
    };
    (text, status)
}

pub struct BiroApi {
    pub config: UserConfig,
    http: Client,
}

impl BiroApi {
    pub fn new(config: UserConfig) -> Self {
        let http = Client::builder()
            .timeout(None)
            .connect_timeout(Duration::from_secs(15))
            .user_agent("BIRO-Rust/1.0")
            .build()
            .expect("Failed to build HTTP client");
        Self { config, http }
    }

    fn url(&self, path: &str) -> String {
        format!(
            "{}/{}",
            self.config.api_url.trim_end_matches('/'),
            path.trim_start_matches('/')
        )
    }

    fn apply_auth(&self, req: reqwest::blocking::RequestBuilder) -> reqwest::blocking::RequestBuilder {
        if !self.config.access_token.is_empty() {
            req.header("Authorization", format!("Bearer {}", self.config.access_token))
        } else {
            req
        }
    }

    fn json_or_err(resp: Response) -> ApiResult<Value> {
        if !resp.status().is_success() {
            let (msg, status) = detail_of(resp);
            if status == 401 {
                return Err(ApiError::Http(
                    "Your BIRO session is invalid or expired. Run `/login` to sign in again.".into(),
                    401,
                ));
            }
            return Err(ApiError::Http(msg, status));
        }
        resp.json::<Value>()
            .map_err(|e| ApiError::Message(format!("Invalid JSON response: {}", e)))
    }

    pub fn signup(&mut self, display_name: &str, email: &str, password: &str) -> ApiResult<Value> {
        let body = json!({"display_name": display_name, "email": email, "password": password});
        let resp = self
            .http
            .post(self.url("/api/v1/auth/signup"))
            .json(&body)
            .send()
            .map_err(|e| ApiError::Message(format!("Connection failed: {}", e)))?;
        self.accept_session(resp)
    }

    pub fn login(&mut self, email: &str, password: &str) -> ApiResult<Value> {
        let body = json!({"email": email, "password": password});
        let resp = self
            .http
            .post(self.url("/api/v1/auth/login"))
            .json(&body)
            .send()
            .map_err(|e| ApiError::Message(format!("Connection failed: {}", e)))?;
        self.accept_session(resp)
    }

    fn accept_session(&mut self, resp: Response) -> ApiResult<Value> {
        let v = Self::json_or_err(resp)?;
        let token = v
            .get("access_token")
            .and_then(|x| x.as_str())
            .ok_or_else(|| ApiError::Message("The server returned an unexpected sign-in response.".into()))?
            .to_string();
        let user = v.get("user").cloned().unwrap_or_else(|| json!({}));
        if self.config.access_token != token {
            self.config.current_chat_id.clear();
        }
        self.config.access_token = token;
        self.config.email = user.get("email").and_then(|v| v.as_str()).unwrap_or("").to_string();
        self.config.display_name = user.get("display_name").and_then(|v| v.as_str()).unwrap_or("").to_string();
        self.config
            .save()
            .map_err(|e| ApiError::Message(format!("Failed to save config: {}", e)))?;
        Ok(v)
    }

    pub fn me(&self) -> ApiResult<Value> {
        let req = self.apply_auth(self.http.get(self.url("/api/v1/me")));
        Self::json_or_err(req.send().map_err(|e| ApiError::Message(format!("Connection failed: {}", e)))?)
    }

    pub fn models(&self, model: &str) -> ApiResult<Value> {
        let req = self.apply_auth(self.http.get(self.url(&format!("/api/v1/ai/models?provider={}", model))));
        Self::json_or_err(req.send().map_err(|e| ApiError::Message(format!("Connection failed: {}", e)))?)
    }

    pub fn list_chats(&self) -> ApiResult<Vec<Value>> {
        let req = self.apply_auth(self.http.get(self.url("/api/v1/chats")));
        let v = Self::json_or_err(req.send().map_err(|e| ApiError::Message(format!("Connection failed: {}", e)))?)?;
        Ok(v.as_array().cloned().unwrap_or_default())
    }

    pub fn get_chat(&self, chat_id: &str) -> ApiResult<Value> {
        let req = self.apply_auth(self.http.get(self.url(&format!("/api/v1/chats/{}", chat_id))));
        Self::json_or_err(req.send().map_err(|e| ApiError::Message(format!("Connection failed: {}", e)))?)
    }

    pub fn create_chat(&mut self, title: &str, select: bool) -> ApiResult<Value> {
        let body = json!({"title": title});
        let req = self.apply_auth(self.http.post(self.url("/api/v1/chats")).json(&body));
        let v = Self::json_or_err(req.send().map_err(|e| ApiError::Message(format!("Connection failed: {}", e)))?)?;
        if select {
            if let Some(id) = v.get("id").and_then(|x| x.as_str()) {
                self.config.current_chat_id = id.to_string();
                let _ = self.config.save();
            }
        }
        Ok(v)
    }

    pub fn update_chat(&self, chat_id: &str, title: &str) -> ApiResult<Value> {
        let body = json!({"title": title});
        let req = self.apply_auth(
            self.http
                .patch(self.url(&format!("/api/v1/chats/{}", chat_id)))
                .json(&body),
        );
        Self::json_or_err(req.send().map_err(|e| ApiError::Message(format!("Connection failed: {}", e)))?)
    }

    pub fn delete_chat(&mut self, chat_id: &str) -> ApiResult<()> {
        let req = self.apply_auth(self.http.delete(self.url(&format!("/api/v1/chats/{}", chat_id))));
        let resp = req.send().map_err(|e| ApiError::Message(format!("Connection failed: {}", e)))?;
        if !resp.status().is_success() {
            let (msg, status) = detail_of(resp);
            return Err(ApiError::Http(msg, status));
        }
        if self.config.current_chat_id == chat_id {
            self.config.current_chat_id.clear();
            let _ = self.config.save();
        }
        Ok(())
    }

    pub fn list_messages(&self, chat_id: &str) -> ApiResult<Vec<Value>> {
        let req = self.apply_auth(
            self.http
                .get(self.url(&format!("/api/v1/chats/{}/messages", chat_id))),
        );
        let v = Self::json_or_err(req.send().map_err(|e| ApiError::Message(format!("Connection failed: {}", e)))?)?;
        Ok(v.as_array().cloned().unwrap_or_default())
    }

    pub fn generate_image(&self, chat_id: &str, prompt: &str) -> ApiResult<Value> {
        let body = json!({"prompt": prompt});
        let req = self.apply_auth(
            self.http
                .post(self.url(&format!("/api/v1/chats/{}/images", chat_id)))
                .json(&body),
        );
        Self::json_or_err(req.send().map_err(|e| ApiError::Message(format!("Connection failed: {}", e)))?)
    }

    pub fn download_artifact(&self, chat_id: &str, artifact_id: &str) -> ApiResult<(Vec<u8>, String)> {
        let req = self.apply_auth(self.http.get(self.url(&format!(
            "/api/v1/chats/{}/artifacts/{}/download",
            chat_id, artifact_id
        ))));
        let resp = req.send().map_err(|e| ApiError::Message(format!("Connection failed: {}", e)))?;
        if !resp.status().is_success() {
            let (msg, status) = detail_of(resp);
            return Err(ApiError::Http(msg, status));
        }
        let mime = resp
            .headers()
            .get("content-type")
            .and_then(|v| v.to_str().ok())
            .unwrap_or("application/octet-stream")
            .split(';')
            .next()
            .unwrap_or("")
            .trim()
            .to_string();
        let bytes = resp
            .bytes()
            .map_err(|e| ApiError::Message(format!("Download failed: {}", e)))?
            .to_vec();
        Ok((bytes, mime))
    }

    pub fn build_prompt_payload(
        prompt: &str,
        model: &str,
        instructions: &str,
        attachments: &[Value],
    ) -> ApiResult<Value> {
        if attachments.len() > 4 {
            return Err(ApiError::Message(
                "Attach no more than four files to a single BIRO message.".into(),
            ));
        }
        if instructions.len() > 4000 {
            return Err(ApiError::Message(
                "The deployed BIRO backend accepts at most 4,000 instruction characters. The CLI will not silently truncate system instructions.".into(),
            ));
        }
        if prompt.len() <= 12_000 {
            let mut payload = json!({
                "message": prompt,
                "provider": model,
                "attachments": attachments,
            });
            if !instructions.is_empty() {
                payload["instructions"] = json!(instructions);
            }
            return Ok(payload);
        }

        // Chunk long prompts into up to four 80 000-char text attachments.
        let mut parts: Vec<String> = Vec::new();
        let mut current = String::new();
        for ch in prompt.chars() {
            current.push(ch);
            if current.len() >= 80_000 {
                parts.push(std::mem::take(&mut current));
            }
        }
        if !current.is_empty() {
            parts.push(current);
        }
        if parts.len() > 4 && attachments.is_empty() {
            return Err(ApiError::Message(
                "The current BIRO backend forwards at most 320,000 characters from long text attachments in one request. Split the prompt or expand the backend schema.".into(),
            ));
        }
        if parts.len() + attachments.len() > 4 {
            return Err(ApiError::Message(
                "The current BIRO backend accepts at most four attachments per message, including long-prompt parts. Shorten the prompt or attach fewer files.".into(),
            ));
        }

        let mut text_attachments: Vec<Value> = Vec::new();
        for (i, part) in parts.iter().enumerate() {
            let encoded = base64::engine::general_purpose::STANDARD.encode(part.as_bytes());
            text_attachments.push(json!({
                "filename": format!("prompt-part-{:02}.txt", i + 1),
                "mime_type": "text/plain",
                "data_base64": encoded,
                "text_content": part,
                "vision_frames": [],
            }));
        }
        let instruction = "The attached prompt-part files contain the user's full request, in numeric order. Read every part as one request before answering. Preserve requirements across all parts.";
        let mut all = attachments.to_vec();
        all.extend(text_attachments);
        let mut payload = json!({
            "message": instruction,
            "provider": model,
            "attachments": all,
        });
        if !instructions.is_empty() {
            payload["instructions"] = json!(instructions);
        }
        Ok(payload)
    }

    pub fn stream_message<F>(
        &self,
        chat_id: &str,
        payload: &Value,
        mut on_event: F,
    ) -> ApiResult<()>
    where
        F: FnMut(&Value) -> bool,
    {
        let req = self.apply_auth(
            self.http
                .post(self.url(&format!(
                    "/api/v1/chats/{}/messages/stream",
                    chat_id
                )))
                .header("Accept", "application/x-ndjson")
                .json(payload),
        );
        let resp = req
            .send()
            .map_err(|e| ApiError::Message(format!("Connection failed: {}", e)))?;
        if !resp.status().is_success() {
            let status = resp.status().as_u16();
            if status == 401 {
                return Err(ApiError::Http(
                    "Your BIRO session is invalid or expired. Run `/login` to sign in again.".into(),
                    401,
                ));
            }
            let (msg, status) = detail_of(resp);
            return Err(ApiError::Http(msg, status));
        }

        let reader = BufReader::new(resp);
        for line in reader.lines() {
            let line = line.map_err(|e| ApiError::Message(format!("Stream read failed: {}", e)))?;
            if line.trim().is_empty() {
                continue;
            }
            let Ok(event) = serde_json::from_str::<Value>(&line) else {
                continue;
            };
            if event.get("type").and_then(|t| t.as_str()) == Some("error") {
                let msg = event
                    .get("detail")
                    .and_then(|d| d.as_str())
                    .unwrap_or("BIRO stream failed.")
                    .to_string();
                return Err(ApiError::Message(msg));
            }
            if !on_event(&event) {
                break;
            }
        }
        Ok(())
    }
}
