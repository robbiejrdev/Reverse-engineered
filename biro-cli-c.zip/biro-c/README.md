# BIRO CLI — C port (in progress)

This repository is a native C rewrite of the uploaded BIRO CLI v1.2.1 project. It talks to the existing BIRO backend; it does not embed provider credentials or require backend changes.

## Build (Ubuntu/Debian)

```sh
sudo apt-get update
sudo apt-get install -y build-essential cmake pkg-config libcurl4-openssl-dev libjson-c-dev
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j
sudo cmake --install build
```

Run `biro --help`, `biro login`, `biro signup`, `biro -p "Explain this repository"`, or `biro` for the interactive prompt. Set `BIRO_API_URL` to override the backend URL, and `BIRO_MODEL=biro-mini` to change the default model. The accepted public models are `biro-max` and `biro-mini`.

Configuration is saved to `~/.config/biro/config.json`; the directory is chmod 0700 and the file 0600 where supported. Passwords are not persisted. `biro logout` removes the local token.

## Porting status and parity disclosure

The uploaded Python project has substantially more behavior than can honestly be claimed as complete in this first native port. This implementation includes native HTTP/JSON client code, signup/login, local session persistence, model/account/chat endpoints, NDJSON response streaming, a terminal prompt, model selection, chat resume/history, and local file/shell action execution with workspace path checks.

**Not yet at full feature parity:**

- Background task daemon and `biro jobs`/PM2 integration.
- Tavily web search implementation and bounded/date-tagged source validation.
- Image attachment encoding, image generation endpoint, and generated-artifact downloads.
- Long-prompt chunking and the four-attachment / 80,000-character attachment rules.
- Full conversation-memory attachments (the Python version fetches older messages to compensate for backend history limits).
- Rich prompt-toolkit behavior: command suggestions, arrow-key chat picker, prompt history/search, paste mode, file path completion, interruption handling, and persistent dashboard.
- Syntax-aware diff previews with line numbers and the ten-changed-line preview limit.
- GitHub/Hugging Face integration commands and OAuth/connectors.
- Full structured action parsing/validation and complete tool alias/envelope compatibility; only common fenced actions are currently recognized.
- Python project's test suite has not been ported; live backend integration is not verified from this environment.

Those gaps are explicitly listed rather than silently claiming that every behavior has been recreated. The original source remains the reference for exact parity: `src/biro/` and `tests/` in the uploaded archive. Treat this C port as an initial working base, not a drop-in complete replacement yet.

## Security notes

Shell actions execute commands in the current workspace, as the original coding agent intends. Only use this agent in directories you trust. File actions reject paths that resolve outside the workspace. This is not a sandbox against hostile shell commands: shell commands can still access other resources allowed to the current OS user.
