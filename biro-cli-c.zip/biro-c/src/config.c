#include "biro.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>
#include <errno.h>
#include <limits.h>

static void config_path(char *p,size_t n){const char *h=getenv("HOME"); if(!h)h="."; snprintf(p,n,"%s/.config/biro/config.json",h);}
void config_defaults(BiroConfig *c){memset(c,0,sizeof(*c));snprintf(c->api_url,sizeof(c->api_url),"%s",getenv("BIRO_API_URL")?getenv("BIRO_API_URL"):BIRO_DEFAULT_URL);snprintf(c->model,sizeof(c->model),"%s",getenv("BIRO_MODEL")?getenv("BIRO_MODEL"):"biro-max");if(strcmp(c->model,"biro-mini")&&strcmp(c->model,"biro-max"))snprintf(c->model,sizeof(c->model),"biro-max");}
int config_load(BiroConfig *c){char p[PATH_MAX];config_path(p,sizeof(p));FILE *f=fopen(p,"rb");if(!f)return 0;fseek(f,0,SEEK_END);long z=ftell(f);rewind(f);if(z<0||z>65536){fclose(f);return -1;}char *b=calloc((size_t)z+1,1);if(!b){fclose(f);return -1;}fread(b,1,(size_t)z,f);fclose(f);struct json_object *o=json_tokener_parse(b);free(b);if(!o)return -1;const char *s=NULL;struct json_object *v=NULL;
#define GET(k,dst) if(json_object_object_get_ex(o,k,&v)&&json_object_is_type(v,json_type_string)){s=json_object_get_string(v);snprintf(dst,sizeof(dst),"%s",s);}
GET("api_url",c->api_url);GET("access_token",c->token);GET("model",c->model);GET("current_chat_id",c->current_chat_id);
#undef GET
if(json_object_object_get_ex(o,"think",&v))c->think=json_object_get_boolean(v);json_object_put(o);if(strcmp(c->model,"biro-max")&&strcmp(c->model,"biro-mini"))snprintf(c->model,sizeof(c->model),"biro-max");const char *env=getenv("BIRO_API_URL");if(env&&*env)snprintf(c->api_url,sizeof(c->api_url),"%s",env);env=getenv("BIRO_MODEL");if(env&&*env&&(strcmp(env,"biro-max")==0||strcmp(env,"biro-mini")==0))snprintf(c->model,sizeof(c->model),"%s",env);return 1;}
int config_save(const BiroConfig *c){char p[PATH_MAX],d[PATH_MAX];config_path(p,sizeof(p));snprintf(d,sizeof(d),"%s/.config/biro",getenv("HOME")?getenv("HOME"):".");if(mkdir(d,0700)&&errno!=EEXIST)return -1;chmod(d,0700);struct json_object *o=json_object_new_object();json_object_object_add(o,"api_url",json_object_new_string(c->api_url));json_object_object_add(o,"access_token",json_object_new_string(c->token));json_object_object_add(o,"model",json_object_new_string(c->model));json_object_object_add(o,"current_chat_id",json_object_new_string(c->current_chat_id));json_object_object_add(o,"think",json_object_new_boolean(c->think));const char *s=json_object_to_json_string_ext(o,JSON_C_TO_STRING_PRETTY);FILE *f=fopen(p,"wb");if(!f){json_object_put(o);return -1;}int ok=fputs(s,f)>=0&&fputc('\n',f)!=EOF;fclose(f);chmod(p,0600);json_object_put(o);return ok?0:-1;}
int config_logout(BiroConfig *c){c->token[0]=0;c->current_chat_id[0]=0;return config_save(c);}
