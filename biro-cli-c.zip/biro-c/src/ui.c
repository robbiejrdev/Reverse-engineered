#include "biro.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
void ui_banner(void){puts("\033[36m  ██████╗ ██╗██████╗  ██████╗\n  ██╔══██╗██║██╔══██╗██╔═══██╗\n  ██████╔╝██║██████╔╝██║   ██║\n  ██╔══██╗██║██╔══██╗██║   ██║\n  ██████╔╝██║██║  ██║╚██████╔╝\n  ╚═════╝ ╚═╝╚═╝  ╚═╝ ╚═════╝\033[0m");printf("BIRO CLI C %s — terminal coding agent\n\n",BIRO_VERSION);}
char *ui_readline(const char *prompt){fputs(prompt,stdout);fflush(stdout);size_t cap=4096,n=0;char *b=malloc(cap);if(!b)return NULL;int ch;while((ch=getchar())!=EOF&&ch!='\n'){if(ch=='\r')continue;if(n+2>cap){if(cap>=1024*1024){fprintf(stderr,"Input exceeds 1 MiB.\n");free(b);return NULL;}cap*=2;char *p=realloc(b,cap);if(!p){free(b);return NULL;}b=p;}b[n++]=(char)ch;}if(ch==EOF&&n==0){free(b);return NULL;}b[n]=0;return b;}
void print_help(void){puts("BIRO CLI usage:\n  biro [--version] [--help] [-m max|mini] [--think] [-p PROMPT] [--background] [COMMAND]\n\nCommands:\n  login, signup, logout, jobs, chat CHAT_ID, chats, history, models, account\n\nInteractive commands:\n  /help /id /status /retry /rename TITLE /new /chats /open N /resume ID\n  /history /model [max|mini] /file PATH /image PATH /paste /cwd [PATH]\n  /account /login /signup /logout /models /clear /exit\n\nModel choices: biro-max and biro-mini. Backend defaults to https://api.robbiejr.site.\nSet BIRO_API_URL for a test backend. Credentials are not persisted; session token is stored in ~/.config/biro/config.json (0600).");}
