#ifndef BIRO_H
#define BIRO_H
#include <json-c/json.h>
#include <stddef.h>
#define BIRO_DEFAULT_URL "https://api.robbiejr.site"
#define BIRO_VERSION "1.2.1-c"
typedef struct { char api_url[512]; char token[4096]; char model[32]; char current_chat_id[256]; int think; } BiroConfig;
typedef struct { char *data; size_t len; size_t cap; long status; char content_type[256]; } HttpResponse;
void config_defaults(BiroConfig *c);
int config_load(BiroConfig *c);
int config_save(const BiroConfig *c);
int config_logout(BiroConfig *c);
int api_request(BiroConfig *c,const char *method,const char *path,struct json_object *payload,HttpResponse *out,int auth);
void response_free(HttpResponse *r);
struct json_object *api_json(BiroConfig *c,const char *method,const char *path,struct json_object *payload,int auth);
int api_login(BiroConfig *c,const char *email,const char *password,int signup,const char *name);
int api_stream(BiroConfig *c,const char *chat_id,const char *prompt,const char *attachments_json);
int api_create_chat(BiroConfig *c,char *out,size_t n);
int api_list_chats(BiroConfig *c);
int api_show_history(BiroConfig *c,const char *chat_id);
int api_models(BiroConfig *c);
int api_me(BiroConfig *c);
int tool_execute(const char *workspace,struct json_object *action,char **result);
int agent_send(BiroConfig *c,const char *prompt,const char *workspace);
void ui_banner(void);
char *ui_readline(const char *prompt);
void print_help(void);
char *json_string(struct json_object *o,const char *key,const char *fallback);
#endif
